PES [Personnel Evaluation System]

วิธีการนำไปทดสอบ

1.Unzip ไฟล์ไปยัง C:\PES หรือ ที่อื่น ตามความเหมาะสม แต่ในตัวอย่างจะใช้ C:\PES
ภายใน Folder PES ประกอบด้วย
[PES]
|-[backend]
|-[frontend]
|-.env
|-.gitignore
|-docker-compose.yml
|-schema.sql

2.ติดตั้ง Docker ให้เรียบร้อย

3.จากนั้นเปิด Command Prompt
```
c:
cd \
cd PES
docker compose up -d --build
```
4.ทดสอบโดยเข้าไปที่
Web Frontend : http://localhost:3000
Database : http://localhost:8080
5.login
username : admin@ccollege.ac.th
password : 12345678