<template>
  <v-app>
    <v-navigation-drawer
      v-model="drawer"
      :permanent="!smAndDown"
      :temporary="smAndDown"
      :rail="false"
      app
    >
      <v-list density="compact">
        <template v-for="sec in menu" :key="sec.label">
          <v-list-subheader>{{ sec.label }}</v-list-subheader>

          <v-list-item
            v-for="it in sec.items"
            :key="it.to"
            :to="it.to"
            link
          >
            <template #prepend>
              <v-icon :icon="it.icon || 'mdi-circle-small'" />
            </template>
            <v-list-item-title>{{ it.label }}</v-list-item-title>
          </v-list-item>

          <v-divider class="my-2" />
        </template>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar app flat>
      <!-- ให้กด toggle ได้ทุกขนาดจอ -->
      <v-app-bar-nav-icon @click="drawer = !drawer" />
      <v-toolbar-title>Personnel evaluation system</v-toolbar-title>

      <v-spacer />

      <v-btn icon @click="toggleTheme">
        <v-icon>mdi-theme-light-dark</v-icon>
      </v-btn>

      <!-- Profile -->
      <v-menu>
        <template #activator="{ props }">
          <v-btn v-bind="props" icon>
            <v-avatar size="32">
              <v-icon>mdi-account</v-icon>
            </v-avatar>
          </v-btn>
        </template>
        <v-list>
          <v-list-item
            :title="auth.user?.name || 'ผู้ใช้'"
            :subtitle="auth.user?.email || '-'"
            prepend-icon="mdi-account"
          />
          <v-divider class="my-2" />
          <NuxtLink to="/me" class="no-underline">
            <v-list-item title="Profile" prepend-icon="mdi-account-cog-outline" />
          </NuxtLink>
          <v-list-item title="Logout" prepend-icon="mdi-logout" @click="logout" />
        </v-list>
      </v-menu>
    </v-app-bar>

    <v-main class="bg-gray-50">
      <div class="p-4 lg:p-6">
        <slot /> <!-- Layout ใช้ slot -->
      </div>
    </v-main>

    <v-footer app class="text-caption">© {{ year }} VEC Skills</v-footer>
  </v-app>
</template>

<script setup>


/**
 * Composition API (JavaScript) เวอร์ชันสำหรับผู้เริ่มต้น:
 * - ตัด TypeScript ออกทั้งหมด
 * - คง logic เดิม (drawer + menu ตาม role + theme sync + logout)
 * - ใช้กับ Nuxt/Vuetify ได้เหมือนเดิม
 */
import { ref, computed, watch, onMounted } from 'vue'
import { useDisplay, useTheme } from 'vuetify'
import { useMenu } from '~/composables/useMenu'
import { useAuthStore } from '~/stores/auth'


// --- จอเล็ก/ใหญ่จาก Vuetify
const { smAndDown } = useDisplay()

// --- สถานะ Drawer: หน้าจอใหญ่ให้เปิด, หน้าจอเล็กให้ปิด
const drawer = ref(!smAndDown.value)
watch(smAndDown, (v) => { drawer.value = !v })

// --- Auth + Role (สมมติใช้ Pinia/auto-import ของ Nuxt)
const auth = typeof useAuthStore === 'function' ? useAuthStore() : null
const role = computed(() => (auth && auth.user && auth.user.role) ? auth.user.role : 'user')

// --- เมนูขึ้นกับ role (ใช้ composable ของโปรเจ็กต์)
const { menu } = useMenu(role.value)

// --- Theme: sync Vuetify + DaisyUI + localStorage
const theme = useTheme()
// ใน Nuxt มี useState; ถ้าไม่ใช้ Nuxt เปลี่ยนเป็น ref('light') ได้
const themeName = useState ? useState('theme', () => 'light') : ref('light')

function applyTheme (name) {
  // ตั้งชื่อธีมของ Vuetify
  theme.global.name.value = name
  // ตั้ง data-theme สำหรับ daisyUI และจำค่า
  if (typeof window !== 'undefined') {
    document.documentElement.setAttribute('data-theme', name)
    try {
      localStorage.setItem('theme', name)
    } catch (_) {}
  }
}

onMounted(() => {
  let saved = null
  if (typeof window !== 'undefined') {
    try {
      saved = localStorage.getItem('theme')
    } catch (_) {}
  }
  themeName.value = saved || themeName.value
  applyTheme(themeName.value)
})

function toggleTheme () {
  themeName.value = themeName.value === 'dark' ? 'light' : 'dark'
  applyTheme(themeName.value)
}

// --- ปีใน footer
const year = new Date().getFullYear()

// --- ออกจากระบบแบบง่าย ๆ (กัน error ถ้าไม่มี store)ใช้ optional chaining แบบ manual
//→ เช็กก่อนว่า มีตัวแปร auth หรือไม่ (auth && …) แล้วในนั้นมีเมธอดชื่อ clear หรือไม่ (auth.clear && …)
function logout () {
  // try { auth && auth.clear && auth.clear() } catch (_) {}
  try { auth && auth.logout && auth.logout() } catch (_) {}
  // redirect ไปหน้า login (ถ้ามี navigateTo)
  // ถ้าไม่มี ให้ใช้ window.location.href (กัน error กรณี SSR)
  if (typeof navigateTo === 'function') {
    navigateTo('/login')
  } else if (typeof window !== 'undefined') {
    window.location.href = '/login'
  }
}
</script>
