วิธีการทดสอบ
1 . กำหนด รูปแบบการเชื่อมต่อ

  GitLab   IP  172.16.3.10:80

  PortainerIP  172.16.3.10:9443

  Registry IP  172.16.3.10:5000

  Production IP 172.16.3.10


2.ทำ insecure-registries  ให้ Docker Engine

2.1 Docker Desktop บน Windows
{
  "builder": {
    "gc": {
      "defaultKeepStorage": "20GB",
      "enabled": true
    }
  },
  "experimental": false,
  "insecure-registries": [
    "192.168.0.112:5000"
  ]
}

2.2 Linux 
$ sudo nano /etc/docker/daemon.json
แล้วคัดลอกด้านล่างนี้ไปใส่
{
  "insecure-registries": [
    "172.16.3.10:5000"
  ]
}

3. ทำการ Build และ run ตาม Step โดยอยู่ใน Directory ที่เห็น ./database ./backend ./frontend
3.1  ทำ Database ก่อน
docker build -t 172.16.3.10:5000/node-project-database:latest ./database
docker push 172.16.3.10:5000/node-project-database:latest
docker run -d --name demo-task-postgres --restart unless-stopped -e POSTGRES_DB=demo_task_db -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=password -p 5432:5432 172.16.3.10:5000/node-project-database:latest

3.2 ทำ Backend
docker build -t 172.16.3.10:5000/node-project-backend:latest ./backend
docker push 172.16.3.10:5000/node-project-backend:latest
docker run -d --name demo-task-backend --restart unless-stopped -e DATABASE_URL=postgresql://postgres:password@host.docker.internal:5432/demo_task_db?schema=public -p 3000:3000 172.16.3.10:5000/node-project-backend:latest

3.3 ทำ Frontend
docker build -t 172.16.3.10:5000/node-project-frontend:latest ./frontend
docker push 172.16.3.10:5000/node-project-frontend:latest
docker run -d --name demo-task-frontend --restart unless-stopped -p 8080:80 172.16.3.10:5000/node-project-frontend:latest

3.4 ทดสอบโดยเปิด Browser แล้วเรียกผ่าน Port 8080


4. หยุดการทำงานของ Container ด้วย
🔻 4.1. หยุด container
docker stop demo-task-frontend
docker stop demo-task-backend
docker stop demo-task-postgres
หรือ หยุด container ทั้งหมด
docker stop $(docker ps -aq)

🗑️ 4.2. ลบ container
docker rm demo-task-frontend
docker rm demo-task-backend
docker rm demo-task-postgres
หรือ ลบ container ทั้งหมด
docker rm $(docker ps -aq)

📦 4.3. ลบ image ทั้งหมด หากไม่ใช้แล้ว
docker rmi -f $(docker images -q)


5. ใช้ Docker Compose ในการ Start Container
docker-compose up -d

======================================================================================
✅ ขั้นตอนการตั้งค่า SSH Key สำหรับ GitLab CI/CD
เปิด Git Bash บน Windows ถ้าไม่มีให้ติดตั้ง Git for Windows ก่อน

🔧 1. สร้าง SSH Key Pair บนเครื่อง Local ของคุณ
ssh-keygen -t rsa -b 4096 -C "gitlab-ci-deploy" -f ~/.ssh/gitlab_ci_rsa
กด Enter ตลอด ไม่ต้องใส่ passphrase
ไฟล์จะถูกสร้างที่ C:\Users\<ชื่อคุณ>\.ssh\gitlab_ci_rsa (สำหรับ Git Bash)
🗂️ ไฟล์ที่คุณจะได้:
gitlab_ci_rsa → ไฟล์ Private Key (ไว้ใส่ใน GitLab CI/CD Variables)
gitlab_ci_rsa.pub → ไฟล์ Public Key (นำไปใส่ใน ~/.ssh/authorized_keys ของเซิร์ฟเวอร์)

🖥️ 2. นำ Public Key ไปใส่ในเครื่องเซิร์ฟเวอร์ปลายทาง (เช่น VPS, Docker Host)
ล็อกอินเข้าเซิร์ฟเวอร์ปลายทาง แล้ว:
mkdir -p ~/.ssh
nano ~/.ssh/authorized_keys
แล้ววางเนื้อหา gitlab_ci_rsa.pub ลงไป
✅ อย่าลืมตั้ง permission:
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys


🔐 3. ตั้งค่า Private Key ใน GitLab CI/CD
เข้า GitLab ไปที่ [Your Project] → Settings → CI/CD → Variables
กด Add variable
Key: SSH_PRIVATE_KEY
Value: วางเนื้อหา gitlab_ci_rsa (Private Key ทั้งหมด)
Enable:
✅ Protected (ถ้าคุณใช้เฉพาะกับ main, develop)
✅ Masked

✅ ขั้นตอน เปิดใช้งาน SSH key-based authentication บน Ubuntu Server
1.SSH เข้าเซิร์ฟเวอร์:
ssh username@your-server-ip

2.แก้ไฟล์ SSH config:
sudo nano /etc/ssh/sshd_config

3.ตรวจสอบหรือแก้ไขบรรทัดต่อไปนี้ให้เป็น:
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys
PasswordAuthentication no   # (ถ้าต้องการปิดการ login ด้วยรหัสผ่าน)

4.บันทึกแล้วรีสตาร์ต SSH service:
sudo systemctl restart ssh

✅ ขั้นตอน  ทดสอบ SSH login ด้วย key
จากเครื่อง GitLab Runner หรือ Windows:
ssh -i ~/.ssh/gitlab_ci_rsa username@your-server-ip
หากเข้าสำเร็จโดยไม่ต้องใช้รหัสผ่าน แสดงว่าใช้งานได้แล้ว ✅

🛡️ เพิ่มเติม (ความปลอดภัย):
หลังจากทดสอบว่าการ login ด้วย key สำเร็จ ค่อย ปิด PasswordAuthentication เพื่อกัน brute-force
ควรใช้ user ที่ไม่ใช่ root เพื่อ deploy

หากคุณต้องการให้ GitLab CI ใช้ key นี้ auto-deploy ไปยัง server ก็สามารถเพิ่ม key นี้ใน GitLab CI/CD Variables ได้เช่นกัน 
(ใน Project > Settings > CI/CD > Variables) เช่น:
SSH_PRIVATE_KEY: เก็บเนื้อหาของ gitlab_ci_rsa

======================================================================================
# Demo Task App

แอปพลิเคชัน demo-task ที่สร้างด้วย Clean Architecture

## 🚀 ภาพรวม

Demo Task App เป็นแอปพลิเคชันจัดการงานที่สร้างด้วย Clean Architecture โดยใช้:
- **Backend**: Node.js + Express API
- **Frontend**: Vue 3 + Vite
- **Database**: In-memory storage (สำหรับ demo)
- **Containerization**: Docker
- **CI/CD**: GitLab CI/CD

## 📁 โครงสร้างโปรเจค

```
projects/
├── backend/                 # Backend API
│   ├── src/
│   │   ├── controllers/    # Business logic controllers
│   │   ├── services/       # Business logic services
│   │   ├── repositories/   # Data access layer
│   │   ├── routes/         # API routes
│   │   ├── middleware/     # Express middleware
│   │   └── index.js        # Entry point
│   ├── Dockerfile          # Backend container
│   ├── .gitlab-ci.yml      # CI/CD pipeline
│   └── package.json
├── frontend/               # Frontend application
│   ├── src/
│   │   ├── components/     # Vue components
│   │   ├── views/          # Page components
│   │   ├── stores/         # Pinia stores
│   │   ├── router/         # Vue Router
│   │   └── main.js         # Entry point
│   ├── Dockerfile          # Frontend container
│   ├── .gitlab-ci.yml      # CI/CD pipeline
│   └── package.json
└── database/
```

## 🛠️ การติดตั้งและรัน

### ข้อกำหนดเบื้องต้น

- Node.js 18+
- Docker และ Docker Compose
- Git

### การติดตั้งแบบ Local Development

#### Backend

```bash
cd backend
npm install
cp env.example .env
npm run dev
```

#### Frontend

```bash
cd frontend
npm install
npm run dev
```

### การรันด้วย Docker

```bash
# Build และ run ทั้งหมด
docker-compose up --build

# หรือแยกกัน
docker-compose up backend
docker-compose up frontend
```

## 🔗 URLs

- **Frontend**: http://localhost:5173 (development) / http://localhost (Docker)
- **Backend API**: http://localhost:3000/api
- **Health Check**: http://localhost:3000/health

## 🔄 CI/CD

โปรเจคนี้ใช้ GitLab CI/CD + Portainer สำหรับ auto deployment:
- **Staging**: Deploy อัตโนมัติเมื่อ push ไปยัง `develop` branch
- **Production**: Deploy แบบ manual เมื่อ push ไปยัง `main` branch
- **Registry**: GitLab Container Registry
- **Webhook**: Portainer webhook สำหรับ auto update

## 🐳 Docker

### การ Build Images
```bash
# Backend
docker build -t demo-task-backend ./backend

# Frontend
docker build -t demo-task-frontend ./frontend
```

### การรัน Containers แยกตาม Service

```bash
# Database
docker-compose -f docker-compose.database.yml up -d

# Backend
docker-compose -f docker-compose.backend.yml up -d

# Frontend
docker-compose -f docker-compose.frontend.yml up -d

```

### Registry และ Webhook

- **Registry**: GitLab Container Registry
- **Webhook**: Portainer webhook สำหรับ auto deployment
- **Monitoring**: Portainer dashboard

## 🧪 การทดสอบ

### Backend Tests

```bash
cd backend
npm test
npm run test:watch
```

### Frontend Tests

```bash
cd frontend
npm run build
npm run lint
```

## 📝 การพัฒนา

### การเพิ่มฟีเจอร์ใหม่

1. **Backend**: สร้าง Controller, Service, Repository
2. **Frontend**: สร้าง Component/View และ Store
3. **Tests**: เขียน unit tests
4. **Documentation**: อัปเดตเอกสาร

### Code Style

- Backend: ESLint configuration
- Frontend: Prettier + ESLint
- Commit messages: Conventional Commits

## 🤝 การมีส่วนร่วม

1. Fork โปรเจค
2. สร้าง feature branch
3. Commit การเปลี่ยนแปลง
4. Push ไปยัง branch
5. สร้าง Pull Request

## 📄 License

MIT License - ดูรายละเอียดใน [LICENSE](LICENSE) file 