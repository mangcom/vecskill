# Demo Task Backend

Backend API สำหรับ Demo Task App ที่สร้างด้วย Node.js + Express + Prisma + PostgreSQL

## 🚀 ภาพรวม

Backend service ที่ให้ API สำหรับจัดการ tasks โดยใช้:
- **Framework**: Node.js + Express
- **Database**: PostgreSQL + Prisma ORM
- **Architecture**: Clean Architecture
- **Containerization**: Docker
- **CI/CD**: GitLab CI/CD + Portainer

## 📁 โครงสร้างโปรเจค

```
backend/
├── src/
│   ├── controllers/    # Business logic controllers
│   ├── services/       # Business logic services
│   ├── repositories/   # Data access layer
│   ├── routes/         # API routes
│   ├── middleware/     # Express middleware
│   ├── scripts/        # Database scripts
│   └── index.js        # Entry point
├── prisma/
│   └── schema.prisma   # Database schema
├── Dockerfile          # Backend container
├── package.json
└── .gitlab-ci.yml     # CI/CD pipeline
```

## 🛠️ การติดตั้งและรัน

### ข้อกำหนดเบื้องต้น

- Node.js 18+
- PostgreSQL 15+
- Docker (optional)

### การติดตั้งแบบ Local Development

```bash
# Clone repository
git clone <backend-repo-url>
cd backend

# ติดตั้ง dependencies
npm install

# ตั้งค่า environment
cp env.example .env
# แก้ไข .env file

# รัน database migrations
npx prisma migrate dev

# รัน seed data
npm run seed

# รัน development server
npm run dev
```

### การรันด้วย Docker

```bash
# Build image
docker build -t demo-task-backend .

# รัน container
docker run -p 3000:3000 demo-task-backend
```

## 🔗 API Endpoints

### Tasks
- `GET /api/tasks` - ดึงรายการ tasks ทั้งหมด
- `GET /api/tasks/:id` - ดึง task ตาม ID
- `POST /api/tasks` - สร้าง task ใหม่
- `PUT /api/tasks/:id` - อัปเดต task
- `DELETE /api/tasks/:id` - ลบ task

### Health Check
- `GET /health` - ตรวจสอบสถานะ service

## 🗄️ Database

### Schema
```sql
-- Tasks table
CREATE TABLE tasks (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  status VARCHAR(50) DEFAULT 'pending',
  priority VARCHAR(50) DEFAULT 'medium',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Migrations
```bash
# สร้าง migration
npx prisma migrate dev --name add_task_table

# รัน migrations
npx prisma migrate deploy

# Reset database
npx prisma migrate reset
```

## 🧪 การทดสอบ

```bash
# รัน tests
npm test

# รัน tests แบบ watch
npm run test:watch

# รัน linting
npm run lint
```

## 🐳 Docker

### Build Image
```bash
docker build -t demo-task-backend .
```

### Environment Variables
```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/demo_task_db

# Server
NODE_ENV=production
PORT=3000

# Security
JWT_SECRET=your-secret-key
```

## 🔄 CI/CD

### GitLab CI/CD Pipeline

1. **Test Stage**: รัน unit tests และ linting
2. **Build Stage**: Build Docker image และ push ไปยัง registry
3. **Deploy Stage**: ส่ง webhook ไปยัง Portainer

### Environment Variables

ตั้งค่าใน GitLab CI/CD Variables:
```
# Registry
CI_REGISTRY=registry.gitlab.com
CI_REGISTRY_USER=your-username
CI_REGISTRY_PASSWORD=your-token
CI_REGISTRY_IMAGE=registry.gitlab.com/your-username/demo-task-backend

# Portainer Webhook URLs
PORTAINER_WEBHOOK_URL_BACKEND_STAGING=http://your-server:3001/webhook/backend/staging
PORTAINER_WEBHOOK_URL_BACKEND_PRODUCTION=http://your-server:3001/webhook/backend/production
```

## 📊 Monitoring

### Health Check
```bash
curl http://localhost:3000/health
```

### Logs
```bash
# Docker logs
docker logs demo-task-backend

# Application logs
npm run logs
```

## 🔒 Security

### Environment Variables
- ใช้ `.env` file สำหรับ local development
- ใช้ GitLab CI/CD variables สำหรับ production
- ไม่ commit secrets ไปยัง repository

### Database Security
- ใช้ connection pooling
- จำกัด database access
- ใช้ SSL สำหรับ production

## 🐛 การแก้ไขปัญหา

### ปัญหา: Database Connection
```bash
# ตรวจสอบ database connection
npx prisma db push

# ตรวจสอบ database status
npx prisma studio
```

### ปัญหา: Docker Build
```bash
# Clean build
docker build --no-cache -t demo-task-backend .

# ตรวจสอบ Dockerfile
docker build --progress=plain -t demo-task-backend .
```

## 📚 เอกสารเพิ่มเติม

- [Database Schema](./prisma/schema.prisma)

## 🤝 การมีส่วนร่วม

1. Fork โปรเจค
2. สร้าง feature branch
3. Commit การเปลี่ยนแปลง
4. Push ไปยัง branch
5. สร้าง Pull Request

## 📄 License

MIT License 