const TaskController = require('../controllers/TaskController');
const TaskService = require('../services/TaskService');

// Mock TaskService
jest.mock('../services/TaskService');

describe('TaskController', () => {
  let taskController;
  let mockTaskService;

  beforeEach(() => {
    mockTaskService = {
      getAllTasks: jest.fn(),
      getTaskById: jest.fn(),
      createTask: jest.fn(),
      updateTask: jest.fn(),
      deleteTask: jest.fn(),
    };
    
    TaskService.mockImplementation(() => mockTaskService);
    taskController = new TaskController();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('getAllTasks', () => {
    it('should return all tasks', async () => {
      const mockTasks = [
        { id: '1', title: 'Task 1' },
        { id: '2', title: 'Task 2' },
      ];
      
      mockTaskService.getAllTasks.mockResolvedValue(mockTasks);
      
      const result = await taskController.getAllTasks();
      
      expect(mockTaskService.getAllTasks).toHaveBeenCalled();
      expect(result).toEqual(mockTasks);
    });

    it('should throw error when service fails', async () => {
      const error = new Error('Service error');
      mockTaskService.getAllTasks.mockRejectedValue(error);
      
      await expect(taskController.getAllTasks()).rejects.toThrow('Service error');
    });
  });

  describe('getTaskById', () => {
    it('should return task when found', async () => {
      const mockTask = { id: '1', title: 'Task 1' };
      mockTaskService.getTaskById.mockResolvedValue(mockTask);
      
      const result = await taskController.getTaskById('1');
      
      expect(mockTaskService.getTaskById).toHaveBeenCalledWith('1');
      expect(result).toEqual(mockTask);
    });

    it('should throw NotFoundError when task not found', async () => {
      mockTaskService.getTaskById.mockResolvedValue(null);
      
      await expect(taskController.getTaskById('999')).rejects.toThrow('Task not found');
    });
  });

  describe('createTask', () => {
    it('should create and return new task', async () => {
      const taskData = { title: 'New Task', description: 'Description' };
      const mockTask = { id: '1', ...taskData };
      
      mockTaskService.createTask.mockResolvedValue(mockTask);
      
      const result = await taskController.createTask(taskData);
      
      expect(mockTaskService.createTask).toHaveBeenCalledWith(taskData);
      expect(result).toEqual(mockTask);
    });
  });

  describe('updateTask', () => {
    it('should update and return task when found', async () => {
      const taskData = { title: 'Updated Task' };
      const mockTask = { id: '1', ...taskData };
      
      mockTaskService.updateTask.mockResolvedValue(mockTask);
      
      const result = await taskController.updateTask('1', taskData);
      
      expect(mockTaskService.updateTask).toHaveBeenCalledWith('1', taskData);
      expect(result).toEqual(mockTask);
    });

    it('should throw NotFoundError when task not found', async () => {
      mockTaskService.updateTask.mockResolvedValue(null);
      
      await expect(taskController.updateTask('999', {})).rejects.toThrow('Task not found');
    });
  });

  describe('deleteTask', () => {
    it('should delete task successfully', async () => {
      mockTaskService.deleteTask.mockResolvedValue(true);
      
      const result = await taskController.deleteTask('1');
      
      expect(mockTaskService.deleteTask).toHaveBeenCalledWith('1');
      expect(result).toBe(true);
    });

    it('should throw NotFoundError when task not found', async () => {
      mockTaskService.deleteTask.mockResolvedValue(false);
      
      await expect(taskController.deleteTask('999')).rejects.toThrow('Task not found');
    });
  });
}); 