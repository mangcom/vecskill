const TaskService = require('../services/TaskService');

class TaskController {
  constructor() {
    this.taskService = new TaskService();
  }

  async getAllTasks(req, res, next) {
    try {
      const tasks = await this.taskService.getAllTasks();
      return tasks;
    } catch (error) {
      throw error;
    }
  }

  async getTaskById(id) {
    try {
      const task = await this.taskService.getTaskById(id);
      if (!task) {
        const error = new Error('Task not found');
        error.name = 'NotFoundError';
        error.statusCode = 404;
        throw error;
      }
      return task;
    } catch (error) {
      throw error;
    }
  }

  async createTask(taskData) {
    try {
      const task = await this.taskService.createTask(taskData);
      return task;
    } catch (error) {
      throw error;
    }
  }

  async updateTask(id, taskData) {
    try {
      const task = await this.taskService.updateTask(id, taskData);
      if (!task) {
        const error = new Error('Task not found');
        error.name = 'NotFoundError';
        error.statusCode = 404;
        throw error;
      }
      return task;
    } catch (error) {
      throw error;
    }
  }

  async deleteTask(id) {
    try {
      const deleted = await this.taskService.deleteTask(id);
      if (!deleted) {
        const error = new Error('Task not found');
        error.name = 'NotFoundError';
        error.statusCode = 404;
        throw error;
      }
      return true;
    } catch (error) {
      throw error;
    }
  }
}

module.exports = TaskController; 