const Joi = require('joi');

const taskSchema = Joi.object({
  title: Joi.string().min(1).max(255).required(),
  description: Joi.string().max(1000).optional(),
  status: Joi.string().valid('pending', 'in_progress', 'completed', 'PENDING', 'IN_PROGRESS', 'COMPLETED').default('pending'),
  priority: Joi.string().valid('low', 'medium', 'high', 'LOW', 'MEDIUM', 'HIGH').default('medium'),
  dueDate: Joi.date().iso().optional()
});

const validateTask = (req, res, next) => {
  if (req.body && req.body.id) {
    console.log(`req.body id = ${req.body.id}`);
  }
  const { error, value } = taskSchema.validate(req.body, { allowUnknown: true });

  if (error) {
    const errorMessage = error.details.map(detail => detail.message).join(', ');
    const validationError = new Error(`Validation error: ${errorMessage}`);
    validationError.name = 'ValidationError';
    validationError.statusCode = 400;
    return next(validationError);
  }

  // Remove 'id' from value if present, to avoid "id is not allowed" error
  if ('id' in value) {
    delete value.id;
  }

  req.body = value;
  next();
};

module.exports = { validateTask }; 