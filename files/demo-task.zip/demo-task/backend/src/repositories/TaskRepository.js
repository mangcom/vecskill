const databaseService = require('../services/DatabaseService');

class TaskRepository {
  constructor() {
    this.prisma = databaseService.getPrisma();
  }

  async findAll() {
    try {
      return await this.prisma.task.findMany({
        orderBy: {
          createdAt: 'desc'
        }
      });
    } catch (error) {
      console.error('Error finding all tasks:', error);
      throw error;
    }
  }

  async findById(id) {
    try {
      return await this.prisma.task.findUnique({
        where: { id }
      });
    } catch (error) {
      console.error('Error finding task by id:', error);
      throw error;
    }
  }

  async create(taskData) {
    try {
      return await this.prisma.task.create({
        data: {
          title: taskData.title,
          description: taskData.description || '',
          status: taskData.status || 'PENDING',
          priority: taskData.priority || 'MEDIUM',
          dueDate: taskData.dueDate ? new Date(taskData.dueDate) : null
        }
      });
    } catch (error) {
      console.error('Error creating task:', error);
      throw error;
    }
  }

  async update(id, taskData) {
    try {
      return await this.prisma.task.update({
        where: { id },
        data: {
          title: taskData.title,
          description: taskData.description,
          status: taskData.status,
          priority: taskData.priority,
          dueDate: taskData.dueDate ? new Date(taskData.dueDate) : null
        }
      });
    } catch (error) {
      console.error('Error updating task:', error);
      throw error;
    }
  }

  async delete(id) {
    try {
      await this.prisma.task.delete({
        where: { id }
      });
      return true;
    } catch (error) {
      console.error('Error deleting task:', error);
      throw error;
    }
  }

  async findByStatus(status) {
    try {
      return await this.prisma.task.findMany({
        where: { status },
        orderBy: {
          createdAt: 'desc'
        }
      });
    } catch (error) {
      console.error('Error finding tasks by status:', error);
      throw error;
    }
  }

  async findByPriority(priority) {
    try {
      return await this.prisma.task.findMany({
        where: { priority },
        orderBy: {
          createdAt: 'desc'
        }
      });
    } catch (error) {
      console.error('Error finding tasks by priority:', error);
      throw error;
    }
  }

  async count() {
    try {
      return await this.prisma.task.count();
    } catch (error) {
      console.error('Error counting tasks:', error);
      throw error;
    }
  }
}

module.exports = TaskRepository; 