const express = require('express');
const router = express.Router();
const TaskController = require('../controllers/TaskController');
const { validateTask } = require('../middleware/validation');

const taskController = new TaskController();

// GET /api/tasks - Get all tasks
router.get('/', async (req, res, next) => {
  try {
    const tasks = await taskController.getAllTasks();
    res.json({
      success: true,
      data: tasks
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/tasks/:tid - Get task by ID
router.get('/:tid', async (req, res, next) => {
  try {
    const task = await taskController.getTaskById(req.params.tid);
    res.json({
      success: true,
      data: task
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/tasks - Create new task
router.post('/', validateTask, async (req, res, next) => {
  try {
    const task = await taskController.createTask(req.body);
    res.status(201).json({
      success: true,
      data: task
    });
  } catch (error) {
    next(error);
  }
});

// PUT /api/tasks/:tid - Update task
router.put('/:tid', validateTask, async (req, res, next) => {
  console.log('req.params');
  console.log(req.params);
  console.log('req.body');
  console.log(req.body);
  try {
    const task = await taskController.updateTask(req.params.tid, req.body);
    res.json({
      success: true,
      data: task
    });
  } catch (error) {
    next(error);
  }
});

// DELETE /api/tasks/:tid - Delete task
router.delete('/:tid', async (req, res, next) => {
  try {
    await taskController.deleteTask(req.params.tid);
    res.json({
      success: true,
      message: 'Task deleted successfully'
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router; 