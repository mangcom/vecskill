const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seeding...');

  // Clear existing data
  await prisma.task.deleteMany({});

  // Create sample tasks
  const tasks = [
    {
      title: 'Complete project documentation',
      description: 'Write comprehensive documentation for the demo task app',
      status: 'IN_PROGRESS',
      priority: 'HIGH',
      dueDate: new Date('2024-01-15')
    },
    {
      title: 'Setup CI/CD pipeline',
      description: 'Configure GitLab CI/CD for auto deployment',
      status: 'COMPLETED',
      priority: 'HIGH',
      dueDate: new Date('2024-01-10')
    },
    {
      title: 'Create Docker containers',
      description: 'Build Docker images for backend and frontend',
      status: 'PENDING',
      priority: 'MEDIUM',
      dueDate: new Date('2024-01-20')
    },
    {
      title: 'Implement PostgreSQL integration',
      description: 'Connect backend to PostgreSQL database using Prisma ORM',
      status: 'IN_PROGRESS',
      priority: 'HIGH',
      dueDate: new Date('2024-01-25')
    },
    {
      title: 'Add unit tests',
      description: 'Write comprehensive unit tests for all components',
      status: 'PENDING',
      priority: 'MEDIUM',
      dueDate: new Date('2024-01-30')
    }
  ];

  for (const task of tasks) {
    await prisma.task.create({
      data: task
    });
  }

  console.log('✅ Database seeded successfully!');
  console.log(`📊 Created ${tasks.length} sample tasks`);
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  }); 