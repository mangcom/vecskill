const TaskRepository = require('../repositories/TaskRepository');

class TaskService {
  constructor() {
    this.taskRepository = new TaskRepository();
  }

  async getAllTasks() {
    try {
      return await this.taskRepository.findAll();
    } catch (error) {
      throw error;
    }
  }

  async getTaskById(id) {
    try {
      return await this.taskRepository.findById(id);
    } catch (error) {
      throw error;
    }
  }

  async createTask(taskData) {
    try {
      // Convert status and priority to uppercase for enum
      const normalizedTaskData = {
        ...taskData,
        status: taskData.status?.toUpperCase() || 'PENDING',
        priority: taskData.priority?.toUpperCase() || 'MEDIUM'
      };

      return await this.taskRepository.create(normalizedTaskData);
    } catch (error) {
      throw error;
    }
  }

  async updateTask(id, taskData) {
    try {
      const existingTask = await this.taskRepository.findById(id);
      if (!existingTask) {
        return null;
      }

      // Convert status and priority to uppercase for enum
      const normalizedTaskData = {
        ...taskData,
        status: taskData.status?.toUpperCase(),
        priority: taskData.priority?.toUpperCase()
      };

      return await this.taskRepository.update(id, normalizedTaskData);
    } catch (error) {
      throw error;
    }
  }

  async deleteTask(id) {
    try {
      const task = await this.taskRepository.findById(id);
      if (!task) {
        return false;
      }

      await this.taskRepository.delete(id);
      return true;
    } catch (error) {
      throw error;
    }
  }

  // ID generation is now handled by Prisma with cuid()
  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }
}

module.exports = TaskService; 