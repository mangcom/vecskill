-- init.sql

-- สร้าง enum
CREATE TYPE "TaskStatus" AS ENUM (
  'PENDING',
  'IN_PROGRESS',
  'COMPLETED'
);

CREATE TYPE "Priority" AS ENUM (
  'LOW',
  'MEDIUM',
  'HIGH'
);

-- สร้างตาราง tasks
CREATE TABLE tasks (
  id          TEXT PRIMARY KEY,
  title       VARCHAR(255) NOT NULL,
  description TEXT,
  status      "TaskStatus" NOT NULL DEFAULT 'PENDING',
  priority    "Priority" NOT NULL DEFAULT 'MEDIUM',
  "dueDate"   TIMESTAMP,
  "createdAt" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
