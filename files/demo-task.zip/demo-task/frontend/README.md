# Demo Task Frontend

Frontend application สำหรับ Demo Task App ที่สร้างด้วย Vue 3 + Vite + Pinia

## 🚀 ภาพรวม

Frontend service ที่ให้ user interface สำหรับจัดการ tasks โดยใช้:
- **Framework**: Vue 3 + Vite
- **State Management**: Pinia
- **Routing**: Vue Router
- **UI Framework**: Tailwind CSS
- **Containerization**: Docker
- **CI/CD**: GitLab CI/CD + Portainer

## 📁 โครงสร้างโปรเจค

```
frontend/
├── src/
│   ├── components/     # Vue components
│   ├── views/          # Page components
│   ├── stores/         # Pinia stores
│   ├── router/         # Vue Router
│   ├── assets/         # Static assets
│   └── main.js         # Entry point
├── public/             # Public assets
├── Dockerfile          # Frontend container
├── package.json
└── .gitlab-ci.yml     # CI/CD pipeline
```

## 🛠️ การติดตั้งและรัน

### ข้อกำหนดเบื้องต้น

- Node.js 18+
- npm หรือ yarn
- Docker (optional)

### การติดตั้งแบบ Local Development

```bash
# Clone repository
git clone <frontend-repo-url>
cd frontend

# ติดตั้ง dependencies
npm install

# ตั้งค่า environment
cp .env.example .env
# แก้ไข .env file

# รัน development server
npm run dev
```

### การรันด้วย Docker

```bash
# Build image
docker build -t demo-task-frontend .

# รัน container
docker run -p 80:80 demo-task-frontend
```

## 🔗 URLs

- **Development**: http://localhost:5173
- **Production**: http://localhost
- **API Base URL**: http://localhost:3000/api

## 📱 Features

### Task Management
- ✅ สร้าง task ใหม่
- ✅ แก้ไข task
- ✅ ลบ task
- ✅ เปลี่ยนสถานะ task
- ✅ ตั้งค่าความสำคัญ

### User Interface
- 🎨 Modern UI design
- 📱 Responsive design
- ⚡ Fast loading
- 🔄 Real-time updates

## 🧪 การทดสอบ

```bash
# รัน tests
npm test

# รัน tests แบบ watch
npm run test:watch

# รัน linting
npm run lint

# Build production
npm run build
```

## 🐳 Docker

### Build Image
```bash
docker build -t demo-task-frontend .
```

### Environment Variables
```bash
# API Configuration
VITE_API_BASE_URL=http://localhost:3000/api

# App Configuration
VITE_APP_TITLE=Demo Task App
VITE_APP_VERSION=1.0.0
```

## 🔄 CI/CD

### GitLab CI/CD Pipeline

1. **Test Stage**: รัน unit tests และ linting
2. **Build Stage**: Build Docker image และ push ไปยัง registry
3. **Deploy Stage**: ส่ง webhook ไปยัง Portainer

### Environment Variables

ตั้งค่าใน GitLab CI/CD Variables:
```
# Registry
CI_REGISTRY=registry.gitlab.com
CI_REGISTRY_USER=your-username
CI_REGISTRY_PASSWORD=your-token
CI_REGISTRY_IMAGE=registry.gitlab.com/your-username/demo-task-frontend

# Portainer Webhook URLs
PORTAINER_WEBHOOK_URL_FRONTEND_STAGING=http://your-server:3001/webhook/frontend/staging
PORTAINER_WEBHOOK_URL_FRONTEND_PRODUCTION=http://your-server:3001/webhook/frontend/production
```

## 📊 Monitoring

### Health Check
```bash
curl http://localhost/health
```

### Build Status
```bash
# ตรวจสอบ build
npm run build

# ตรวจสอบ bundle size
npm run analyze
```

## 🔒 Security

### Environment Variables
- ใช้ `.env` file สำหรับ local development
- ใช้ GitLab CI/CD variables สำหรับ production
- ไม่ commit secrets ไปยัง repository

### Content Security Policy
- ตั้งค่า CSP headers
- จำกัด external resources
- ใช้ HTTPS สำหรับ production

## 🐛 การแก้ไขปัญหา

### ปัญหา: Build Failed
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install

# Clear cache
npm run clean
```

### ปัญหา: Docker Build
```bash
# Clean build
docker build --no-cache -t demo-task-frontend .

# ตรวจสอบ Dockerfile
docker build --progress=plain -t demo-task-frontend .
```

### ปัญหา: API Connection
```bash
# ตรวจสอบ API endpoint
curl http://localhost:3000/api/tasks

# ตรวจสอบ CORS
# ตรวจสอบ network tab ใน browser
```

## 🤝 การมีส่วนร่วม

1. Fork โปรเจค
2. สร้าง feature branch
3. Commit การเปลี่ยนแปลง
4. Push ไปยัง branch
5. สร้าง Pull Request

## 📄 License

MIT License 