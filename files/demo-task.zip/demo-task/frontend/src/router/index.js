import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '@/views/HomeView.vue'
import TaskListView from '@/views/TaskListView.vue'
import TaskDetailView from '@/views/TaskDetailView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
    meta: { title: 'หน้าแรก - Demo Task App' }
  },
  {
    path: '/tasks',
    name: 'tasks',
    component: TaskListView,
    meta: { title: 'จัดการงาน - Demo Task App' }
  },
  {
    path: '/tasks/:id',
    name: 'task-detail',
    component: TaskDetailView,
    meta: { title: 'รายละเอียดงาน - Demo Task App' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Update page title
router.beforeEach((to, from, next) => {
  if (to.meta.title) {
    document.title = to.meta.title
  }
  next()
})

export default router 