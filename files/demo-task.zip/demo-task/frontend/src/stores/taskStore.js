import { defineStore } from 'pinia'
import { ref } from 'vue'
import axios from 'axios'

export const useTaskStore = defineStore('task', () => {
  const tasks = ref([])
  const loading = ref(false)
  const error = ref(null)

  const API_BASE_URL = '/api/tasks'

  const fetchTasks = async () => {
    loading.value = true
    error.value = null
    
    try {
      const response = await axios.get(API_BASE_URL)
      tasks.value = response.data.data
    } catch (err) {
      error.value = err.response?.data?.error?.message || 'เกิดข้อผิดพลาดในการโหลดข้อมูล'
      console.error('Error fetching tasks:', err)
    } finally {
      loading.value = false
    }
  }

  const fetchTaskById = async (id) => {
    loading.value = true
    error.value = null
    
    try {
      const response = await axios.get(`${API_BASE_URL}/${id}`)
      return response.data.data
    } catch (err) {
      error.value = err.response?.data?.error?.message || 'เกิดข้อผิดพลาดในการโหลดข้อมูล'
      console.error('Error fetching task:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const createTask = async (taskData) => {
    loading.value = true
    error.value = null
    
    try {
      const response = await axios.post(API_BASE_URL, taskData)
      const newTask = response.data.data
      tasks.value.push(newTask)
      return newTask
    } catch (err) {
      error.value = err.response?.data?.error?.message || 'เกิดข้อผิดพลาดในการสร้างงาน'
      console.error('Error creating task:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const updateTask = async (id, taskData) => {
    loading.value = true
    error.value = null
    
    try {
      const response = await axios.put(`${API_BASE_URL}/${id}`, taskData)
      const updatedTask = response.data.data
      const index = tasks.value.findIndex(task => task.id === id)
      if (index !== -1) {
        tasks.value[index] = updatedTask
      }
      return updatedTask
    } catch (err) {
      error.value = err.response?.data?.error?.message || 'เกิดข้อผิดพลาดในการอัปเดตงาน'
      console.error('Error updating task:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const deleteTask = async (id) => {
    loading.value = true
    error.value = null
    
    try {
      await axios.delete(`${API_BASE_URL}/${id}`)
      tasks.value = tasks.value.filter(task => task.id !== id)
    } catch (err) {
      error.value = err.response?.data?.error?.message || 'เกิดข้อผิดพลาดในการลบงาน'
      console.error('Error deleting task:', err)
      throw err
    } finally {
      loading.value = false
    }
  }

  const getTaskById = (id) => {
    return tasks.value.find(task => task.id === id)
  }

  const getTasksByStatus = (status) => {
    return tasks.value.filter(task => task.status === status)
  }

  const getTasksByPriority = (priority) => {
    return tasks.value.filter(task => task.priority === priority)
  }

  return {
    tasks,
    loading,
    error,
    fetchTasks,
    fetchTaskById,
    createTask,
    updateTask,
    deleteTask,
    getTaskById,
    getTasksByStatus,
    getTasksByPriority
  }
}) 