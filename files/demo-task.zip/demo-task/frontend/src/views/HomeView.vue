<template>
  <div class="home">
    <div class="hero">
      <h1 class="hero-title">ยินดีต้อนรับสู่ Demo Task App</h1>
      <p class="hero-subtitle">
        แอปพลิเคชันจัดการงานที่สร้างด้วย Vue 3 และ Clean Architecture
      </p>
      <div class="hero-actions">
        <router-link to="/tasks" class="btn btn-primary">
          เริ่มจัดการงาน
        </router-link>
      </div>
    </div>

    <div class="features">
      <div class="feature-card">
        <div class="feature-icon">🚀</div>
        <h3>Vue 3</h3>
        <p>ใช้ Vue 3 Composition API สำหรับการพัฒนา UI ที่ทันสมัย</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">🏗️</div>
        <h3>Clean Architecture</h3>
        <p>โครงสร้างโค้ดที่แยกส่วนชัดเจน ง่ายต่อการบำรุงรักษา</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">🔧</div>
        <h3>Express API</h3>
        <p>Backend API ที่สร้างด้วย Node.js และ Express</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">🐳</div>
        <h3>Docker Ready</h3>
        <p>พร้อมใช้งานกับ Docker และ CI/CD pipeline</p>
      </div>
    </div>

    <div class="stats">
      <div class="stat-card">
        <h3>{{ stats.totalTasks }}</h3>
        <p>งานทั้งหมด</p>
      </div>
      <div class="stat-card">
        <h3>{{ stats.completedTasks }}</h3>
        <p>งานที่เสร็จแล้ว</p>
      </div>
      <div class="stat-card">
        <h3>{{ stats.pendingTasks }}</h3>
        <p>งานที่รอดำเนินการ</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useTaskStore } from '@/stores/taskStore'

const taskStore = useTaskStore()
const stats = ref({
  totalTasks: 0,
  completedTasks: 0,
  pendingTasks: 0
})

onMounted(async () => {
  await taskStore.fetchTasks()
  const tasks = taskStore.tasks
  
  stats.value = {
    totalTasks: tasks.length,
    completedTasks: tasks.filter(task => task.status === 'completed').length,
    pendingTasks: tasks.filter(task => task.status === 'pending').length
  }
})
</script>

<style scoped>
.home {
  text-align: center;
}

.hero {
  padding: 4rem 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-radius: 12px;
  margin-bottom: 3rem;
}

.hero-title {
  font-size: 3rem;
  margin-bottom: 1rem;
  font-weight: bold;
}

.hero-subtitle {
  font-size: 1.2rem;
  margin-bottom: 2rem;
  opacity: 0.9;
}

.hero-actions {
  margin-top: 2rem;
}

.btn {
  display: inline-block;
  padding: 0.75rem 2rem;
  border-radius: 8px;
  text-decoration: none;
  font-weight: bold;
  transition: all 0.3s;
}

.btn-primary {
  background-color: #28a745;
  color: white;
}

.btn-primary:hover {
  background-color: #218838;
  transform: translateY(-2px);
}

.features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
}

.feature-card {
  padding: 2rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  transition: transform 0.3s;
}

.feature-card:hover {
  transform: translateY(-5px);
}

.feature-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
}

.feature-card h3 {
  margin-bottom: 1rem;
  color: #333;
}

.feature-card p {
  color: #666;
  line-height: 1.6;
}

.stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
}

.stat-card {
  padding: 2rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.stat-card h3 {
  font-size: 2.5rem;
  color: #667eea;
  margin-bottom: 0.5rem;
}

.stat-card p {
  color: #666;
  font-weight: bold;
}
</style> 