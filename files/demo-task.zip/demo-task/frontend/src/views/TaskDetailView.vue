<template>
  <div class="task-detail">
    <div v-if="loading" class="loading">
      กำลังโหลดข้อมูล...
    </div>

    <div v-else-if="error" class="error">
      {{ error }}
    </div>

    <div v-else-if="!task" class="not-found">
      <h2>ไม่พบงานที่ต้องการ</h2>
      <router-link to="/tasks" class="btn btn-primary">
        กลับไปหน้ารายการ
      </router-link>
    </div>

    <div v-else class="task-content">
      <div class="task-header">
        <div class="back-link">
          <router-link to="/tasks" class="btn-back">
            ← กลับไปหน้ารายการ
          </router-link>
        </div>
        
        <div class="task-actions">
          <button @click="showEditModal = true" class="btn btn-primary">
            แก้ไขงาน
          </button>
          <button @click="deleteTask" class="btn btn-danger">
            ลบงาน
          </button>
        </div>
      </div>

      <div class="task-card">
        <div class="task-title">
          <h1>{{ task.title }}</h1>
          <div class="task-badges">
            <span class="status-badge" :class="task.status">
              {{ getStatusText(task.status) }}
            </span>
            <span class="priority-badge" :class="task.priority">
              {{ getPriorityText(task.priority) }}
            </span>
          </div>
        </div>

        <div class="task-description">
          <h3>รายละเอียด</h3>
          <p>{{ task.description || 'ไม่มีรายละเอียด' }}</p>
        </div>

        <div class="task-info">
          <div class="info-item">
            <strong>สถานะ:</strong>
            <span :class="`status-${task.status}`">
              {{ getStatusText(task.status) }}
            </span>
          </div>
          
          <div class="info-item">
            <strong>ความสำคัญ:</strong>
            <span :class="`priority-${task.priority}`">
              {{ getPriorityText(task.priority) }}
            </span>
          </div>
          
          <div class="info-item" v-if="task.dueDate">
            <strong>กำหนดส่ง:</strong>
            <span>{{ formatDate(task.dueDate) }}</span>
          </div>
          
          <div class="info-item">
            <strong>สร้างเมื่อ:</strong>
            <span>{{ formatDateTime(task.createdAt) }}</span>
          </div>
          
          <div class="info-item">
            <strong>อัปเดตล่าสุด:</strong>
            <span>{{ formatDateTime(task.updatedAt) }}</span>
          </div>
        </div>
      </div>

      <!-- Edit Modal -->
      <div v-if="showEditModal" class="modal-overlay" @click="closeModal">
        <div class="modal" @click.stop>
          <h2>แก้ไขงาน</h2>
          
          <form @submit.prevent="handleSubmit" class="task-form">
            <div class="form-group">
              <label>หัวข้อ *</label>
              <input 
                v-model="formData.title" 
                type="text" 
                required 
                placeholder="ใส่หัวข้องาน"
              />
            </div>
            
            <div class="form-group">
              <label>รายละเอียด</label>
              <textarea 
                v-model="formData.description" 
                placeholder="ใส่รายละเอียดงาน"
                rows="3"
              ></textarea>
            </div>
            
            <div class="form-row">
              <div class="form-group">
                <label>สถานะ</label>
                <select v-model="formData.status">
                  <option value="pending">รอดำเนินการ</option>
                  <option value="in_progress">กำลังดำเนินการ</option>
                  <option value="completed">เสร็จแล้ว</option>
                </select>
              </div>
              
              <div class="form-group">
                <label>ความสำคัญ</label>
                <select v-model="formData.priority">
                  <option value="low">ต่ำ</option>
                  <option value="medium">ปานกลาง</option>
                  <option value="high">สูง</option>
                </select>
              </div>
            </div>
            
            <div class="form-group">
              <label>กำหนดส่ง</label>
              <input v-model="formData.dueDate" type="date" />
            </div>
            
            <div class="form-actions">
              <button type="button" @click="closeModal" class="btn btn-secondary">
                ยกเลิก
              </button>
              <button type="submit" class="btn btn-primary">
                อัปเดต
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useTaskStore } from '@/stores/taskStore'
import { format } from 'date-fns'

const route = useRoute()
const router = useRouter()
const taskStore = useTaskStore()

const task = ref(null)
const showEditModal = ref(false)
const loading = ref(false)
const error = ref(null)

const formData = ref({
  title: '',
  description: '',
  status: 'pending',
  priority: 'medium',
  dueDate: ''
})

onMounted(async () => {
  await loadTask()
})

const loadTask = async () => {
  loading.value = true
  error.value = null
  
  try {
    task.value = await taskStore.fetchTaskById(route.params.id)
    if (task.value) {
      formData.value = { ...task.value }
    }
  } catch (err) {
    error.value = 'ไม่สามารถโหลดข้อมูลงานได้'
    console.error('Error loading task:', err)
  } finally {
    loading.value = false
  }
}

const closeModal = () => {
  showEditModal.value = false
  formData.value = { ...task.value }
}

const handleSubmit = async () => {
  try {
    await taskStore.updateTask(task.value.id, formData.value)
    await loadTask() // Reload task data
    closeModal()
  } catch (error) {
    console.error('Error updating task:', error)
  }
}

const deleteTask = async () => {
  if (confirm('คุณแน่ใจหรือไม่ที่จะลบงานนี้?')) {
    try {
      await taskStore.deleteTask(task.value.id)
      router.push('/tasks')
    } catch (error) {
      console.error('Error deleting task:', error)
    }
  }
}

const getStatusText = (status) => {
  const statusMap = {
    pending: 'รอดำเนินการ',
    in_progress: 'กำลังดำเนินการ',
    completed: 'เสร็จแล้ว'
  }
  return statusMap[status] || status
}

const getPriorityText = (priority) => {
  const priorityMap = {
    low: 'ต่ำ',
    medium: 'ปานกลาง',
    high: 'สูง'
  }
  return priorityMap[priority] || priority
}

const formatDate = (dateString) => {
  try {
    return format(new Date(dateString), 'dd/MM/yyyy')
  } catch {
    return dateString
  }
}

const formatDateTime = (dateString) => {
  try {
    return format(new Date(dateString), 'dd/MM/yyyy HH:mm')
  } catch {
    return dateString
  }
}
</script>

<style scoped>
.task-detail {
  max-width: 800px;
  margin: 0 auto;
}

.loading, .error, .not-found {
  text-align: center;
  padding: 2rem;
  color: #666;
}

.error {
  color: #dc3545;
}

.not-found h2 {
  margin-bottom: 1rem;
  color: #333;
}

.task-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.back-link {
  flex: 1;
}

.btn-back {
  color: #667eea;
  text-decoration: none;
  font-weight: bold;
}

.btn-back:hover {
  text-decoration: underline;
}

.task-actions {
  display: flex;
  gap: 1rem;
}

.task-card {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.task-title {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 2rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.task-title h1 {
  margin: 0;
  color: #333;
  flex: 1;
  min-width: 300px;
}

.task-badges {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.status-badge, .priority-badge {
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: bold;
}

.status-badge.pending {
  background-color: #fff3cd;
  color: #856404;
}

.status-badge.in_progress {
  background-color: #cce5ff;
  color: #004085;
}

.status-badge.completed {
  background-color: #d4edda;
  color: #155724;
}

.priority-badge.low {
  background-color: #e2e3e5;
  color: #383d41;
}

.priority-badge.medium {
  background-color: #fff3cd;
  color: #856404;
}

.priority-badge.high {
  background-color: #f8d7da;
  color: #721c24;
}

.task-description {
  margin-bottom: 2rem;
}

.task-description h3 {
  margin-bottom: 1rem;
  color: #333;
}

.task-description p {
  color: #666;
  line-height: 1.6;
}

.task-info {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
}

.info-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background-color: #f8f9fa;
  border-radius: 8px;
}

.info-item strong {
  color: #333;
}

.info-item span {
  font-weight: bold;
}

.info-item .status-pending {
  color: #856404;
}

.info-item .status-in_progress {
  color: #004085;
}

.info-item .status-completed {
  color: #155724;
}

.info-item .priority-low {
  color: #383d41;
}

.info-item .priority-medium {
  color: #856404;
}

.info-item .priority-high {
  color: #721c24;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.modal h2 {
  margin-bottom: 1.5rem;
  color: #333;
}

.task-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.form-group label {
  font-weight: bold;
  color: #333;
}

.form-group input,
.form-group textarea,
.form-group select {
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

.form-group textarea {
  resize: vertical;
  min-height: 80px;
}

.form-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 1rem;
}

.btn {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-primary {
  background-color: #667eea;
  color: white;
}

.btn-primary:hover {
  background-color: #5a6fd8;
}

.btn-secondary {
  background-color: #6c757d;
  color: white;
}

.btn-secondary:hover {
  background-color: #5a6268;
}

.btn-danger {
  background-color: #dc3545;
  color: white;
}

.btn-danger:hover {
  background-color: #c82333;
}

@media (max-width: 768px) {
  .task-header {
    flex-direction: column;
    gap: 1rem;
    align-items: stretch;
  }
  
  .task-title {
    flex-direction: column;
    align-items: stretch;
  }
  
  .task-title h1 {
    min-width: auto;
  }
  
  .info-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
}
</style> 