<template>
  <div class="task-list">
    <div class="header">
      <h1>จัดการงาน</h1>
      <button @click="showCreateModal = true" class="btn btn-primary">
        + เพิ่มงานใหม่
      </button>
    </div>

    <div class="filters">
      <select v-model="statusFilter" class="filter-select">
        <option value="">สถานะทั้งหมด</option>
        <option value="pending">รอดำเนินการ</option>
        <option value="in_progress">กำลังดำเนินการ</option>
        <option value="completed">เสร็จแล้ว</option>
      </select>
      
      <select v-model="priorityFilter" class="filter-select">
        <option value="">ความสำคัญทั้งหมด</option>
        <option value="low">ต่ำ</option>
        <option value="medium">ปานกลาง</option>
        <option value="high">สูง</option>
      </select>
    </div>

    <div v-if="loading" class="loading">
      กำลังโหลดข้อมูล...
    </div>

    <div v-else-if="error" class="error">
      {{ error }}
    </div>

    <div v-else-if="filteredTasks.length === 0" class="empty-state">
      <p>ไม่มีงานที่ตรงกับเงื่อนไข</p>
    </div>

    <div v-else class="task-grid">
      <div 
        v-for="task in filteredTasks" 
        :key="task.id" 
        class="task-card"
        :class="`priority-${task.priority} status-${task.status}`"
      >
        <div class="task-header">
          <h3>{{ task.title }}</h3>
          <div class="task-actions">
            <button @click="editTask(task)" class="btn-icon">✏️</button>
            <button @click="deleteTask(task.id)" class="btn-icon">🗑️</button>
          </div>
        </div>
        
        <p class="task-description">{{ task.description }}</p>
        
        <div class="task-meta">
          <span class="status-badge" :class="task.status">
            {{ getStatusText(task.status) }}
          </span>
          <span class="priority-badge" :class="task.priority">
            {{ getPriorityText(task.priority) }}
          </span>
        </div>
        
        <div class="task-footer">
          <small v-if="task.dueDate">
            กำหนดส่ง: {{ formatDate(task.dueDate) }}
          </small>
          <router-link :to="`/tasks/${task.id}`" class="view-detail">
            ดูรายละเอียด →
          </router-link>
        </div>
      </div>
    </div>

    <!-- Create/Edit Modal -->
    <div v-if="showCreateModal || showEditModal" class="modal-overlay" @click="closeModal">
      <div class="modal" @click.stop>
        <h2>{{ showEditModal ? 'แก้ไขงาน' : 'เพิ่มงานใหม่' }}</h2>
        
        <form @submit.prevent="handleSubmit" class="task-form">
          <div class="form-group">
            <label>หัวข้อ *</label>
            <input 
              v-model="formData.title" 
              type="text" 
              required 
              placeholder="ใส่หัวข้องาน"
            />
          </div>
          
          <div class="form-group">
            <label>รายละเอียด</label>
            <textarea 
              v-model="formData.description" 
              placeholder="ใส่รายละเอียดงาน"
              rows="3"
            ></textarea>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label>สถานะ</label>
              <select v-model="formData.status">
                <option value="pending">รอดำเนินการ</option>
                <option value="in_progress">กำลังดำเนินการ</option>
                <option value="completed">เสร็จแล้ว</option>
              </select>
            </div>
            
            <div class="form-group">
              <label>ความสำคัญ</label>
              <select v-model="formData.priority">
                <option value="low">ต่ำ</option>
                <option value="medium">ปานกลาง</option>
                <option value="high">สูง</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <label>กำหนดส่ง</label>
            <input v-model="formData.dueDate" type="date" />
          </div>
          
          <div class="form-actions">
            <button type="button" @click="closeModal" class="btn btn-secondary">
              ยกเลิก
            </button>
            <button type="submit" class="btn btn-primary">
              {{ showEditModal ? 'อัปเดต' : 'สร้าง' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useTaskStore } from '@/stores/taskStore'
import { format } from 'date-fns'

const taskStore = useTaskStore()

const showCreateModal = ref(false)
const showEditModal = ref(false)
const editingTask = ref(null)
const statusFilter = ref('')
const priorityFilter = ref('')

const formData = ref({
  title: '',
  description: '',
  status: 'pending',
  priority: 'medium',
  dueDate: ''
})

const filteredTasks = computed(() => {
  let tasks = taskStore.tasks

  if (statusFilter.value) {
    tasks = tasks.filter(task => task.status === statusFilter.value)
  }

  if (priorityFilter.value) {
    tasks = tasks.filter(task => task.priority === priorityFilter.value)
  }

  return tasks
})

const { loading, error } = taskStore

onMounted(() => {
  taskStore.fetchTasks()
})

const editTask = (task) => {
  editingTask.value = task
  formData.value = { ...task }
  showEditModal.value = true
}

const closeModal = () => {
  showCreateModal.value = false
  showEditModal.value = false
  editingTask.value = null
  formData.value = {
    title: '',
    description: '',
    status: 'pending',
    priority: 'medium',
    dueDate: ''
  }
}

const handleSubmit = async () => {
  try {
    if (showEditModal.value) {
      await taskStore.updateTask(editingTask.value.id, formData.value)
    } else {
      await taskStore.createTask(formData.value)
    }
    closeModal()
  } catch (error) {
    console.error('Error submitting form:', error)
  }
}

const deleteTask = async (id) => {
  if (confirm('คุณแน่ใจหรือไม่ที่จะลบงานนี้?')) {
    try {
      await taskStore.deleteTask(id)
    } catch (error) {
      console.error('Error deleting task:', error)
    }
  }
}

const getStatusText = (status) => {
  const statusMap = {
    pending: 'รอดำเนินการ',
    in_progress: 'กำลังดำเนินการ',
    completed: 'เสร็จแล้ว'
  }
  return statusMap[status] || status
}

const getPriorityText = (priority) => {
  const priorityMap = {
    low: 'ต่ำ',
    medium: 'ปานกลาง',
    high: 'สูง'
  }
  return priorityMap[priority] || priority
}

const formatDate = (dateString) => {
  try {
    return format(new Date(dateString), 'dd/MM/yyyy')
  } catch {
    return dateString
  }
}
</script>

<style scoped>
.task-list {
  max-width: 1200px;
  margin: 0 auto;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.header h1 {
  margin: 0;
  color: #333;
}

.filters {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
}

.filter-select {
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
}

.loading, .error, .empty-state {
  text-align: center;
  padding: 2rem;
  color: #666;
}

.error {
  color: #dc3545;
}

.task-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
}

.task-card {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.task-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.task-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
}

.task-header h3 {
  margin: 0;
  color: #333;
  flex: 1;
}

.task-actions {
  display: flex;
  gap: 0.5rem;
}

.btn-icon {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 1.2rem;
  padding: 0.25rem;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.btn-icon:hover {
  background-color: #f8f9fa;
}

.task-description {
  color: #666;
  margin-bottom: 1rem;
  line-height: 1.5;
}

.task-meta {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.status-badge, .priority-badge {
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: bold;
}

.status-badge.pending {
  background-color: #fff3cd;
  color: #856404;
}

.status-badge.in_progress {
  background-color: #cce5ff;
  color: #004085;
}

.status-badge.completed {
  background-color: #d4edda;
  color: #155724;
}

.priority-badge.low {
  background-color: #e2e3e5;
  color: #383d41;
}

.priority-badge.medium {
  background-color: #fff3cd;
  color: #856404;
}

.priority-badge.high {
  background-color: #f8d7da;
  color: #721c24;
}

.task-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.9rem;
}

.view-detail {
  color: #667eea;
  text-decoration: none;
  font-weight: bold;
}

.view-detail:hover {
  text-decoration: underline;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.modal h2 {
  margin-bottom: 1.5rem;
  color: #333;
}

.task-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.form-group label {
  font-weight: bold;
  color: #333;
}

.form-group input,
.form-group textarea,
.form-group select {
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

.form-group textarea {
  resize: vertical;
  min-height: 80px;
}

.form-actions {
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 1rem;
}

.btn {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-primary {
  background-color: #667eea;
  color: white;
}

.btn-primary:hover {
  background-color: #5a6fd8;
}

.btn-secondary {
  background-color: #6c757d;
  color: white;
}

.btn-secondary:hover {
  background-color: #5a6268;
}
</style> 