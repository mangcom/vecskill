# vecskill — Personnel Evaluation System (ตัวอย่าง DevOps จริง)

โปรเจกต์ตัวอย่าง: Backend (Node.js/Express + MySQL ผ่าน Knex) + Frontend (Nuxt 3) +
MySQL, รันด้วย Docker Compose ทั้งหมด ใช้เป็นตัวอย่างประกอบการสอน CI/CD (ดู
`.gitlab-ci.yml`, `docker-compose.prod.yml`, โฟลเดอร์ `deploy/`)

## โครงสร้างโปรเจกต์

```
pes-main/
├── docker-compose.yml        # รัน dev: build จากซอร์สโค้ดตรง ๆ
├── docker-compose_mysql.yml  # ทางเลือก: รันแค่ db + phpMyAdmin (เผื่ออยาก dev backend/frontend ตรง ๆ โดยไม่ build image)
├── docker-compose.prod.yml   # รัน production: ดึง image สำเร็จรูปจาก registry
├── .gitlab-ci.yml            # Pipeline: test → build (dind) → deploy (ssh+rsync)
├── schema.sql                # สคริปต์สร้างตาราง + seed ข้อมูลตัวอย่าง
├── backend/                  # Node.js/Express API (พอร์ต 7000)
├── frontend/                 # Nuxt 3 (พอร์ต 3000)
└── deploy/                   # เทมเพลต .env ของ backend บน production
```

## เริ่มต้นใช้งาน (Quick Start)

### 1. สร้าง Docker network ที่ใช้ร่วมกัน

ทุก service ใน compose ไฟล์นี้ใช้ network ชื่อ `app_net` แบบ **external** (ไม่ได้
สร้างเองใน compose) เพราะในสภาพแวดล้อมจริงที่ใช้สอน network นี้ถูกสร้างไว้แล้ว
โดยสแตค GitLab/Runner (ดูบท "การติดตั้ง GitLab Runner") ถ้าคุณรันแค่โปรเจกต์นี้
เดี่ยว ๆ (ไม่มีสแตค GitLab) ให้สร้าง network เองครั้งแรกก่อน:

```powershell
docker network create app_net
```

ถ้า network มีอยู่แล้วคำสั่งนี้จะ error เฉย ๆ ข้ามไปได้เลย

### 2. ตั้งค่าไฟล์ environment (ไฟล์เดียวที่ root — ใช้ร่วมกันทั้ง frontend และ backend)

```powershell
cp .env.example .env
```

แก้ `JWT_SECRET` ตามต้องการ (ค่าอื่น ๆ ใช้ค่าเริ่มต้นได้เลยสำหรับ dev local)
ส่วน `NUXT_PUBLIC_API_BASE` ปกติ**ปล่อยว่างไว้**ได้เลย — frontend จะเดา URL
ของ backend เองจาก host ที่คุณใช้เปิดเว็บ (ดูหัวข้อ "เปิดผ่าน host อื่นที่ไม่ใช่
localhost" ด้านล่าง) ตั้งค่านี้เฉพาะกรณี backend อยู่คนละ host/port กับหน้าเว็บ
จริง ๆ เท่านั้น

> ไฟล์นี้ (`.env` ที่ root) ถูกใช้สองทาง: Docker Compose อ่านเพื่อแทนค่า
> `${...}` ในไฟล์ `docker-compose.yml` เอง (เช่น `NUXT_PUBLIC_API_BASE`) และ
> ถูกส่งต่อให้ container ของ backend ทั้งไฟล์ผ่าน `env_file:` (เช่น `DB_HOST`,
> `JWT_SECRET`) — เดิมค่าของ backend เคยแยกอยู่ที่ `backend/.env` คนละไฟล์
> ตอนนี้รวมเป็นไฟล์เดียวที่ root แล้ว

### 3. รันทั้งสแตค

```powershell
docker compose up -d --build
docker compose ps
```

ครั้งแรกใช้เวลานานกว่าปกติ เพราะ `backend` จะรอจน `db` ขึ้นสถานะ `healthy`
(MySQL กำลังโหลด `schema.sql`) ดูความคืบหน้าได้ด้วย `docker compose logs -f db`

### 4. เข้าใช้งาน

| บริการ | URL | หมายเหตุ |
|---|---|---|
| Frontend | http://localhost:3000 | หน้าเว็บหลัก — พอร์ตมาจาก `FRONTEND_PORT` ใน `.env` |
| Backend API + Docs | http://localhost:7000/docs | Swagger UI (ดู [backend/openapi.md](backend/openapi.md) สำหรับคำอธิบายทุก endpoint แบบอ่านง่าย) — พอร์ตมาจาก `BACKEND_PORT` ใน `.env` |
| phpMyAdmin | http://localhost:8080 | login: `root` / `rootpassword` |

แทน `localhost` ด้วย `127.0.0.1`, IP วง LAN (เช่น `192.168.100.102`), หรือ domain
จริง (เช่น `apps.vecskill.ovec`) ก็เปิดได้เหมือนกันโดยไม่ต้องแก้อะไร — ดูหัวข้อ
ถัดไป

ถ้า `3000`/`7000` ชนกับพอร์ตอื่นที่ใช้อยู่แล้วบนเครื่อง ให้แก้ `FRONTEND_PORT`/
`BACKEND_PORT` ใน `.env` เป็นพอร์ตอื่นได้เลย แล้ว `docker compose up -d --build`
ใหม่ — ไม่ต้องแก้ไฟล์โค้ดไหนเพิ่ม ทั้งสองค่า
นี้ไปโผล่ถูกที่หมดแล้ว (`docker-compose.yml`'s `ports:`, backend's `PORT` ที่
`server.js` อ่านจริง, และ `NUXT_PUBLIC_API_PORT` ที่ frontend ใช้ตอน
auto-detect URL ของ backend — ดูหัวข้อถัดไป)

### Demo login

ผู้ใช้ตัวอย่างทุกคน (seed ไว้ใน `schema.sql`) ใช้รหัสผ่านเดียวกัน:

```
admin@vecskill.ovec / 12345678
```

ผู้ใช้ตัวอย่างอื่น: `eva.it@vecskill.ovec`, `eva.me@vecskill.ovec`,
`t.it01@vecskill.ovec`, `t.me01@vecskill.ovec`, `t.acc01@vecskill.ovec`
(รหัสผ่านเดียวกันหมด)

## เปิดผ่าน host อื่นที่ไม่ใช่ localhost

Frontend เป็น SPA ล้วน (`ssr: false`) ดังนั้นทุกการเรียก API เกิดขึ้นจาก browser
โดยตรง — ไฟล์ `frontend/composables/useApiBase.js` จะเดา URL ของ backend จาก
`protocol://hostname` เดียวกับที่ browser ใช้เปิดหน้าเว็บ + พอร์ตของ backend
(ค่าจาก `NUXT_PUBLIC_API_PORT` ซึ่ง `docker-compose.yml` ตั้งให้ตรงกับ
`BACKEND_PORT` ใน `.env` อัตโนมัติ — ดีฟอลต์ `7000`) เสมอ ถ้าไม่ได้ตั้งค่า
`NUXT_PUBLIC_API_BASE` ไว้ ซึ่งหมายความว่า (ตัวอย่างใช้ `BACKEND_PORT=7000`
ค่าเริ่มต้น):

- เปิดผ่าน `http://127.0.0.1:3000` → เรียก backend ที่ `http://127.0.0.1:7000`
- เปิดผ่าน `http://192.168.100.102:3000` → เรียก backend ที่ `http://192.168.100.102:7000`
- เปิดผ่าน `http://apps.vecskill.ovec:3000` → เรียก backend ที่ `http://apps.vecskill.ovec:7000`

ใช้งานได้ทันทีโดยไม่ต้องแก้ไฟล์ใด ๆ ตราบใดที่ backend เปิดพอร์ตเดียวกับที่ตั้ง
`BACKEND_PORT` ไว้ อยู่ที่ host เดียวกับที่เปิด frontend จริง ๆ (ซึ่งเป็นกรณีปกติ
เมื่อรันด้วย `docker compose` บนเครื่องเดียว) — ถ้าเปลี่ยน `BACKEND_PORT` ใน
`.env` ทั้งสองฝั่งจะซิงก์ตามกันเองโดยไม่ต้องแก้ตรงนี้

> **เปิดด้วยชื่อโดเมน:** Dev server ของ frontend รับเฉพาะ localhost, IP และโดเมนที่
> ระบุไว้ใน `vite.server.allowedHosts` (`frontend/nuxt.config.ts` ตั้งไว้เป็น
> `.vecskill.ovec`) โดเมนอื่นจะได้ `403 Blocked request` ให้เพิ่มโดเมนแล้ว build
> image ใหม่ ส่วน production ต้องเพิ่ม URL นั้นใน `CORS_ORIGIN` ด้วย

ฝั่ง backend (`backend/app.js`) ตั้งค่า CORS ให้รับทุก origin เป็นค่าเริ่มต้น
(`CORS_ORIGIN` ว่างใน `.env` = อนุญาตทุก origin) เพื่อให้สอดคล้องกับพฤติกรรมนี้ —
ตั้งเจาะจงเฉพาะตอน deploy ขึ้น production จริงเท่านั้น (ดู
`deploy/.env.example`)

**ตั้งค่าด้วยมือเฉพาะกรณีจำเป็น** (เช่น backend อยู่หลัง reverse proxy คนละ
host/port กับหน้าเว็บ): ตั้ง `NUXT_PUBLIC_API_BASE` ในไฟล์ `.env` ที่ root (ดู
`.env.example`) แล้ว `docker compose up -d --build frontend` ใหม่

## รันเทส

มี 3 ระดับ แยกตามว่าทดสอบ "แค่ไหน" ของระบบ:

### 1. Backend — integration test (Vitest + Supertest)

```powershell
cd backend
npm test
```

ต้องมี container `db` รันอยู่และ seed ข้อมูลแล้ว (เทสต์ auth ยิงใส่ฐานข้อมูลจริง
ไม่ได้ mock เพราะ `auth.controller.js` คิวรี knex ตรง ๆ ไม่มี repository layer
ให้ mock) — ยิง request เข้า Express app โดยตรง ไม่ผ่านเบราว์เซอร์/frontend

หรือรันใน container (ไม่ต้องติดตั้ง Node.js บนเครื่อง):
`docker compose exec backend npm test`

### 2. Frontend — component test (Vitest + @vue/test-utils)

```powershell
cd frontend
npm test
```

mount แค่ component เดียว ๆ ใน jsdom (ไม่ต้องมี backend/ฐานข้อมูลจริง — mock
`useNuxtApp().$api` ไว้แทน ดู `frontend/tests/setup.ts`)

หรือ `docker compose exec frontend npm test`

### 3. E2E test (Playwright) — ทดสอบทั้งระบบรวมกันจริง

```powershell
cd frontend
npx playwright install chromium   # ครั้งแรกครั้งเดียว ดาวน์โหลด browser
npm run test:e2e
```

เปิด Chromium จริงไปที่ frontend ที่รันอยู่จริง ซึ่งคุยกับ backend + ฐานข้อมูล
จริงทั้งหมด (ไม่ mock อะไรเลย) — **ต้องมีสแตคทั้งหมดรันอยู่ก่อนเสมอ**
(`docker compose up -d`) ดูตัวอย่างและคำอธิบายละเอียดที่
[frontend/e2e/login.e2e.spec.ts](frontend/e2e/login.e2e.spec.ts) (ทดสอบ
login) และ [frontend/e2e/upload.e2e.spec.ts](frontend/e2e/upload.e2e.spec.ts)
(ทดสอบอัปโหลดไฟล์หลักฐานจนจบ workflow) — ใช้ `npm run test:e2e:ui` แทนถ้า
อยากเห็นขั้นตอนทำงานแบบ step-by-step ผ่านหน้าต่าง Playwright UI

## Deploy ขึ้น Production

ดูขั้นตอนทั้งหมด พร้อมวิธีตรวจสอบและแก้ปัญหา ในคู่มือหัวข้อ "การใช้งาน Gitlab CI/CD"
ที่ https://vecskill.bncc.ac.th/cicd

ค่าที่ตั้งไว้ในโปรเจกต์ (ถ้าระบบของคุณใช้ค่าอื่น ให้แก้ตามตารางนี้):

| ค่า | ตั้งไว้เป็น | แก้ที่ |
|---|---|---|
| Server 1 (GitLab, Runner, Caddy, Registry) | `10.20.30.101` | `/etc/hosts` บน Production |
| Production | `192.168.100.102` | `.gitlab-ci.yml` (`DEPLOY_HOST`) |
| URL ของ Frontend ที่อนุญาต (CORS) | `http://192.168.100.102:3000` | `/opt/vecskill/deploy/.env` |
| URL ของ Backend ที่ Browser เรียก | `http://192.168.100.102:7000` | `/opt/vecskill/.env.production` (pipeline สร้างจาก `DEPLOY_HOST` ให้ตอน deploy) |
| Registry สำหรับ build/push | `registry:5000` | CI/CD Variable `CI_REGISTRY` |
| Registry สำหรับ Production pull | `registry.vecskill.ovec` | ค่าเริ่มต้นใน `docker-compose.prod.yml` |

ไฟล์ secrets บนเครื่อง production (`/opt/vecskill/.env.production`,
`/opt/vecskill/deploy/.env`) ต้องสร้างด้วยมือครั้งเดียว **ก่อน push ครั้งแรก**
ไม่ได้ส่งผ่าน git หรือ pipeline (ดูเทมเพลตในไฟล์ `.example`)
