// app.js
//
// ไฟล์นี้คือ "แกนกลาง" ของ backend — มีหน้าที่สร้าง Express application แล้ว
// ประกอบร่างทุกอย่างเข้าด้วยกัน: middleware ของ Express เอง (cors, body
// parser, logger), เส้นทาง static ไฟล์ (รูป/เอกสารที่อัปโหลด), หน้า Swagger
// API docs, และสุดท้ายคือ route ของแต่ละโมดูล (auth, users, upload,
// attachments) ก่อนจะ export ตัว app ออกไปให้ server.js เอาไปสั่ง .listen()
//
// ลำดับการ app.use(...) ในไฟล์นี้ "มีผลจริง" — Express จะไล่เช็กทีละ
// middleware/route จากบนลงล่างตามลำดับที่เขียนในไฟล์นี้ ใครเจอ route ที่ตรง
// ก่อนก็จะตอบกลับก่อน (ไม่ไล่ต่อ เว้นแต่เรียก next()) ดังนั้นลำดับทั่วไปที่ถูกต้อง
// คือ: middleware พื้นฐาน (cors/json) -> static files -> route เฉพาะทาง ->
// 404 handler (ต้องอยู่ "ล่างสุด" เพราะมันจับทุก path ที่เหลือ) -> error handler
// (ต้องอยู่ "ล่างสุดจริง ๆ" เพราะ Express รู้จัก error-handling middleware จาก
// การมี 4 พารามิเตอร์ (err, req, res, next))

const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const path = require("path");
const dotenv = require("dotenv");
const attachmentsApi = require("./routes/attachments");   // route ของ period/indicator/attachment (ดูคอมเมนต์ด้านล่าง)
// Swagger — ใช้สร้างหน้าเอกสาร API แบบอ่านง่าย ทดลองยิง request ได้จากหน้าเว็บ
const swaggerUi = require("swagger-ui-express");
const fs = require("fs");

dotenv.config({ path: path.resolve(__dirname, "../.env") });
// โหลดค่าจากไฟล์ .env ที่ root ของโปรเจกต์เข้า process.env (ไม่ใช่
// backend/.env แยกต่างหากเหมือนเดิม — ดูคอมเมนต์ใน db/knex.js ประกอบ) เผื่อ
// ไฟล์นี้ถูก require ตรง ๆ โดยไม่ผ่าน server.js เช่นตอนรัน test — กันพลาด
// กรณี .env ยังไม่ถูกโหลด

const app = express();
// สร้าง Express application ตัวจริงขึ้นมา ทุกอย่างข้างล่างคือการ "ต่อเติม"
// ความสามารถให้กับตัวแปร app ตัวนี้

app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : '*' }));
// เปิดใช้ CORS (Cross-Origin Resource Sharing) — จำเป็นเพราะ frontend (Nuxt,
// พอร์ต 3000) กับ backend (พอร์ต 7000) ถือเป็นคนละ origin กันในสายตาเบราว์เซอร์
// ถ้าไม่เปิด CORS เบราว์เซอร์จะบล็อก request ข้าม origin ทั้งหมด
// - ถ้าตั้งค่า CORS_ORIGIN ไว้ใน .env (คั่นด้วยคอมมาได้หลายโดเมน) จะอนุญาตเฉพาะ
//   โดเมนที่ระบุเท่านั้น (เหมาะกับ production ที่รู้โดเมนจริงแน่นอนแล้ว)
// - ถ้า CORS_ORIGIN ว่างไว้ (ค่าเริ่มต้นตอน dev) จะ fallback เป็น '*' คือ
//   "อนุญาตทุก origin" ซึ่งจำเป็นสำหรับ template นี้ เพราะ frontend ต้องเปิดได้
//   จากหลาย host (localhost, 127.0.0.1, IP วง LAN, โดเมนจริง) โดยไม่ต้องมานั่ง
//   แก้ไฟล์ .env ทุกครั้งที่เปลี่ยน host (ดู frontend/composables/useApiBase.js)
// app.use(cors());
app.use(express.urlencoded({ extended: true }));  // ใส่คู่กับ express.json()
// express.urlencoded(...) ทำให้ Express อ่าน body แบบ
// application/x-www-form-urlencoded ได้ (เช่น ฟอร์ม HTML ธรรมดาที่ไม่ใช่ JSON)
// { extended: true } ใช้ไลบรารี qs แปลง body แบบซับซ้อน (object/array ซ้อนกัน)
// ได้ด้วย ไม่ใช่แค่ key=value ธรรมดา
app.use(express.json());
// express.json() ทำให้ Express แปลง body ที่ส่งมาเป็น JSON (Content-Type:
// application/json) ให้กลายเป็น req.body (object ธรรมดาใน JavaScript) อัตโนมัติ
// ถ้าไม่มีบรรทัดนี้ req.body จะเป็น undefined ตลอดเวลาที่ frontend ส่ง JSON มา
app.use(morgan("dev"));
// morgan คือ HTTP request logger — โหมด "dev" จะพิมพ์แต่ละ request ที่เข้ามา
// ออกทาง console แบบสั้น ๆ มีสี (METHOD path status เวลาที่ใช้) มีประโยชน์มาก
// ตอน dev เพราะเห็นได้ทันทีว่า frontend ยิง request อะไรมาบ้าง และได้ status
// อะไรกลับไป
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
// express.static(...) ทำให้โฟลเดอร์ backend/uploads/ ถูกเปิดให้เข้าถึงไฟล์
// ข้างในได้ตรง ๆ ผ่าน URL เช่น http://host:7000/uploads/1/4/xxx.pdf
// (path.join(__dirname, "uploads") คือ path แบบ absolute ไปยังโฟลเดอร์
// backend/uploads/ ไม่ว่าจะรันจากที่ไหนก็ตาม) — ไฟล์หลักฐาน (evidence) ที่
// ผู้ใช้อัปโหลดผ่านหน้า /upload จะถูกเก็บไว้ที่นี่ แล้วให้ frontend ดึงรูป/ไฟล์
// มาแสดงผ่าน URL แบบนี้ได้เลยโดยไม่ต้องผ่าน API endpoint พิเศษ
app.use("/public", express.static(path.join(__dirname, "public")));
// เช่นเดียวกับด้านบน แต่สำหรับไฟล์สาธารณะทั่วไป (ไม่ผูกกับระบบอัปโหลดหลักฐาน)

// Health
//http://localhost:7000/health
app.get("/health", (req, res) => {
  // endpoint สำหรับเช็กว่า server ยังมีชีวิตอยู่ไหม (health check) นิยมใช้คู่กับ
  // Docker healthcheck หรือ monitoring tool เรียกเช็กเป็นระยะ ๆ
  res.json({ service: "vecskill-backend", time: new Date().toISOString() });
});

// ให้ /openapi.json ส่งไฟล์จริงแบบ no-store เพื่อไม่ให้แคช
app.get("/openapi.json", (req, res) => {
  // openapi.json คือไฟล์สเปก (ข้อกำหนด) ของ API ทั้งหมดในรูปแบบ OpenAPI —
  // Swagger UI (ด้านล่าง) จะมาอ่านไฟล์นี้เพื่อสร้างหน้าเอกสารแบบ interactive
  res.set("Cache-Control", "no-store");
  // สั่งเบราว์เซอร์/proxy ว่า "ห้ามแคช" ไฟล์นี้ไว้ เพราะถ้าแก้ openapi.json แล้ว
  // อยาก reload หน้า /docs ให้เห็นของใหม่ทันที ไม่อยากให้มันไปอ่านไฟล์แคชเก่า
  res.sendFile(path.join(__dirname, "openapi.json"));
  // ส่งไฟล์ backend/openapi.json ตรง ๆ ไปเป็น response (res.sendFile จัดการ
  // เรื่อง Content-Type ให้อัตโนมัติจากนามสกุลไฟล์)
});

// ให้ Swagger UI ไปดึงสเปกจาก URL ด้านบน (สดใหม่เสมอ)
app.use(
  "/docs",
  swaggerUi.serve,
  // swaggerUi.serve คือ middleware ชุดที่ทำหน้าที่ส่งไฟล์ static ของหน้า
  // Swagger UI (HTML/CSS/JS ของตัว UI เอง) ให้เบราว์เซอร์
  swaggerUi.setup(null, {
    // swaggerUi.setup(spec, options) ปกติจะรับ spec (object ข้อมูล API) ไป
    // แสดงตรง ๆ แต่ที่นี่ส่ง null แล้วบอกให้ไปดึงจาก swaggerOptions.url แทน
    // เหตุผล: ถ้าฝัง spec ไว้ตรง ๆ ตอน server เริ่มทำงาน การแก้ openapi.json
    // ภายหลังจะไม่มีผล (ต้อง restart server) แต่พอให้ไปดึงจาก URL /openapi.json
    // ทุกครั้งที่เปิดหน้า /docs จะได้ข้อมูลล่าสุดเสมอแม้ server จะไม่ได้ restart
    swaggerOptions: { url: "/openapi.json" },
  })
);
// ผลลัพธ์: เปิด http://host:7000/docs จะเห็นหน้าเอกสาร API พร้อมปุ่ม "Try it
// out" ทดลองยิง request จริงได้จากในหน้าเว็บเลย

const userRoutes = require("./routes/users.routes");
const authRoutes = require("./routes/auth.routes");
const uploadRoutes = require("./routes/upload.routes");

// http://localhost:7000/api/auth/login
// app.use('/api/auth', require('./routes/auth.routes'));
app.use("/api/auth", authRoutes);
// ทุก route ที่ประกาศไว้ใน routes/auth.routes.js จะถูก "ติด prefix" เป็น
// /api/auth นำหน้าทั้งหมด เช่นถ้าในไฟล์นั้นมี router.post('/login', ...) จริง ๆ
// แล้วมันจะตอบที่ POST /api/auth/login
// http://localhost:7000/api/users
app.use("/api/users", userRoutes);
// เช่นเดียวกัน route ทั้งหมดใน routes/users.routes.js จะขึ้นต้นด้วย /api/users
// http://localhost:7000/api/upload
app.use("/api/upload", uploadRoutes);
// route ทั้งหมดใน routes/upload.routes.js จะขึ้นต้นด้วย /api/upload
// (เอาไว้สำหรับฝั่ง evaluatee/evaluator อัปโหลด/จัดการไฟล์หลักฐานของตัวเอง
// แยกจาก /api/attachments ด้านล่างซึ่งเป็นอีกชุด endpoint ของเรื่องเดียวกัน
// ที่ผู้พัฒนาเดิมเขียนไว้คู่ขนานกัน — ตอนนี้ frontend หน้า /upload เรียกใช้
// /api/attachments จริง ส่วน /api/upload/* ยังมีให้ใช้งานได้เช่นกัน)
// จะได้ /api/periods/active, /api/indicators, ...

// << เส้นทางสำหรับ Period/Indicator/EvidenceType และ POST /attachments
app.use("/api", attachmentsApi);           // จะได้ /api/periods/active, /api/indicators, ...
// route ทั้งหมดใน routes/attachments.js จะขึ้นต้นด้วย /api เฉย ๆ (ไม่มี
// prefix เฉพาะเจาะจงเหมือนด้านบน) ไฟล์นั้นจึงกำหนด path เต็มของตัวเองไว้ เช่น
// '/periods/active', '/indicators', '/attachments' ผลลัพธ์คือ
// GET /api/periods/active, GET /api/indicators, POST /api/attachments ฯลฯ


app.use((req, res, next) => {
  // middleware นี้ไม่มี path ระบุไว้ (app.use เฉย ๆ) แปลว่ามันจะถูกเรียกกับ
  // "ทุก request ที่ไหลลงมาถึงตรงนี้" ซึ่งจะเกิดขึ้นก็ต่อเมื่อไม่มี route ไหน
  // ด้านบนตอบ request นั้นเลย (ไม่ match ทั้ง path และ method) — เพราะมันอยู่
  // ล่างสุดในบรรดา route ปกติ จึงทำหน้าที่เป็น "catch-all 404 handler"
  res.status(404).json({ success: false, message: "ไม่พบหน้านี้" });
});

// Error handler
const error = require("./middlewares/error");
app.use(error);
// Express จะรู้ว่า middleware ตัวไหนเป็น "error handler" จากการที่ฟังก์ชันนั้น
// รับพารามิเตอร์ 4 ตัว (err, req, res, next) — ตัวนี้ต้องประกาศเป็นตัวสุดท้าย
// เสมอ เพราะเมื่อใดก็ตามที่ route/middleware ด้านบนเรียก next(err) (หรือโยน
// exception ออกมาในฟังก์ชัน async ที่มี try/catch ครอบไว้) Express จะข้าม
// middleware ปกติทั้งหมดที่เหลือ แล้วกระโดดมาที่ error handler ตัวนี้ทันที
// console.log(module);// Debug: log the module object to see its properties

module.exports = app;
// ส่งออกตัว app ที่ประกอบร่างเสร็จสมบูรณ์แล้ว ให้ server.js เอาไปสั่ง .listen()
// (หรือให้ไฟล์ test เอาไปยิง request ทดสอบตรง ๆ โดยไม่ต้องเปิดพอร์ตจริง)
