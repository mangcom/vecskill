// controllers/auth.controller.js
// เวอร์ชันสอนนักศึกษา: routes -> controller -> knex (ไม่มี repository ชั้นกลาง)
//
// ไฟล์นี้มีหน้าที่เดียว: ตรวจสอบ email/password ที่ส่งมา แล้วถ้าถูกต้อง
// ให้ออก JWT (JSON Web Token) กลับไปให้ฝั่ง frontend เก็บไว้ใช้แนบไปกับทุก
// request ถัดไปที่ต้อง login (ดู middlewares/auth.js ฝั่งที่ตรวจสอบ token
// และ frontend/plugins/axios.client.js ฝั่งที่แนบ token ไปกับ request)
//
// ทำไมเขียนคุย DB ตรง ๆ ในไฟล์นี้ ไม่แยกเป็น repository เหมือนบางโมดูล?
// เพื่อให้เห็นภาพง่าย ๆ ของเส้นทางข้อมูลแบบสั้นที่สุด: HTTP request ->
// controller -> ฐานข้อมูล -> ตอบกลับ เหมาะกับคนเริ่มต้นที่ยังไม่คุ้นกับแพทเทิร์น
// repository (เทียบกับ controllers/upload.controller.js ที่แยกไปใช้
// repositories/*.js แทน จะเห็นความต่างของสองแนวทางได้ชัดเจน)

const db = require("../db/knex");  // ใช้ knex ต่อ DB โดยตรง
const jwt = require("jsonwebtoken");
// ไลบรารีสร้าง/ตรวจสอบ JWT — jwt.sign(...) ใช้ "สร้าง" token (ตรงข้ามกับ
// jwt.verify(...) ใน middlewares/auth.js ที่ใช้ "ตรวจสอบ" token)
const bcrypt = require("bcrypt");
// ไลบรารีสำหรับ hash รหัสผ่าน (เข้ารหัสทางเดียว ถอดกลับไม่ได้) — ฐานข้อมูล
// ไม่เคยเก็บรหัสผ่านจริงเป็นตัวหนังสือเปล่า ๆ (plaintext) เลย เก็บแต่ค่าที่
// hash แล้ว (คอลัมน์ password_hash) ถ้าใครขโมยฐานข้อมูลไปก็ยังไม่รู้รหัสผ่าน
// จริงของใครเลย

// ช่วย: เลือกฟิลด์ที่จะส่งกลับ (อย่าส่ง password_hash)
const pickPublic = (row) =>
  row && ({ id: row.id, name: row.name_th, email: row.email, role: row.role });
// ฟังก์ชันเล็ก ๆ ที่รับแถวผู้ใช้เต็ม ๆ จากฐานข้อมูล (ที่มี password_hash ติด
// มาด้วย) แล้วคัดเฉพาะฟิลด์ที่ "ปลอดภัยที่จะส่งกลับไปให้ client เห็น" เท่านั้น
// — `row && (...)` คือการเช็กก่อนว่า row มีค่าจริงไหม (ไม่ใช่ null/undefined)
// ถ้า row เป็น falsy จะคืนค่า row นั้นกลับไปตรง ๆ (เช่น undefined) แทนที่จะ
// พยายามเข้าถึง row.id แล้ว error เพราะ row เป็น undefined

/**
 * POST /api/auth/login
 * body: { email, password }
 * 200: { success:true, accessToken, user:{ id,name,email,role } }
 * 400: ข้อมูลไม่ครบ
 * 401: อีเมล/รหัสผ่านไม่ถูกต้อง
 */
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    // destructure email/password จาก body — `req.body || {}` กันกรณี
    // req.body เป็น undefined ไปเลย (เช่นลืมตั้ง express.json() middleware)
    // ไม่งั้นจะ error ตอนพยายาม destructure จาก undefined
    if (!email || !password) {
      // เช็กว่าส่งมาครบทั้งสองฟิลด์ไหม ถ้าขาดอันใดอันหนึ่งให้ตอบ 400 (Bad
      // Request = client ส่งข้อมูลมาไม่ครบ/ไม่ถูกต้อง) ทันที ไม่ต้องไปคิวรี
      // ฐานข้อมูลให้เสียเวลาเปล่า
      return res
        .status(400)
        .json({ success: false, message: "email and password required" });
    }

    // 1) ค้นผู้ใช้จากอีเมล (ต้องดึง password_hash มาด้วย เพื่อตรวจรหัสผ่าน)
    const user = await db("users")
      .select("id", "name_th", "email", "role", "password_hash")
      // ต้อง select password_hash มาด้วยตรงนี้ (ทั้งที่สุดท้ายจะไม่ส่งออกไป
      // ให้ client เห็น) เพราะต้องใช้มันเปรียบเทียบกับรหัสผ่านที่ผู้ใช้กรอก
      // มาในขั้นตอนถัดไป
      .where({ email })
      .first();
      // ดึงผู้ใช้แถวแรกที่ email ตรงกัน (email ควรเป็น unique อยู่แล้วตาม
      // schema.sql จึงมีได้แค่แถวเดียวพอดี)

    if (!user) {
      // ไม่เจอผู้ใช้ที่ email นี้เลยในฐานข้อมูล
      return res
        .status(401)
        .json({ success: false, message: "Invalid credentials-email" });
      // 401 Unauthorized = ยืนยันตัวตนไม่สำเร็จ หมายเหตุด้านความปลอดภัย:
      // ข้อความ "Invalid credentials-email" นี้บอกชัดเจนเกินไปว่า "ปัญหาคือ
      // อีเมล" (ต่างจากที่ด้านล่างบอกว่า "ปัญหาคือรหัสผ่าน") ระบบจริงที่
      // เข้มงวดเรื่องความปลอดภัยมักจะใช้ข้อความเดียวกันทั้งสองกรณี (เช่น
      // "Invalid credentials" เฉย ๆ) เพื่อไม่ให้ผู้ไม่หวังดีรู้ได้ว่า "อีเมลนี้
      // มีอยู่จริงในระบบไหม" จากการลองผิดลองถูก (เรียกว่า user enumeration)
      // — ในตัวอย่างนี้แยกข้อความไว้เพื่อให้เห็นภาพตอนเรียนรู้ง่ายกว่า
    }

    // 2) เปรียบเทียบรหัสผ่าน
    const ok = await bcrypt.compare(password, user.password_hash);
    // bcrypt.compare(plaintext, hash) จะ hash ค่า plaintext (รหัสผ่านที่
    // ผู้ใช้เพิ่งกรอกมา) ด้วยวิธีเดียวกับตอนสร้าง hash เดิม แล้วเทียบผลลัพธ์
    // กับ hash ที่เก็บไว้ในฐานข้อมูล คืนค่า true/false — ไม่มีการถอดรหัส
    // password_hash กลับมาเป็นตัวหนังสือจริงเลย (ทำไม่ได้ เพราะ hash เป็น
    // การเข้ารหัส "ทางเดียว")
    if (!ok) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid credentials-password" });
    }

    // 3) สร้าง JWT
    const token = jwt.sign(
      { id: user.id, role: user.role, name: user.name_th }, // payload
      // payload คือข้อมูลที่จะ "ฝัง" ไว้ในตัว token เอง (ไม่ได้เข้ารหัสลับ
      // แบบอ่านไม่ออก แค่เซ็นลายเซ็นกันการปลอมแปลง — ใครก็ถอด payload ออกมา
      // อ่านได้ถ้ามี token แต่จะปลอม/แก้ไขค่าข้างในแล้วให้ผ่านการตรวจสอบไม่ได้
      // ถ้าไม่รู้ JWT_SECRET) ใส่แค่ข้อมูลที่จำเป็นต้องใช้บ่อย ๆ (id, role,
      // name) ไม่ใส่ข้อมูลอ่อนไหว เช่น password_hash ลงไปเด็ดขาด
      process.env.JWT_SECRET,                                // ความลับจาก .env
      // กุญแจลับที่ใช้เซ็น token — ต้องเป็นค่าเดียวกับที่ middlewares/auth.js
      // ใช้ตอน verify ทุกครั้งที่มี request เข้ามา ถ้าค่านี้หลุดไปถึงมือคนอื่น
      // เขาจะปลอม token เป็นใครก็ได้ในระบบ จึงต้องเก็บเป็นความลับใน .env
      // เท่านั้น ห้าม commit ขึ้น git
      { expiresIn: process.env.JWT_EXPIRES || "1h" }         // อายุโทเค็น
      // กำหนดว่า token นี้จะหมดอายุเมื่อไหร่ (เช่น "2h" = 2 ชั่วโมง) หลังจาก
      // หมดอายุ jwt.verify() ฝั่ง middlewares/auth.js จะ throw error
      // (TokenExpiredError) ทำให้ผู้ใช้ต้อง login ใหม่ — การจำกัดอายุ token
      // ไว้สั้น ๆ ช่วยลดความเสียหายถ้า token หลุดไปอยู่ในมือคนอื่น
    );

    // 4) ส่งผลลัพธ์ (อย่าส่ง password_hash ออกไป)
    return res.json({
      success: true,
      accessToken: token,
      // ส่ง token กลับไปให้ frontend เก็บไว้ (ดู frontend/stores/auth.js ว่า
      // เก็บไว้ที่ไหน และ frontend/plugins/axios.client.js ว่าหยิบมาแนบกับ
      // request ยังไง)
      user: pickPublic(user),
      // ใช้ pickPublic (ฟังก์ชันด้านบนของไฟล์) กรองเอาเฉพาะฟิลด์ที่ปลอดภัย
      // ออกไป ไม่ส่ง password_hash ติดไปด้วยโดยไม่ได้ตั้งใจ
    });
  } catch (e) {
    next(e); // ให้ error handler กลางจัดการ
    // ถ้ามี error ที่ไม่คาดคิด (เช่น ต่อฐานข้อมูลไม่ได้) เกิดขึ้นระหว่าง
    // try block ด้านบน จะถูกดักด้วย catch นี้ แล้วส่งต่อให้
    // middlewares/error.js เป็นคนตอบ response สุดท้ายแทน (ดูรายละเอียดที่
    // ไฟล์นั้น)
  }
};
// หมายเหตุ: ในระบบจริง ควรมีการล็อกกิจกรรมการล็อกอิน (login audit) ด้วย
// เช่น บันทึกว่าใคร login สำเร็จ/ไม่สำเร็จ เมื่อไหร่ จาก IP ไหน เพื่อใช้
// ตรวจสอบความปลอดภัยย้อนหลังได้ (ตัวอย่างนี้ยังไม่ได้ทำส่วนนี้)
