// controllers/upload.controller.js
//
// Controller ของชุด endpoint /api/upload/* (ดู routes/upload.routes.js) —
// ต่างจาก controllers/auth.controller.js และ users.controller.js ที่คุยกับ
// ฐานข้อมูลตรง ๆ ผ่าน knex ไฟล์นี้ "แยกชั้น repository" ออกมาใช้ (attRepo,
// asgRepo, mapRepo ด้านล่าง) ทำให้เห็นตัวอย่างแนวทางที่ต่างออกไป — เหมาะกับ
// การเทียบดูว่าแบบไหนอ่านง่ายกว่ากัน/ดูแลง่ายกว่ากันเมื่อโปรเจกต์โตขึ้น

const path = require('path');
const fs = require('fs');
const attRepo = require('../repositories/attachments');
const asgRepo = require('../repositories/assignments');
const mapRepo = require('../repositories/indicatorEvidence');
const db = require('../db/knex');
// หมายเหตุ: แม้จะ import repository มาใช้แล้ว ไฟล์นี้ก็ยัง import db (knex)
// มาคิวรีตรง ๆ เพิ่มเติมในบางจุดด้วย (เช่น isPeriodActive ด้านล่าง) ไม่ได้
// ผ่าน repository 100% ทุกจุด — เป็นเรื่องปกติในโปรเจกต์จริงที่ค่อย ๆ ทยอย
// ปรับโครงสร้างไปเรื่อย ๆ ไม่จำเป็นต้อง "เนี้ยบ" ตามแพทเทิร์นเดียวทุกจุดเป๊ะ ๆ

// ---------- helpers ----------
function safeUnlink(abs) {
  // ฟังก์ชันช่วยลบไฟล์แบบ "ปลอดภัย" (ไม่ throw error ออกมาแม้ลบไม่สำเร็จ)
  try { if (fs.existsSync(abs)) fs.unlinkSync(abs); } catch {}
  // เช็กก่อนว่าไฟล์ยังมีอยู่จริงไหม (fs.existsSync) ก่อนจะสั่งลบ (fs.unlinkSync)
  // — เผื่อกรณีไฟล์ถูกลบไปแล้วด้วยเหตุผลอื่น (เช่นโดนลบมือจากนอกระบบ) การลบ
  // ไฟล์ที่ไม่มีอยู่แล้วจะทำให้ error ถ้าไม่เช็กก่อน catch {} ว่างเปล่าด้านท้าย
  // คือ "ถ้ายังไงก็ error อีกจนได้ ก็เงียบไปเลย ไม่ต้องทำอะไรต่อ" เพราะการลบ
  // ไฟล์แนบเป็นแค่ "งานทำความสะอาด" ไม่ใช่งานหลัก ถ้าพลาดก็ไม่ควรทำให้
  // request ทั้งหมด error ไปด้วย
}
function relFromUploads(absPath) {
  // ให้ได้ path แบบ relative ต่อโฟลเดอร์ uploads และใช้ slash เดียว
  return path
    .relative(path.join(__dirname, '..', 'uploads'), absPath)
    // path.relative(from, to) คำนวณ "เส้นทางสัมพัทธ์" จากโฟลเดอร์ from ไปยัง
    // to เช่นถ้า absPath คือ backend/uploads/1/4/x.pdf (แบบ absolute) และ
    // from คือ backend/uploads จะได้ผลลัพธ์เป็น "1/4/x.pdf" เท่านั้น — เก็บ
    // เป็น relative path ไว้ในฐานข้อมูล (ไม่เก็บ absolute path เต็ม ๆ) เพื่อ
    // ให้ย้ายโปรเจกต์ไปรันที่เครื่องอื่น/โฟลเดอร์อื่นแล้วยังหาไฟล์เจอ (ไม่ผูก
    // ติดกับ path เฉพาะเครื่องใดเครื่องหนึ่ง) แล้วค่อยเอาไปต่อกับ
    // "/uploads/" ตอนสร้าง URL ให้ frontend เรียกดู (ดู app.js ที่เปิด
    // /uploads เป็น static folder)
    .replace(/\\/g, '/');
    // บน Windows path.relative จะคืนค่าด้วย backslash (\) คั่นแต่ละชั้น
    // โฟลเดอร์ (เช่น "1\4\x.pdf") แต่ URL ต้องใช้ forward slash (/) เสมอ
    // (เช่น "1/4/x.pdf") จึงต้องแทนที่ \ ทั้งหมดด้วย / ก่อนเก็บ ไม่งั้นถ้า
    // สร้าง/รันบน Windows แล้วเก็บ path แบบ \ ไว้ จะเปิดไฟล์ผ่าน URL ไม่ได้
}
async function isPeriodActive(period_id) {
  const row = await db('evaluation_periods').where({ id: period_id, is_active: 1 }).first();
  // return row or undefined หมายความว่า period_id ที่ส่งมา ต้องเป็นเลข และต้องมีในตาราง evaluation_periods และ is_active=1  เพื่อให้ period นั้นเปิดอยู่
  return !!row;
  // ฟังก์ชันนี้ถูกเรียกซ้ำหลายจุดในไฟล์นี้ (อัปโหลด, ลบ, แก้ไข) เพราะทุก
  // การกระทำกับไฟล์หลักฐานต้อง "เกิดขึ้นได้เฉพาะตอนรอบประเมินยังเปิดอยู่
  // เท่านั้น" — ถ้ารอบประเมินถูกปิดไปแล้ว (is_active = 0) จะแก้ไข/ลบ/อัปโหลด
  // เพิ่มไม่ได้อีก (ข้อมูลถูก "ล็อก" ไว้ตามรอบที่ปิดไปแล้ว)
}

// =====================================================================
// Evaluatee: CREATE (อัปโหลดหลักฐานของตัวเอง)
// Body: { period_id, indicator_id, evidence_type_id } + file
// =====================================================================
exports.uploadEvidence = async (req, res, next) => {
  console.log('uploadEvidence body=', req.body);
  console.log('uploadEvidence file=', req.file);
  console.log('uploadEvidence user=', req.user);
  console.log('uploadEvidence user.id=', req.user?.id);
  console.log('uploadEvidence user.role=', req.user?.role);
  console.log('uploadEvidence user.email=', req.user?.email);
  // log ไว้หลายบรรทัดแบบนี้เพื่อช่วย debug ตอนพัฒนา (เห็นชัดเจนว่า request
  // ที่เข้ามามีอะไรบ้าง) ในระบบ production จริงอาจพิจารณาลด log ที่มีข้อมูล
  // ผู้ใช้ละเอียดขนาดนี้ลง หรือใช้ระบบ logging ที่ควบคุม log level ได้
  try {
    const evaluatee_id = Number(req.user?.id);// ต้องมี user.id จาก JWT เสมอ  return 401 ถ้าไม่มี   ถ้ามี return 400
        if (!evaluatee_id) return res.status(401).json({ success:false, message:'invalid user' });
    // endpoint นี้ถูกครอบด้วย middleware auth('evaluatee') อยู่แล้ว (ดู
    // routes/upload.routes.js) จึงไม่น่าเกิดกรณีไม่มี req.user เลย แต่เช็กไว้
    // กันเหนียวอีกชั้น — Number(undefined) จะได้ NaN ซึ่งเป็น falsy เหมือน 0
    // ทำให้เงื่อนไข !evaluatee_id ตรวจจับได้ทั้งสองกรณี (ไม่มี id เลย หรือ id
    // แปลงเป็นตัวเลขไม่ได้)
    const { period_id, indicator_id, evidence_type_id } = req.body || {};

    if (!req.file) return res.status(400).json({ success:false, message:'ไม่ได้ส่ง file มาด้วย' });
    // req.file ถูกเติมโดย middleware upload.single('file') (multer) — ถ้า
    // ไม่มีเลยแปลว่า client ไม่ได้แนบไฟล์มาในฟอร์ม (หรือตั้งชื่อ fieldผิด)
    if (!period_id || !indicator_id || !evidence_type_id) {
      return res.status(400).json({ success:false, message:'missing period_id/indicator_id/evidence_type_id' });
    }

    // ต้องถูก assign ใน period นั้น
    const okAssign = await asgRepo.hasEvaluateeInPeriod({  //return true/false
      period_id: Number(period_id),
      evaluatee_id
    });
    if (!okAssign) return res.status(400).json({ success:false, message:'evaluatee not assigned in the period' });
    // เรียกใช้ repository แทนที่จะเขียนคิวรีตรง ๆ ในไฟล์นี้ (ต่างจาก
    // routes/attachments.js ที่เขียนคิวรีแบบเดียวกันนี้ซ้ำไว้ตรง ๆ โดยไม่
    // ผ่าน repository — เทียบดูสองไฟล์นี้จะเห็นข้อดีของการมี repository
    // ชัดเจน: logic การเช็กสิทธิ์อยู่ที่เดียว ไม่ต้องแก้หลายที่ถ้าเปลี่ยนกฎ)

    // period ต้องเปิดอยู่
    if (!(await isPeriodActive(Number(period_id)))) {  //คือ period_id ที่ส่งมา ต้องเป็นเลข และต้องมีในตาราง evaluation_periods และ is_active=1
      //isPeriodActive return true/false
      return res.status(403).json({ success:false, message:'period closed' });
    }

    // mapping indicator-evidence_type ต้องถูกต้อง (มีในตาราง indicator_evidence)หรือไม่
    const okMap = await mapRepo.mapExists({
      indicator_id: Number(indicator_id),
      evidence_type_id: Number(evidence_type_id)
    });
    if (!okMap) return res.status(400).json({ success:false, message:'invalid indicator/evidence_type pair' });
    // บันทึกลงตาราง attachments
    // console.log('req.file.path=', req.file.path);
    const storage_path = relFromUploads(req.file.path);
    // แปลง path เต็ม ๆ ที่ multer เก็บไฟล์ไว้จริง (req.file.path เป็น
    // absolute path) ให้กลายเป็น relative path ก่อนเก็บลงฐานข้อมูล (ดู
    // เหตุผลในฟังก์ชัน relFromUploads ด้านบน) — ต่างจาก routes/attachments.js
    // ที่เก็บ req.file.path (absolute) ลงฐานข้อมูลตรง ๆ โดยไม่แปลง (เป็นจุดที่
    // สองเส้นทางอัปโหลดในระบบนี้ทำไม่เหมือนกัน ดังที่กล่าวไว้ในคอมเมนต์ของ
    // routes/attachments.js)
    console.log('storage_path=', storage_path);
    const [id] = await db('attachments').insert({
      period_id: Number(period_id),
      evaluatee_id,
      indicator_id: Number(indicator_id),
      evidence_type_id: Number(evidence_type_id),
      file_name: req.file.originalname,
      mime_type: req.file.mimetype,
      size_bytes: req.file.size,
      storage_path
    });

    const created = await attRepo.findById(id);
    res.status(201).json({ success:true, data: { ...created, url: `/uploads/${created.storage_path}` }});
    // ใส่ฟิลด์ url เพิ่มเข้าไปใน response (ไม่ได้เก็บไว้ในฐานข้อมูล สร้างสด
    // ตอนตอบ response นี่แหละ) โดยต่อ "/uploads/" (path ที่ app.js เปิดเป็น
    // static folder ไว้) เข้ากับ storage_path (relative path ที่เพิ่งเก็บไป)
    // ได้เป็น URL แบบ "/uploads/1/4/x.pdf" ที่ frontend เอาไปใช้ <img
    // src="..."> หรือเปิดลิงก์ดาวน์โหลดได้ตรง ๆ โดยไม่ต้องคำนวณเอง
  } catch (e) { next(e); }
};

// =====================================================================
// Evaluatee: LIST ของตัวเอง
// Query optional: period_id, indicator_id, evidence_type_id
// =====================================================================
exports.listMine = async (req, res, next) => {
  try {
    const evaluatee_id = Number(req.user?.id);
    const { period_id, indicator_id, evidence_type_id } = req.query || {};
    // ฟังก์ชันนี้รับ filter ผ่าน query string (GET request ไม่มี body) เช่น
    // GET /api/upload/mine?period_id=1

    let q = db('attachments').where({ evaluatee_id }).orderBy('id', 'desc');
    if (period_id) q = q.andWhere({ period_id: Number(period_id) });
    if (indicator_id) q = q.andWhere({ indicator_id: Number(indicator_id) });
    if (evidence_type_id) q = q.andWhere({ evidence_type_id: Number(evidence_type_id) });
    // ทยอยเพิ่มเงื่อนไขกรองทีละตัวเฉพาะที่ถูกส่งมาจริง (เหมือนแพทเทิร์นที่ใช้
    // ใน repositories/attachments.js -> listMine) หมายเหตุ: ในไฟล์นี้เขียน
    // คิวรีตรง ๆ ที่นี่เลย ไม่ได้เรียกผ่าน attRepo.listMine() ที่เตรียมไว้ให้
    // แล้ว (อีกจุดที่ logic คล้ายกันถูกเขียนซ้ำไว้คนละที่)

    const rows = await q;
    const data = rows.map(r => ({ ...r, url:`/uploads/${r.storage_path}` }));
    // ใส่ url ให้ทุกแถวเหมือนกับตอน upload — {...r, url: ...} คือการสร้าง
    // object ใหม่ที่มีทุกฟิลด์ของ r (spread) บวกฟิลด์ url เพิ่มเข้าไป
    res.json({ success:true, data });
  } catch (e) { next(e); }
};

// =====================================================================
// Evaluatee: DELETE ของตัวเอง (ลบได้เฉพาะช่วงที่ period ยังเปิด)
// =====================================================================
exports.deleteMine = async (req, res, next) => {
  try {
    const evaluatee_id = Number(req.user?.id);
    const id = Number(req.params.id);
    const row = await attRepo.findById(id);

    if (!row || row.evaluatee_id !== evaluatee_id) {
      // เช็กสองอย่างพร้อมกัน: (1) มีไฟล์ id นี้อยู่จริงไหม (2) ไฟล์นี้เป็น
      // ของ evaluatee คนที่กำลังเรียก API นี้จริงไหม — ถ้าข้อใดข้อหนึ่งไม่
      // ผ่าน ให้ตอบ 404 เหมือนกันหมด (ไม่บอกแยกว่า "ไม่เจอไฟล์" กับ "ไฟล์นี้
      // ไม่ใช่ของคุณ" เพื่อไม่ให้ผู้ใช้เดาได้ว่า id นี้มีอยู่จริงในระบบแต่เป็น
      // ของคนอื่น)
      return res.status(404).json({ success:false, message:'not found' });
    }
    if (!(await isPeriodActive(row.period_id))) {
      return res.status(403).json({ success:false, message:'period closed' });
    }

    const abs = path.join(__dirname, '..', 'uploads', row.storage_path);
    // ประกอบ path แบบ absolute กลับคืนมาจาก relative path ที่เก็บไว้ในฐาน
    // ข้อมูล (ย้อนกลับขั้นตอนของ relFromUploads) เพื่อเอาไปลบไฟล์จริงบนดิสก์
    await db('attachments').where({ id }).del();
    // ลบ "record ในฐานข้อมูล" ก่อน
    safeUnlink(abs);
    // แล้วค่อยลบ "ไฟล์จริงบนดิสก์" ทีหลัง — ลำดับนี้ตั้งใจ: ถ้าลบไฟล์จริง
    // ไม่สำเร็จด้วยเหตุผลใดก็ตาม (safeUnlink กลืน error ไว้เงียบ ๆ) อย่างน้อย
    // record ในฐานข้อมูลก็ถูกลบไปแล้ว ไม่ขึ้นค้างให้ผู้ใช้เห็นในรายการอีก
    // (ไฟล์ขยะที่หลงเหลือบนดิสก์ ถือเป็นปัญหาที่ยอมรับได้มากกว่า record
    // ค้างในฐานข้อมูลที่ผู้ใช้ยังเห็นแต่กดอะไรไม่ได้)

    res.json({ success:true, message:'deleted' });
  } catch (e) { next(e); }
};

// =====================================================================
// Evaluatee: UPDATE FILE ของตัวเอง  (ของเดิมของคุณ)
// =====================================================================
exports.updateFileMine = async (req, res, next) => {
  try {
    const userId = Number(req.user?.id);
    const id = Number(req.params.id);
    if (!req.file) return res.status(400).json({ success:false, message:'no file' });

    const row = await attRepo.findById(id);
    if (!row || row.evaluatee_id !== userId) return res.status(404).json({ success:false, message:'not found' });

    if (!(await isPeriodActive(row.period_id))) {
      return res.status(403).json({ success:false, message:'period closed' });
    }

    const oldAbs = path.join(__dirname, '..', 'uploads', row.storage_path);
    // เก็บ path ของไฟล์ "เก่า" ไว้ก่อน (จะต้องลบทิ้งทีหลัง หลังจากอัปเดต
    // record เรียบร้อยแล้ว)
    const newRel = relFromUploads(req.file.path);
    // ไฟล์ "ใหม่" ที่เพิ่งอัปโหลดมาถูก multer เก็บไว้เป็นไฟล์แยกต่างหากแล้ว
    // เรียบร้อย (คนละชื่อไฟล์กับไฟล์เก่าแน่นอน เพราะ middlewares/upload.js
    // ใส่ timestamp นำหน้าชื่อไฟล์เสมอ) งานของฟังก์ชันนี้คือ "สลับ" ให้
    // record ในฐานข้อมูลชี้ไปที่ไฟล์ใหม่แทน แล้วค่อยลบไฟล์เก่าทิ้ง

    await db('attachments').where({ id }).update({
      file_name: req.file.originalname,
      mime_type: req.file.mimetype,
      size_bytes: req.file.size,
      storage_path: newRel
    });

    safeUnlink(oldAbs);
    // ลบไฟล์เก่าทิ้งหลังจาก update record สำเร็จแล้วเท่านั้น (ลำดับนี้
    // สำคัญ: ถ้า update record ล้มเหลวก่อน อย่างน้อยไฟล์เก่าก็ยังอยู่ ไม่เสีย
    // ข้อมูลไปทั้งคู่)
    const updated = await attRepo.findById(id);
    res.json({ success:true, data: { ...updated, url: `/uploads/${updated.storage_path}` }});
  } catch (e) { next(e); }
};

// =====================================================================
// Evaluatee: UPDATE META ของตัวเอง (ของเดิมของคุณ)
// =====================================================================
exports.updateMetaMine = async (req, res, next) => {
  // ต่างจาก updateFileMine ด้านบน: ฟังก์ชันนี้ "ไม่แตะไฟล์จริง" เลย แก้ไขแค่
  // ข้อมูลประกอบ (ผูกกับ indicator/evidence_type ตัวไหน) ของไฟล์ที่มีอยู่แล้ว
  try {
    const userId = Number(req.user?.id);
    const id = Number(req.params.id);
    const { indicator_id, evidence_type_id } = req.body || {};

    const row = await attRepo.findById(id);
    if (!row || row.evaluatee_id !== userId) return res.status(404).json({ success:false, message:'not found' });

    if (!(await isPeriodActive(row.period_id))) {
      return res.status(403).json({ success:false, message:'period closed' });
    }

    const newIndicator = indicator_id ? Number(indicator_id) : row.indicator_id;
    const newEvType   = evidence_type_id ? Number(evidence_type_id) : row.evidence_type_id;
    // รองรับ partial update เหมือน users.controller.js -> update(): ถ้าไม่
    // ได้ส่งฟิลด์ไหนมา ให้ใช้ค่าเดิมของแถวนั้นแทน (ไม่ใช่เขียนทับด้วยค่าว่าง)

    const okMap = await mapRepo.mapExists({ indicator_id: newIndicator, evidence_type_id: newEvType });
    // ต้องเช็กซ้ำว่าคู่ "ใหม่" (หลังจากผสานค่าเดิม+ค่าที่ส่งมาแล้ว) ยังเป็นคู่
    // ที่ได้รับอนุญาตอยู่ไหม — กันไม่ให้แก้ไขจนกลายเป็นคู่ indicator/
    // evidence_type ที่ไม่ถูกต้องตามกฎของระบบ
    if (!okMap) return res.status(400).json({ success:false, message:'invalid indicator/evidence_type pair' });

    await db('attachments').where({ id }).update({
      indicator_id: newIndicator,
      evidence_type_id: newEvType
    });

    const updated = await attRepo.findById(id);
    res.json({ success:true, data: { ...updated, url: `/uploads/${updated.storage_path}` }});
  } catch (e) { next(e); }
};

// =====================================================================
// Evaluator: LIST หลักฐานของ evaluatee ที่ดูแล
// Query optional: period_id
// =====================================================================
exports.listForEvaluator = async (req, res, next) => {
  try {
    const evaluateeId = Number(req.params.evaluateeId);
    const { period_id } = req.query || {};

    let q = db('attachments').where({ evaluatee_id: evaluateeId }).orderBy('id', 'desc');
    if (period_id) q = q.andWhere({ period_id: Number(period_id) });

    // (ถ้าต้องการตรวจสิทธิ์ evaluator ↔ evaluatee เพิ่ม เติมที่นี่)
    // หมายเหตุสำคัญสำหรับคนต่อยอด: ฟังก์ชันนี้ "ยังไม่ได้" เช็กว่า evaluator
    // ที่กำลังเรียก API นี้ (req.user.id) ถูกมอบหมายให้ดูแล evaluatee คนที่
    // ระบุใน URL (evaluateeId) จริงไหม — ตอนนี้ route ถูกจำกัดแค่ auth
    // ('evaluator') เฉย ๆ (role ต้องเป็น evaluator แต่ไม่เช็กว่าคู่กับ
    // evaluatee คนไหนได้บ้าง) ซึ่งหมายความว่า evaluator คนหนึ่งสามารถเดา/
    // ใส่ evaluateeId ของ evaluatee คนอื่นที่ตนเองไม่ได้ดูแลเข้ามาใน URL
    // แล้วเห็นไฟล์หลักฐานของเขาได้เช่นกัน ถ้าจะนำไปใช้งานจริง ควรเพิ่มการเช็ก
    // ด้วย asgRepo.hasPairInPeriod(...) (เหมือนที่ routes/attachments.js ทำ)
    // ก่อนอนุญาตให้ดูข้อมูลตรงนี้ด้วย
    const rows = await q;
    const data = rows.map(r => ({ ...r, url:`/uploads/${r.storage_path}` }));
    res.json({ success:true, data });
  } catch (e) { next(e); }
};
