// controllers/users.controller.js
// ---------------------------------------------
// "ฉบับนักเรียน" : Controller คุย DB โดยตรงผ่าน Knex (ไม่มี repository)
// จุดประสงค์เพื่อให้เห็นเส้นทางข้อมูลแบบตรงไปตรงมา: HTTP -> Controller -> DB
// ---------------------------------------------
//
// ไฟล์นี้รวมทุก endpoint ที่เกี่ยวกับการจัดการผู้ใช้ (CRUD) ไว้ในที่เดียว —
// ดู routes/users.routes.js ประกอบ เพื่อดูว่าแต่ละฟังก์ชันถูกผูกกับ
// path/method ไหน และต้องผ่าน middleware auth(...) แบบไหนก่อนถึงจะเรียกมาที่
// ฟังก์ชันในไฟล์นี้ได้

const db = require("../db/knex");   // ตัวเชื่อม MySQL ผ่าน Knex (ตั้งค่าใน db/knex.js)
const bcrypt = require("bcrypt");   // สำหรับแฮช (เข้ารหัสทางเดียว) รหัสผ่าน

// ฟังก์ชันเล็กๆ ช่วย "เลือกเฉพาะฟิลด์ที่ปลอดภัย" ไม่ส่ง password_hash ออกไป
// เหตุผล: ห้ามเปิดเผย password_hash ต่อ client เพื่อความปลอดภัย
const pickPublic = (row) =>
  row && {
    id: row.id,
    name_th: row.name_th,
    email: row.email,
    role: row.role,
    created_at: row.created_at,
  };
// หมายเหตุ: ฟังก์ชันนี้ถูกประกาศไว้แต่ "ไม่ได้ถูกเรียกใช้จริง" ในไฟล์นี้เลย —
// ทุกฟังก์ชันด้านล่างเลือกวิธี .select("id","name_th",...) ที่ตัว query
// โดยตรงแทน (กรองตั้งแต่ตอนคิวรีฐานข้อมูล ไม่ต้องกรองซ้ำอีกทีตอนส่ง
// response) ทั้งสองวิธีได้ผลลัพธ์เหมือนกันคือ "ไม่ส่ง password_hash ออกไป"
// เก็บฟังก์ชันนี้ไว้เป็นตัวอย่างอีกแนวทางหนึ่งที่ทำได้เช่นกัน

/**
 * GET /api/users
 * ---------------------------
 * - แสดงรายการผู้ใช้
 * - ถ้าเป็น admin => เห็นทั้งหมด
 * - ถ้าเป็นบทบาทอื่น => เห็นเฉพาะ "ข้อมูลตัวเอง"
 * - ใช้สำหรับอธิบาย RBAC และการดึงข้อมูลแบบปลอดภัย (ไม่ส่ง password_hash)
 */
exports.list = async (req, res, next) => {
  try {
    // กรณี admin เห็นทั้งหมด
    if (req.user?.role === "admin") {
      // req.user ถูกแนบมาโดย middleware auth(...) (ดู middlewares/auth.js)
      // หลัง verify token ผ่านแล้ว — `req.user?.role` ใช้ optional chaining
      // (?.) กันกรณี req.user เป็น undefined ไม่ให้ error ตอนเข้าถึง .role
      const items = await db("users")
        .select("id", "name_th", "email", "role", "created_at")
        // เลือกเฉพาะคอลัมน์ที่ปลอดภัย "ไม่รวม password_hash" ตั้งแต่ชั้น
        // คิวรีฐานข้อมูลเลย (ดีกว่าดึงมาทั้งหมดแล้วค่อยกรองทีหลัง เพราะ
        // password_hash จะไม่มีวันหลุดออกไปโดยไม่ได้ตั้งใจ ไม่ว่าจะลืมกรอง
        // ตรงไหนก็ตาม)
        .orderBy("id", "desc");
        // เรียงผู้ใช้ที่สร้างล่าสุด (id มากสุด) ขึ้นก่อน
      return res.json({ success: true, items, total: items.length });
      // ส่ง total (จำนวนทั้งหมด) กลับไปด้วย เผื่อ frontend เอาไปแสดงผล เช่น
      // "พบผู้ใช้ทั้งหมด N คน"
    }

    // ไม่ใช่ admin -> ต้องล็อกอิน และเห็นเฉพาะตัวเอง
    if (!req.user?.id) {
      // กันเหนียวอีกชั้น: ถ้าด้วยเหตุผลใดก็ตาม req.user ไม่มี id เลย (ไม่น่า
      // เกิดขึ้นถ้า route นี้ถูกครอบด้วย middleware auth(...) อยู่แล้ว แต่
      // เขียนเช็กไว้กันพลาด) ให้ตอบ 403 ทันที
      return res.status(403).json({ success: false, message: "Forbidden" });
    }
    const me = await db("users")
      .select("id", "name_th", "email", "role", "created_at")
      .where({ id: req.user.id })
      // กรองให้เห็นแค่แถวของตัวเอง (id ตรงกับคนที่ login อยู่) — นี่คือหัวใจ
      // ของตัวอย่างนี้: role ที่ไม่ใช่ admin จะถูกจำกัดให้เห็นได้แค่ข้อมูล
      // ของตัวเองเท่านั้น ไม่เห็นข้อมูลของคนอื่นในระบบ
      .first();

    return res.json({
      success: true,
      items: me ? [me] : [],
      // ห่อผลลัพธ์เป็น array เสมอ (ไม่ว่าจะเจอ 1 แถวหรือไม่เจอเลย) เพื่อให้
      // โครงสร้าง response หน้าตาเหมือนกับกรณี admin ด้านบน (ที่ items เป็น
      // array เสมอ) ฝั่ง frontend จะได้เขียนโค้ดอ่าน response แบบเดียวกันได้
      // ทั้งสองกรณี ไม่ต้องแยกเคส
      total: me ? 1 : 0,
    });
  } catch (e) {
    next(e); // ส่งต่อให้ error middleware รวมศูนย์การจัดการ error
  }
};

/**
 * GET /api/users/:id
 * ---------------------------
 * - ดึงรายละเอียดผู้ใช้จาก id
 * - ใช้ .first() เพื่อได้เพียงแถวเดียว
 */
exports.get = async (req, res, next) => {
  try {
    const row = await db("users")
      .select("id", "name_th", "email", "role", "created_at")
      .where({ id: req.params.id })
      // req.params.id คือค่าที่ Express ดึงมาจากส่วน :id ใน path (เช่น
      // GET /api/users/5 -> req.params.id === '5')
      .first();

    if (!row) {
      return res.status(404).json({ success: false, message: "User not found" });
      // 404 Not Found = ไม่มีผู้ใช้ที่ id นี้อยู่ในฐานข้อมูล
    }
    res.json({ success: true, data: row });
    // หมายเหตุ: endpoint นี้ไม่ได้เช็กสิทธิ์เพิ่มเติมว่า "ใครก็ตามที่ login
    // อยู่ (role ไหนก็ได้ตาม middleware ที่ route กำหนดไว้) ดูรายละเอียดผู้ใช้
    // คนไหนก็ได้ตาม id ที่ระบุ" ต่างจาก list() ด้านบนที่จำกัดให้ role ที่ไม่ใช่
    // admin เห็นแค่ของตัวเอง — ถ้าจะต่อยอดให้เข้มงวดเท่ากัน ควรเพิ่มเงื่อนไข
    // คล้ายกันตรงนี้ด้วย (เช็กว่า req.user.id === req.params.id หรือ
    // req.user.role === 'admin' ก่อนอนุญาตให้ดูข้อมูล)
  } catch (e) {
    next(e);
  }
};

/**
 * POST /api/users
 * ---------------------------
 * - สร้างผู้ใช้ใหม่
 * - ตรวจค่าบังคับ (name_th, email, password)
 * - ตรวจอีเมลซ้ำ (unique)
 * - แฮชรหัสผ่านเก็บที่คอลัมน์ password_hash (ตามสคีมา)
 * - คืนข้อมูลผู้ใช้ (แบบไม่รวม password_hash)
 */
exports.create = async (req, res, next) => {
  try {
    const { name_th, email, password, role = "evaluatee" } = req.body || {};
    // ถ้าไม่ได้ส่ง role มาเลย ให้ default เป็น "evaluatee" (บทบาทพื้นฐาน
    // ที่สุดของระบบ — ผู้ถูกประเมิน) กันพลาดกรณี frontend ลืมส่ง role มา

    // 1) ตรวจว่ามีฟิลด์จำเป็นไหม
    if (!name_th || !email || !password) {
      return res
        .status(400)
        .json({ success: false, message: "name_th, email, password required" });
    }

    // 2) ตรวจอีเมลซ้ำ (ต้อง unique)
    const exists = await db("users").where({ email }).first();
    // คิวรีดูก่อนว่ามีผู้ใช้ email นี้อยู่แล้วหรือยัง ก่อนจะ insert จริง
    // (ป้องกันไว้ตั้งแต่ชั้นแอปพลิเคชัน แม้ว่าในฐานข้อมูลควรมี UNIQUE
    // constraint บนคอลัมน์ email ไว้ด้วยอีกชั้นเป็น safety net สุดท้ายก็ตาม
    // — ถ้าพึ่งแค่ constraint ของฐานข้อมูลอย่างเดียว ผู้ใช้จะเห็น error
    // ดิบ ๆ จากฐานข้อมูลแทนข้อความที่เข้าใจง่ายแบบนี้)
    if (exists) {
      return res
        .status(409)
        // 409 Conflict = ข้อมูลที่จะสร้างขัดแย้งกับข้อมูลที่มีอยู่แล้ว
        .json({ success: false, message: "Email already exists" });
    }

    // 3) แฮชรหัสผ่าน แล้วบันทึกลงคอลัมน์ password_hash (ห้ามเก็บ plaintext)
    const password_hash = await bcrypt.hash(password, 10);
    // bcrypt.hash(plaintext, saltRounds) — saltRounds (ที่นี่คือ 10) คือ
    // "ความหนัก" ของการคำนวณ hash ยิ่งค่ามากยิ่งคำนวณช้าลง (ปลอดภัยขึ้นจาก
    // การถูกเดารหัสผ่านแบบ brute-force แต่ก็ใช้เวลา/ทรัพยากรมากขึ้นตอน login
    // ด้วย) ค่า 10 เป็นค่ามาตรฐานที่สมดุลระหว่างความปลอดภัยกับความเร็วสำหรับ
    // แอปทั่วไป

    // 4) insert และอ่านกลับมาเพื่อส่งให้ client
    const [insertId] = await db("users").insert({
      name_th,
      email,
      password_hash,
      // เก็บแค่ password_hash ที่ผ่านการ hash แล้วเท่านั้น "ไม่เคย" เก็บ
      // ตัวแปร password (รหัสผ่านดิบ) ลงฐานข้อมูลเลย
      role,
    });
    const created = await db("users")
      .select("id", "name_th", "email", "role", "created_at")
      .where({ id: insertId })
      .first();
      // insert แล้วดึงกลับมาอีกทีเพื่อให้ได้ข้อมูลที่ฐานข้อมูลเติมให้
      // อัตโนมัติด้วย (เช่น created_at) ไปส่งให้ client แสดงผลต่อได้ทันที

    res.status(201).json({ success: true, data: created });
    // 201 Created = สร้างข้อมูลใหม่สำเร็จ
  } catch (e) {
    next(e);
  }
};

/**
 * PUT /api/users/:id
 * ---------------------------
 * - อัปเดตข้อมูลผู้ใช้ตาม id
 * - อนุญาตแก้เฉพาะฟิลด์ที่ส่งมา (partial update)
 * - ถ้าเปลี่ยนอีเมล ต้องตรวจซ้ำ (unique)
 * - ถ้าส่ง password มาใหม่ -> แฮชใหม่และอัปเดต password_hash
 */
exports.update = async (req, res, next) => {
  try {
    const id = req.params.id;
    if (!id) return res.status(400).json({ success: false, message: "Missing user ID" });
    // ในทางปฏิบัติ req.params.id จะมีค่าเสมอถ้า route คือ '/:id' (Express
    // จะไม่ match route นี้เลยถ้า path ไม่มีส่วนที่เป็น id) แต่เขียนเช็กไว้
    // กันเหนียวเผื่อกรณีแปลก ๆ

    const { name_th, email, role, password } = req.body || {};
    const payload = {};
    // สร้าง object ว่างไว้ก่อน แล้วค่อย ๆ ใส่เฉพาะฟิลด์ที่ผู้ใช้ส่งมาจริง ๆ
    // ด้านล่าง — เทคนิคนี้เรียกว่า "partial update" (อัปเดตแค่บางฟิลด์) ถ้า
    // frontend ส่งมาแค่ { name_th: "ชื่อใหม่" } ฟิลด์อื่น (email, role,
    // password) ในฐานข้อมูลจะไม่ถูกแตะต้องเลย

    // 1) เก็บเฉพาะฟิลด์ที่ส่งเข้ามา (ไม่บังคับต้องส่งครบ)
    if (name_th != null) payload.name_th = name_th;
    // `!= null` เช็กทั้ง null และ undefined พร้อมกันในเงื่อนไขเดียว (ใน
    // JavaScript, null != null เป็น false แต่ null != undefined ก็เป็น
    // false ด้วย เพราะ == / != จะมองว่า null กับ undefined "เท่ากัน" กันเอง)
    // เพื่อแยกจากกรณีผู้ใช้ตั้งใจส่งค่าว่าง "" มา (ซึ่งควรนับว่า "ส่งมาแล้ว
    // ให้เป็นค่าว่าง" ไม่ใช่ "ไม่ได้ส่งมา")
    if (email != null) payload.email = email;
    if (role != null) payload.role = role;

    // 2) ถ้าเปลี่ยนรหัสผ่าน -> แฮชใหม่
    if (password && password.trim() !== "") {
      // เช็กทั้งว่ามีค่า (truthy) และไม่ใช่สตริงที่มีแต่ช่องว่างล้วน ๆ ก่อน
      // ถือว่า "ต้องการเปลี่ยนรหัสผ่านจริง" (ถ้า frontend ส่ง password: ""
      // มาเฉย ๆ ไม่ควรไปเขียนทับรหัสผ่านเดิมด้วยค่าว่าง)
      payload.password_hash = await bcrypt.hash(password, 10);
    }

    // 3) ถ้าจะเปลี่ยนอีเมล -> ตรวจซ้ำกับคนอื่น (ห้ามชนกับผู้ใช้รายอื่น)
    if (payload.email) {
      const dup = await db("users")
        .where({ email: payload.email })
        .andWhereNot({ id })
        // สำคัญมาก: ต้องกัน "ตัวเอง" ออกจากการเช็กซ้ำด้วย (.andWhereNot({
        // id })) ไม่งั้นถ้าผู้ใช้ไม่ได้เปลี่ยนอีเมลเลย (ส่ง email เดิมของ
        // ตัวเองมา) ระบบจะเข้าใจผิดว่า "อีเมลนี้ซ้ำ" (ซ้ำกับตัวเอง) ทั้งที่
        // ไม่ได้มีปัญหาอะไรเลย
        .first();

      if (dup) {
        return res.status(409).json({ success: false, message: "Email already exists" });
      }
    }

    // 4) update และตรวจว่ามีแถวที่ถูกอัปเดตไหม
    const affected = await db("users").where({ id }).update(payload);
    // .update(payload) คืนค่าจำนวนแถวที่ถูกแก้ไขจริง (0 หรือ 1 ในที่นี้
    // เพราะ id เป็น primary key) ถ้าเป็น 0 แปลว่าไม่มีผู้ใช้ id นี้อยู่เลย
    if (!affected) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    // 5) อ่านข้อมูลล่าสุดกลับเพื่อส่งให้ client (ไม่รวม password_hash)
    const updated = await db("users")
      .select("id", "name_th", "email", "role", "created_at")
      .where({ id })
      .first();

    res.json({ success: true, data: updated });
  } catch (e) {
    next(e);
  }
};

/**
 * DELETE /api/users/:id
 * ---------------------------
 * - ลบผู้ใช้ตาม id
 * - ตัวอย่างนี้จำกัดสิทธิ์เฉพาะ admin (แสดงการใช้ RBAC ชัดเจน)
 */
exports.remove = async (req, res, next) => {
  try {
    // RBAC: admin เท่านั้น
    if (req.user?.role !== "admin") {
      // RBAC ย่อมาจาก Role-Based Access Control (การควบคุมสิทธิ์ตามบทบาท)
      // — หมายเหตุ: เงื่อนไขนี้ซ้ำซ้อนกับที่ routes/users.routes.js ผูก
      // middleware auth('admin') ไว้อยู่แล้ว (เช็กซ้ำสองชั้น) แต่เก็บไว้เป็น
      // ตัวอย่างให้เห็นว่า controller เองก็เช็กสิทธิ์ซ้ำได้อีกชั้นหนึ่ง ถ้า
      // อนาคตมีการผูก route นี้จาก path อื่นที่ลืมใส่ middleware ไว้ ก็ยังมี
      // ด่านนี้คอยป้องกันอยู่ (defense in depth)
      return res
        .status(403)
        .json({ success: false, message: "Forbidden (admin only)" });
    }

    const affected = await db("users").where({ id: req.params.id }).del();
    if (!affected) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    // convention: ลบสำเร็จตอบ success: true พอ ไม่ต้องคืนข้อมูล
    res.json({ success: true });
    // ไม่มีข้อมูลอะไรให้ส่งกลับแล้ว (ลบไปแล้ว) จึงตอบแค่สถานะความสำเร็จพอ
    // ต่างจาก create/update ที่มีข้อมูลแถวล่าสุดให้ส่งกลับไปแสดงผลต่อ
  } catch (e) {
    next(e);
  }
};

/**
 * GET /api/users/server
 * ---------------------------
 * - ตัวอย่าง Server-side Pagination + Search + Sort
 * - page, itemsPerPage, sortBy, sortDesc, search
 * - สอนเรื่อง "การนับ total" และ "LIMIT/OFFSET" บน DB
 */
exports.listServer = async (req, res, next) => {
  // "Server-side pagination" คือการให้ฐานข้อมูล/เซิร์ฟเวอร์เป็นคนตัดแบ่งหน้า
  // ข้อมูลให้ (ดึงมาแค่หน้าที่ต้องการจริง ๆ) ต่างจากการดึงข้อมูลทั้งหมดมาไว้
  // ที่ frontend แล้วค่อยตัดแบ่งหน้าเอง (client-side pagination ซึ่ง list()
  // ด้านบนทำแบบนั้น) — เหมาะกับตารางข้อมูลที่มีจำนวนแถวเยอะมาก เพราะไม่ต้อง
  // โหลดข้อมูลทั้งหมดมาทีเดียว
  try {
    // 1) รับค่า query string พร้อม default
    const page = Number(req.query.page || 1);
    // ค่า query string ทุกตัวที่อ่านจาก req.query จะเป็น string เสมอ (เช่น
    // "2" ไม่ใช่ 2) จึงต้องแปลงเป็นตัวเลขด้วย Number(...) ก่อนใช้งาน ถ้าไม่ได้
    // ส่ง page มาเลย default เป็นหน้า 1
    const itemsPerPage = Number(req.query.itemsPerPage || 10);
    // จำนวนแถวต่อหน้า default 10 แถว
    const sortBy = String(req.query.sortBy || "id");
    const sortDesc = req.query.sortDesc === "false" ? false : true;
    // ตรรกะเฉพาะตัวตรงนี้: "ถ้า sortDesc ที่ส่งมาคือสตริง 'false' เป๊ะ ๆ
    // เท่านั้น ถึงจะถือว่าเรียงจากน้อยไปมาก (ascending) กรณีอื่นทั้งหมด (ไม่
    // ส่งมาเลย, ส่งมาเป็น 'true', หรือค่าอื่นใดก็ตาม) ถือว่าเรียงมากไปน้อย
    // (descending) เป็น default" เพราะ query string ทุกตัวเป็น string เสมอ
    // เทียบ req.query.sortDesc === false (boolean) ตรง ๆ จะไม่มีวันเป็น
    // true เลย จึงต้องเทียบกับ string "false" แทน
    const search = String((req.query.search || "").trim());
    // .trim() ตัดช่องว่างหน้า-หลังคำค้นหาออก กันกรณีผู้ใช้เผลอเคาะ
    // เว้นวรรคเกินมา

    // 2) whitelist ชื่อคอลัมน์ที่อนุญาตให้ sort (ป้องกัน SQL Injection ทาง orderBy)
    const allowed = new Set(["id", "name_th", "email", "role", "created_at"]);
    const column = allowed.has(sortBy) ? sortBy : "id";
    // สำคัญมากด้านความปลอดภัย: sortBy มาจาก query string ที่ผู้ใช้ควบคุมได้
    // โดยตรง (เช่น ?sortBy=... ) ถ้าเอาค่านี้ไปต่อเป็นส่วนหนึ่งของคำสั่ง SQL
    // ตรง ๆ โดยไม่ตรวจสอบก่อน ผู้ไม่หวังดีอาจใส่ชื่อคอลัมน์ปลอม หรือแม้แต่
    // คำสั่ง SQL อันตรายเข้ามาได้ (SQL Injection) — การเช็กกับ "whitelist"
    // (รายชื่อคอลัมน์ที่อนุญาตเท่านั้น) ก่อนเสมอ คือวิธีป้องกันที่ถูกต้อง: ถ้า
    // ชื่อคอลัมน์ที่ส่งมาไม่อยู่ในลิสต์ที่อนุญาต ให้ใช้ "id" (ค่าปลอดภัย)
    // แทนเงียบ ๆ โดยไม่ error
    const dir = sortDesc ? "DESC" : "ASC";

    // 3) คำนวณ offset และ pattern ค้นหา
    const off = (page - 1) * itemsPerPage;
    // OFFSET คือ "ข้ามกี่แถวก่อนเริ่มดึง" เช่น หน้า 1 (page=1) offset = 0
    // (ไม่ข้ามเลย) หน้า 2 (page=2) offset = itemsPerPage (ข้ามแถวของหน้า 1
    // ไปทั้งหมด) เป็นสูตรมาตรฐานของการแบ่งหน้าแบบ LIMIT/OFFSET
    const like = `%${search}%`;
    // รูปแบบ pattern สำหรับ SQL LIKE — เครื่องหมาย % หมายถึง "มีอะไรก็ได้
    // (หรือไม่มีเลย) อยู่ตรงนี้" ดังนั้น "%คำค้นหา%" แปลว่า "มีคำค้นหานี้อยู่
    // ตรงไหนก็ได้ในข้อความ" (ค้นหาแบบ contains ไม่ใช่ exact match)

    const isAdmin = req.user?.role === "admin";
    // แก้ไข: endpoint นี้เดิมไม่เช็ก role เลย ทุก role ที่ login อยู่
    // (evaluatee/evaluator/admin) เห็นข้อมูลผู้ใช้ "ทุกคนในระบบ" เหมือนกันหมด
    // ทั้งที่ list() (endpoint ข้างบน) จำกัดไว้แล้วว่า role ที่ไม่ใช่ admin
    // ต้องเห็นได้แค่ของตัวเอง — ทำให้สองหน้า/สอง endpoint ของเรื่องเดียวกัน
    // (ดูรายชื่อผู้ใช้) ให้สิทธิ์ไม่ตรงกัน ตอนนี้บังคับกรองเหมือนกับ list()
    // ด้วย .andWhere({ id: req.user.id }) ด้านล่างถ้าไม่ใช่ admin

    // 4) นับจำนวนแถวทั้งหมดที่ตรง search (ใช้ count แยก 1 คำสั่ง)
    let countQuery = db("users")
      .whereRaw("CONCAT(id,' ',name_th,' ',email,' ',role) LIKE ?", [like])
      // CONCAT(...) ต่อค่าของหลายคอลัมน์เป็นข้อความยาวเส้นเดียวก่อน แล้ว
      // ค่อยเทียบด้วย LIKE — ทำให้ค้นหาคำเดียวแล้วเจอได้ไม่ว่าคำนั้นจะอยู่ใน
      // id, ชื่อ, อีเมล หรือ role ก็ตาม (ค้นหาแบบ "ค้นทุกคอลัมน์พร้อมกัน")
      // การใช้ .whereRaw(sql, [params]) แทนการต่อสตริงเอง (เช่น
      // `LIKE '%${search}%'` ตรง ๆ) คือการป้องกัน SQL Injection ที่ถูกต้อง
      // — ใส่ "?" เป็นตัวแทนค่าไว้ก่อน แล้วส่งค่าจริงแยกมาใน array พารามิเตอร์
      // ([like]) ให้ driver ฐานข้อมูลเป็นคนจัดการ escape ค่าให้ปลอดภัยเอง
      // (ต่างจาก sortBy/column ด้านบนที่ป้องกันด้วย whitelist เพราะเป็นชื่อ
      // คอลัมน์ ไม่ใช่ค่าข้อมูล จะใช้ "?" parameter แบบนี้แทนไม่ได้)
    if (!isAdmin) countQuery = countQuery.andWhere({ id: req.user.id });
    const [{ cnt }] = await countQuery.count({ cnt: "*" });
      // .count({ cnt: "*" }) คือ SELECT COUNT(*) AS cnt — ตั้งชื่อคอลัมน์
      // ผลลัพธ์ว่า "cnt" เพื่อให้ destructure ออกมาใช้ง่าย knex คืนผลลัพธ์
      // ของ .count() เป็น array เสมอ (แม้จะมีแค่แถวเดียว) จึง destructure
      // ด้วย [{ cnt }] (ดึงแถวแรกของ array แล้วดึงฟิลด์ cnt ออกมาจากแถวนั้น
      // อีกที)

    // 5) ดึงแถวเฉพาะหน้าที่ต้องการ (LIMIT/OFFSET + ORDER)
    let itemsQuery = db("users")
      .select("id", "name_th", "email", "role", "created_at")
      .whereRaw("CONCAT(id,' ',name_th,' ',email,' ',role) LIKE ?", [like]);
      // ใช้เงื่อนไขค้นหาเดียวกับตอนนับ total ด้านบน เพื่อให้ total ตรงกับ
      // จำนวนแถวที่ค้นเจอจริง ๆ (ไม่ใช่ total ของทั้งตาราง)
    if (!isAdmin) itemsQuery = itemsQuery.andWhere({ id: req.user.id });
    const items = await itemsQuery
      .orderBy(column, dir)
      .limit(itemsPerPage)
      // LIMIT = ดึงมาสูงสุดกี่แถว (เท่ากับจำนวนแถวต่อหน้า)
      .offset(off);
      // OFFSET = ข้ามไปกี่แถวก่อนเริ่มดึง (คำนวณไว้แล้วด้านบน)

    // 6) ส่งกลับพร้อม total เพื่อให้หน้าเว็บคำนวณจำนวนหน้าได้
    res.json({
      success: true,
      items,
      total: Number(cnt || 0),
      // cnt ที่ได้จาก COUNT(*) ของ MySQL ผ่าน mysql2 driver บางครั้งจะเป็น
      // ชนิดข้อมูล BigInt/string แทนที่จะเป็น number ตรง ๆ จึงแปลงด้วย
      // Number(...) อีกรอบให้ชัวร์ว่าเป็นตัวเลขจริงก่อนส่งออกไปเป็น JSON
      page,
      itemsPerPage,
      // ส่ง page กับ itemsPerPage กลับไปด้วย (ค่าที่ client ส่งมาเอง) เพื่อ
      // ให้ frontend เอาไปคำนวณจำนวนหน้าทั้งหมดได้ง่าย เช่น
      // Math.ceil(total / itemsPerPage)
    });
  } catch (e) {
    next(e);
  }
};
