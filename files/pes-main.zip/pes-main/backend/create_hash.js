// create_hash.js
//
// สคริปต์ยูทิลิตี้เล็ก ๆ สำหรับ "รันมือ" ตอน dev — ไม่ได้ถูกเรียกใช้จาก
// server.js/app.js หรือ route ใด ๆ เลย เป็นเครื่องมือช่วยสร้างค่า bcrypt
// hash ของรหัสผ่าน เอาไว้ก๊อปไปใส่ในไฟล์ schema.sql ตรง ๆ (คอลัมน์
// password_hash ของตาราง users) เวลาจะ seed ผู้ใช้ตัวอย่างใหม่ด้วยรหัสผ่าน
// ที่กำหนดเอง โดยไม่ต้องเปิด API /api/auth/... หรือสมัครผ่านหน้าเว็บก่อน
//
// วิธีใช้: รันด้วยคำสั่ง `node create_hash.js` จากโฟลเดอร์ backend/ แล้ว
// ก๊อปค่า hash ที่พิมพ์ออกมาไปวางในคำสั่ง INSERT ของ schema.sql (ถ้าจะใช้
// รหัสผ่านอื่นที่ไม่ใช่ "12345678" ให้แก้ค่าตัวแปร password ด้านล่างก่อนรัน)

const bcrypt = require('bcrypt');

const password = '12345678'; // รหัสผ่านที่ต้องการเข้ารหัส
// const password = '12345678'; // รหัสผ่านที่ต้องการเข้ารหัส
const saltRounds = 10; // ค่า cost factor ที่แนะนำ
// saltRounds ต้องตั้งเป็นค่าเดียวกับที่ใช้จริงใน
// controllers/users.controller.js (bcrypt.hash(password, 10)) ไม่งั้นแค่
// "ความหนักในการคำนวณ" จะไม่ตรงกัน แต่ไม่ได้ทำให้ login ผิดพลาดแต่อย่างใด
// (ค่า saltRounds ถูกฝังรวมอยู่ในตัว hash ที่ได้ออกมาอยู่แล้ว bcrypt.compare
// ตอน login จะอ่านค่านี้จากตัว hash เองได้เสมอ ไม่ต้องรู้ล่วงหน้าว่าใช้ค่า
// อะไรตอนสร้าง)

bcrypt.hash(password, saltRounds, (err, hash) => {
  // bcrypt.hash รองรับทั้งแบบ callback (แบบนี้) และแบบ Promise (ที่ใช้ await
  // ในโค้ด controller จริงของระบบ) — สคริปต์นี้เลือกใช้แบบ callback เพื่อให้
  // เห็นอีกรูปแบบการเขียนโค้ด asynchronous ของ JavaScript (เทียบกับ
  // async/await ที่ใช้ในไฟล์อื่นของระบบ)
  if (err) {
    console.error('Error hashing password:', err);
  } else {
    console.log('Hashed password:', hash);
    // นำค่าที่พิมพ์ออกมาตรงนี้ไปวางในคอลัมน์ password_hash ของคำสั่ง INSERT
    // ใน schema.sql ได้เลย
  }
});
// นำเข้าโมดูล bcrypt สำหรับการเข้ารหัสรหัสผ่าน
