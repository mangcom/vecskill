// backend/db/knex.js
//
// ไฟล์นี้สร้าง "ตัวเชื่อมต่อฐานข้อมูล" เพียงจุดเดียวของทั้งแอป แล้ว export
// ออกไปให้ไฟล์อื่น (controllers, repositories) เอาไปใช้คิวรี MySQL ผ่าน
// Knex.js (query builder — เขียนโค้ด JavaScript แทนการเขียน SQL ดิบ ๆ เอง
// ทั้งหมด แต่ยังสามารถเขียน SQL ดิบได้เมื่อจำเป็น)
//
// จุดสำคัญ: ไฟล์นี้ require('dotenv').config() เองอีกรอบ (แยกจาก server.js)
// เพื่อให้แน่ใจว่าไม่ว่าไฟล์นี้จะถูก require จากที่ไหนก่อนก็ตาม (เช่นตอนรัน
// test ที่ import controller ตรง ๆ โดยไม่ผ่าน server.js) ค่าใน .env (อยู่ที่
// root ของโปรเจกต์ ไม่ใช่ backend/.env แล้ว — ดูเหตุผลด้านล่าง) จะถูกโหลด
// เข้า process.env แน่นอนเสมอ ก่อนที่จะอ่านค่าไปตั้ง connection

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') }); // << เพิ่มบรรทัดนี้
// บังคับให้ dotenv อ่านไฟล์ .env จาก root ของโปรเจกต์ (ไฟล์เดียวกับที่
// docker-compose.yml ใช้ตั้งค่าทั้ง frontend และ backend) เสมอ ใช้
// path.resolve ระบุ path แบบ absolute อิงจากตำแหน่งไฟล์นี้เอง คือ
// backend/db/ ถอยกลับ 2 ชั้น (../../.env) ไปที่ root ของ repo แทนที่จะปล่อย
// ให้ dotenv เดาจาก working directory ปัจจุบันของโปรเซส ซึ่งอาจไม่ตรงกันถ้า
// รันคำสั่งจากคนละโฟลเดอร์ — เดิมไฟล์นี้เคยอยู่ที่ backend/.env (ถอยแค่ 1
// ชั้น ../.env) แต่ถูกย้ายมารวมกับ .env ที่ root (ที่ใช้ตั้งค่า
// NUXT_PUBLIC_API_BASE ของ frontend อยู่แล้ว) เป็นไฟล์เดียว ลดความซ้ำซ้อน
// ของการมี .env หลายไฟล์กระจายอยู่คนละที่กัน

const knex = require('knex');
// knex คือไลบรารี query builder สำหรับฐานข้อมูล SQL หลายชนิด (MySQL,
// PostgreSQL, SQLite ฯลฯ) เรียก knex({...}) ครั้งเดียวจะได้ instance ที่ใช้
// คิวรีฐานข้อมูลได้ทันที เช่น db('users').where({id: 1}).first()

const db = knex({
  client: 'mysql2',
  // บอก knex ว่าจะต่อกับ MySQL โดยใช้ driver ชื่อ "mysql2" (ไลบรารี npm ที่
  // แท้จริงไปคุยกับ MySQL ผ่าน protocol ของมัน)
  connection: {
    host: process.env.DB_HOST || '127.0.0.1',
    // ที่อยู่ของเครื่อง MySQL — ใน docker compose จะถูกตั้งเป็น "db" (ชื่อ
    // service ใน docker-compose.yml) ส่วนถ้ารันนอก Docker (เช่นต่อ MySQL ที่
    // ติดตั้งเองบนเครื่อง) ค่า default 127.0.0.1 จะใช้ได้เลย
    user: process.env.DB_USER || 'root',
    // password: process.env.DB_PASS || 'rootpassword',
    password: process.env.DB_PASS || '', // สำหรับ XAMPP
    // รหัสผ่านของ user ที่ใช้เชื่อมต่อ — ค่า default เป็นสตริงว่าง เพราะ XAMPP
    // (เครื่องมือจำลอง MySQL ยอดนิยมสำหรับฝึกเขียนโปรแกรมบน Windows) ตั้งค่า
    // root ไว้แบบไม่มีรหัสผ่านโดย default ถ้าใช้ docker compose ของโปรเจกต์นี้
    // ต้องตั้ง DB_PASS=rootpassword ใน .env (ที่ root) ให้ตรงกับ
    // MYSQL_ROOT_PASSWORD ใน docker-compose.yml ไม่งั้นต่อฐานข้อมูลไม่ติด
    database: process.env.DB_NAME || 'skills_db',
    // ชื่อฐานข้อมูลที่จะใช้งาน ต้องตรงกับชื่อที่สร้างไว้ใน schema.sql
    // (CREATE DATABASE / MYSQL_DATABASE ใน docker-compose.yml)
    port: Number(process.env.DB_PORT) || 3306,
    // พอร์ตของ MySQL (ค่ามาตรฐานคือ 3306) — ต้องแปลงเป็นตัวเลขด้วย Number(...)
    // เพราะค่าที่อ่านจาก process.env จะเป็น string เสมอ (เช่น "3306" ไม่ใช่
    // 3306) ถ้าไม่แปลงอาจมีปัญหากับบางไลบรารีที่คาดหวัง number ตรง ๆ
    connectTimeout: 15000,
    // ถ้าเชื่อมต่อฐานข้อมูลไม่สำเร็จภายใน 15000 มิลลิวินาที (15 วินาที) ให้
    // ถือว่า timeout แล้ว โยน error ออกมา แทนที่จะรอเฉย ๆ ไม่มีที่สิ้นสุด
  },
  pool: { min: 0, max: 10, acquireTimeoutMillis: 20000 },
  // connection pool คือกลุ่มของการเชื่อมต่อฐานข้อมูลที่เปิดเตรียมไว้ล่วงหน้า
  // เพื่อนำกลับมาใช้ซ้ำ (ไม่ต้องเปิด-ปิด connection ใหม่ทุกครั้งที่มี query ซึ่ง
  // ช้ากว่ามาก) min: 0 = ไม่ต้องเปิด connection ค้างไว้เลยตอนเริ่มต้น (เปิดเมื่อ
  // มีคิวรีจริง ๆ เท่านั้น) max: 10 = เปิดพร้อมกันได้สูงสุด 10 connection
  // acquireTimeoutMillis: 20000 = ถ้าขอยืม connection จาก pool แล้วรอเกิน
  // 20 วินาที (เช่น pool เต็มหมด) ให้ throw error ออกมาแทนที่จะรอตลอดไป
});

// ช่วยตรวจว่าโหลดค่าถูกจริง
console.log('[DB-CONFIG]', {
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  db: process.env.DB_NAME,
});
// พิมพ์ค่า config ที่อ่านได้ออกทาง console ตอน server เริ่มทำงาน เพื่อให้เห็น
// ทันทีว่าจริง ๆ แล้วตอนนี้ backend กำลังจะไปต่อกับฐานข้อมูลที่ host/port/ชื่อ
// ฐานข้อมูลไหน (มีประโยชน์มากเวลาแก้ปัญหา "ต่อฐานข้อมูลไม่ติด" เพราะเห็นเลยว่า
// .env ถูกอ่านค่าตามที่ตั้งใจไว้จริงหรือเปล่า) หมายเหตุ: ไม่ log password ออกมา
// ด้วย เพื่อไม่ให้รหัสผ่านหลุดไปอยู่ใน log

module.exports = db;
// export instance ของ knex ที่ตั้งค่าเสร็จแล้ว ให้ทุกไฟล์ที่ต้องคิวรีฐานข้อมูล
// (เช่น controllers/auth.controller.js, repositories/*.js) เรียกใช้ร่วมกัน
// เป็นตัวเดียวกันทั้งแอป (connection pool เดียวกัน ไม่ใช่เปิดใหม่ทุกไฟล์)
