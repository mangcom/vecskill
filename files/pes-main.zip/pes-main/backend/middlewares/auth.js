// middlewares/auth.js
//
// Middleware สำหรับตรวจสอบสิทธิ์ (authentication + authorization) ของ
// request ที่เข้ามา ใช้ครอบ route ที่ต้อง login ก่อนถึงจะเรียกได้
//
// วิธีใช้งาน: ไฟล์นี้ export เป็น "ฟังก์ชันที่คืนฟังก์ชัน" (higher-order
// function) ไม่ใช่ middleware ตรง ๆ เพราะเราอยากให้ส่ง "role ที่อนุญาต" เข้าไป
// ได้ตอนผูก route เช่น
//   router.get('/users', auth('admin'), ...)               -> ต้องเป็น admin เท่านั้น
//   router.post('/evidence', auth('evaluatee'), ...)        -> ต้องเป็น evaluatee เท่านั้น
//   router.get('/periods/active', auth('evaluatee','evaluator','admin'), ...) -> role ไหนก็ได้ในลิสต์นี้
//   auth() (ไม่ส่ง role เลย)                                 -> แค่ต้อง login (token ถูกต้อง) role อะไรก็ได้
//
// หลักการทำงานคือ JWT (JSON Web Token): ตอน login สำเร็จ (ดู
// controllers/auth.controller.js) server จะ "เซ็น" ข้อมูล user (id, role,
// name) ด้วยกุญแจลับ (JWT_SECRET) ออกมาเป็น token สตริงยาว ๆ ส่งให้ฝั่ง
// client เก็บไว้ (ดู frontend/stores/auth.js) ทุกครั้งที่ client จะเรียก API ที่
// ต้อง login client จะแนบ token นี้มาใน header
// "Authorization: Bearer <token>" — middleware ตัวนี้มีหน้าที่แกะ token นั้น
// ออกมา ตรวจว่าเซ็นด้วยกุญแจเดียวกันจริงไหม (ไม่ได้ถูกปลอม/แก้ไข) แล้วค่อย
// เช็ก role ว่ามีสิทธิ์เข้าถึง route นี้หรือเปล่า

const jwt = require('jsonwebtoken');
// ไลบรารีมาตรฐานสำหรับสร้าง/ตรวจสอบ JWT — ใช้ jwt.verify() ตรวจสอบ token

module.exports = (...roles) => {
  // (...roles) คือ rest parameter — เก็บทุก argument ที่ส่งเข้ามาตอนเรียก
  // auth('admin', 'evaluator') ให้กลายเป็น array roles = ['admin', 'evaluator']
  // ถ้าเรียก auth() เฉย ๆ roles จะเป็น array ว่าง []

  // ฟังก์ชันนี้ return middleware ตัวจริงออกไป (มี req, res, next ตามรูปแบบ
  // มาตรฐานของ Express middleware) — Express จะเรียกมันทุกครั้งที่มี request
  // เข้า route ที่ผูก middleware ตัวนี้ไว้
  return (req, res, next) => {
    try {
      // 1) log ไว้ดูว่า middleware นี้ถูกเรียกกับ request ไหนบ้าง (method + path)
      //    มีประโยชน์เวลา debug ปัญหา "ทำไม route นี้เข้าไม่ได้" เพราะเห็นเลยว่า
      //    มันถูกเรียกจริงไหมก่อนจะไปดูสาเหตุอื่น
      console.log('[AUTH] hit:', req.method, req.originalUrl);

      // 2) ดึง header "Authorization" ที่ client แนบมา (ถ้าไม่มีให้เป็น
      //    string ว่างแทน undefined กันโค้ดด้านล่าง error ตอนเรียก .startsWith)
      const header = req.headers.authorization || '';
      console.log('[AUTH] header:', header || '(empty)');

      // 3) กรณีเบราว์เซอร์ส่ง HTTP method แบบ OPTIONS มาก่อน (เรียกว่า
      //    "CORS preflight request" — เบราว์เซอร์จะยิง OPTIONS ไปถามก่อนว่า
      //    server อนุญาตให้ request จริงแบบนี้ (เช่น POST ข้าม origin) ได้ไหม)
      //    request แบบนี้ไม่มี token แนบมาด้วยแน่นอน (เบราว์เซอร์เป็นคนส่งเอง
      //    ไม่ใช่โค้ดฝั่ง frontend) ถ้าปล่อยให้ตกไปเช็ก token ด้านล่างจะโดน 401
      //    เสมอ ทำให้ CORS พังทั้งระบบ จึงต้องตอบ 204 (No Content = "รับทราบ
      //    ไม่มีอะไรจะส่งกลับ") แล้ว return ออกจากฟังก์ชันทันที ไม่ไปเช็ก token ต่อ
      if (req.method === 'OPTIONS') {
        console.log('[AUTH] skip OPTIONS');
        return res.sendStatus(204);
      }

      // 4) แกะ token ออกจาก header รูปแบบมาตรฐานคือ "Bearer <token>"
      //    ถ้า header ไม่ได้ขึ้นต้นด้วย "Bearer " ให้ถือว่าไม่มี token เลย (null)
      const token = header.startsWith('Bearer ') ? header.slice(7) : null;
      // header.slice(7) คือตัดคำว่า "Bearer " (7 ตัวอักษร รวมช่องว่าง) ออก
      // เหลือแค่ตัว token เอง
      if (!token) {
        console.log('[AUTH] -> 401 Missing token');
        return res.status(401).json({ success: false, message: 'Missing token' });
      }

      // 5) ตรวจสอบลายเซ็นของ token ด้วยกุญแจลับ JWT_SECRET (ต้องเป็นตัวเดียว
      //    กับที่ใช้ "เซ็น" ตอน login ใน auth.controller.js ไม่งั้นจะ verify
      //    ไม่ผ่าน) ถ้า token ถูกปลอมแปลง/แก้ไข/หมดอายุ jwt.verify จะ throw
      //    error ออกมาทันที (ตกไปเข้า catch ด้านล่าง)
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      // payload คือข้อมูลที่เราฝังไว้ตอนสร้าง token เช่น { id, role, name, iat, exp }
      console.log('[AUTH] verified payload:', payload);

      // 6) ถ้า route นี้ระบุ role ที่อนุญาตไว้ (roles.length > 0) ให้เช็กว่า
      //    role ของ user คนนี้ (payload.role) อยู่ในลิสต์ที่อนุญาตไหม
      //    ถ้าไม่ได้ระบุ role เลย (roles.length === 0) แปลว่าแค่ login ก็พอ
      //    ไม่ต้องเช็ก role เพิ่ม
      if (roles.length && !roles.includes(payload.role)) {
        console.log('[AUTH] -> 403 Forbidden (role not allowed)', roles, 'got:', payload.role);
        return res.status(403).json({ success: false, message: 'Forbidden' });
        // 403 Forbidden = "รู้จักตัวตนคุณแล้ว (login ผ่าน) แต่ไม่มีสิทธิ์ทำสิ่งนี้"
        // ต่างจาก 401 Unauthorized ที่แปลว่า "ยังไม่รู้จักตัวตนคุณเลย"
      }

      // 7) ผ่านทุกการตรวจสอบแล้ว — แนบข้อมูล user ที่ถอดได้จาก token ไว้ที่
      //    req.user เพื่อให้ controller ด้านหลัง (ที่ทำงานหลัง middleware นี้)
      //    เอาไปใช้ต่อได้ เช่น req.user.id, req.user.role โดยไม่ต้อง query
      //    ฐานข้อมูลซ้ำเพื่อรู้ว่า "ใครกำลังเรียก API นี้อยู่"
      req.user = payload;
      return next();
      // next() คือการบอก Express ว่า "ตรวจผ่านแล้ว ให้ไปทำงานขั้นต่อไป"
      // (เช่น middleware ตัวถัดไป หรือ controller ของ route นั้น ๆ)
    } catch (e) {
      // ถ้ามีข้อผิดพลาดเกิดขึ้นระหว่างตรวจสอบ (เช่น token ปลอม, token หมดอายุ,
      // หรือ error อื่นที่ไม่คาดคิด) จะมาเข้า catch นี้
      console.log('[AUTH] ERROR:', e.name, e.message);
      // ถ้า error มาจาก jsonwebtoken โดยตรง (ชื่อ error คือ 'JsonWebTokenError'
      // เช่น token รูปแบบผิด/ลายเซ็นไม่ตรง) ให้ตอบ 401 (ปัญหาเรื่องตัวตน)
      // ถ้าเป็น error อื่นที่ไม่เกี่ยวกับ token โดยตรง ให้ถือว่าเป็น 500
      // (ข้อผิดพลาดฝั่ง server เอง) — หมายเหตุ: 'TokenExpiredError' (token
      // หมดอายุ) จะไม่เข้าเงื่อนไขนี้ จึงถูกตีเป็น 500 ไปด้วย ถ้าต้องการแยก
      // กรณี "token หมดอายุ" ให้ตอบ 401 เหมือนกัน สามารถเพิ่มเงื่อนไขเช็ก
      // e.name === 'TokenExpiredError' ควบคู่ไปด้วยได้
      e.status = e.name === 'JsonWebTokenError' ? 401 : 500;
      next(e);
      // ส่ง error ต่อให้ error-handling middleware (middlewares/error.js)
      // เป็นคนจัดการตอบ response สุดท้ายจริง ๆ (ไม่ตอบ res เองตรงนี้)
    }
  };
};
