// middlewares/error.js
//
// "Error-handling middleware" กลางของทั้งแอป — Express แยกแยะ middleware
// ประเภทนี้ได้จากการที่ฟังก์ชันรับพารามิเตอร์ "4 ตัว" พอดี (err, req, res,
// next) ต่างจาก middleware ปกติที่รับแค่ 3 ตัว (req, res, next)
//
// หน้าที่ของมันคือเป็น "ด่านสุดท้าย" ที่ดักจับ error ทุกตัวที่เกิดขึ้นใน route
// handler ใด ๆ ก่อนหน้า (ไม่ว่าจะเรียก next(err) เองตรง ๆ หรือโยน exception
// ในฟังก์ชัน async ที่ Express ดักให้อัตโนมัติ) แล้วแปลงให้เป็น JSON response
// รูปแบบเดียวกันเสมอ แทนที่แต่ละ route จะต้องเขียน try/catch ตอบ error เอง
// ซ้ำ ๆ กันทุกที่ ต้องถูกประกาศ (app.use(error)) เป็น middleware "ตัวสุดท้าย"
// ใน app.js เสมอ (ดูคอมเมนต์ใน app.js ประกอบ)

module.exports = (err, req, res, next) => {
  const status = err.status || 500;
  // ถ้า error object มีการตั้งค่า .status ไว้ล่วงหน้า (เช่นใน
  // middlewares/auth.js ที่เขียน e.status = 401 ก่อนเรียก next(e)) ให้ใช้ค่า
  // นั้น ถ้าไม่มีเลยให้ถือว่าเป็น 500 (Internal Server Error) ซึ่งหมายถึง
  // "เกิดข้อผิดพลาดที่ไม่ได้คาดคิดไว้ล่วงหน้าฝั่ง server"
  const message = err.message || 'Internal Server Error';
  // ใช้ข้อความจาก error โดยตรงถ้ามี ไม่งั้นใช้ข้อความกลาง ๆ แทน
  if (process.env.NODE_ENV !== 'production') {
    console.error('[ERROR]', err);
    // พิมพ์รายละเอียด error เต็ม ๆ (รวม stack trace) ออก console เฉพาะตอนไม่ได้
    // รันในโหมด production เท่านั้น เพื่อช่วย debug ตอน dev — แต่ไม่อยากให้
    // รายละเอียดภายใน (เช่น query SQL, path ไฟล์บนเครื่อง) หลุดไปอยู่ใน log
    // ของ production โดยไม่จำเป็น (ควรมีระบบ log ที่เหมาะสมกว่านี้แทนในของจริง)
  }
  res.status(status).json({ success: false, message });
  // ตอบกลับไปหา client เป็น JSON รูปแบบเดียวกันทุกครั้งไม่ว่า error จะเกิดจาก
  // ตรงไหนของแอป ทำให้ฝั่ง frontend เขียนโค้ดเช็ก error ได้ง่าย เพราะรู้
  // โครงสร้าง response ที่แน่นอนเสมอ (success: false, message: "...")
  //
  // หมายเหตุ: ไม่ได้ส่ง stack trace หรือรายละเอียดภายในกลับไปให้ client เห็น
  // (ต่างจากที่ log ออก console ด้านบน) เพราะการส่งรายละเอียด error ภายใน
  // กลับไปให้ผู้ใช้จริงเห็น อาจเป็นช่องทางให้ผู้ไม่หวังดีรู้โครงสร้างระบบภายในได้
};
