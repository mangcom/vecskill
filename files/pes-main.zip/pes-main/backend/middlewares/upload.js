// middlewares/upload.js
//
// Middleware สำหรับรับไฟล์ที่ผู้ใช้อัปโหลด (multipart/form-data) ใช้ไลบรารี
// multer ซึ่งเป็นมาตรฐานของวงการ Express สำหรับเรื่องนี้ — Express เองอ่าน
// body แบบ multipart/form-data (ฟอร์มที่มีไฟล์แนบ) ไม่ได้โดยตรง ต้องอาศัย
// multer แปลงให้กลายเป็น req.file (ไฟล์เดียว) หรือ req.files (หลายไฟล์) และ
// req.body (ฟิลด์ข้อความอื่น ๆ ในฟอร์มเดียวกัน) ให้ใช้งานได้ง่าย
//
// ไฟล์นี้ export เป็น instance ของ multer ที่ตั้งค่าไว้ล่วงหน้าแล้ว (ที่เก็บ
// ไฟล์, การตั้งชื่อไฟล์, ชนิดไฟล์ที่อนุญาต, ขนาดสูงสุด) ให้ route ต่าง ๆ เอาไป
// ใช้ซ้ำได้เลย เช่น upload.single('file') ดูตัวอย่างการใช้งานจริงใน
// routes/upload.routes.js และ routes/attachments.js

const multer = require('multer');
const path = require('path');
const fs = require('fs');

const MAX_MB = Number(process.env.UPLOAD_MAX_MB || 10);
// ขนาดไฟล์สูงสุดที่ยอมรับ (หน่วยเป็น MB) อ่านจาก .env ได้ (ตัวแปร
// UPLOAD_MAX_MB) ถ้าไม่ได้ตั้งไว้ใช้ค่าเริ่มต้น 10 MB
const MAX_BYTES = MAX_MB * 1024 * 1024;
// แปลงจาก MB เป็น byte เพราะ multer ต้องการค่าขนาดไฟล์เป็น byte
// (1 MB = 1024 KB, 1 KB = 1024 byte)

// อนุญาต mimetype ทั่วไป (แนะนำ: map ตาม evidence_type ในชั้น controller เพิ่มเติม)
const ALLOWED = new Set([
  // ใช้ Set แทน Array เพราะเช็กว่า "มีอยู่ในลิสต์ไหม" ด้วย .has() จะเร็วกว่า
  // .includes() ของ Array (ไม่มีผลต่างชัดเจนกับลิสต์สั้น ๆ แบบนี้ แต่เป็น
  // ธรรมเนียมที่ดีเวลาต้องเช็ก "มีอยู่ในกลุ่มไหม" บ่อย ๆ)
  'application/pdf',
  'image/png', 'image/jpeg', 'image/webp',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/zip', 'application/x-zip-compressed'
]);
// รายชื่อ MIME type ที่อนุญาตให้อัปโหลด (PDF, รูปภาพ, เอกสาร Office, ไฟล์ zip)
// หมายเหตุในคอมเมนต์เดิม: ถ้าอยากเข้มงวดกว่านี้ตามชนิดหลักฐานแต่ละประเภท
// (evidence_type) เช่น "หลักฐานประเภท A ต้องเป็น PDF เท่านั้น" ควรเพิ่มการ
// ตรวจสอบอีกชั้นในฝั่ง controller (ดู controllers/upload.controller.js)
// เพราะ middleware ตัวนี้เช็กแบบรวม ๆ ทั้งระบบเท่านั้น ไม่รู้บริบทของ
// evidence_type ที่กำลังอัปโหลดอยู่

function ensureDir(dir) {
  // ฟังก์ชันช่วยสร้างโฟลเดอร์ปลายทางถ้ายังไม่มี (กันปัญหา "เขียนไฟล์ไม่ได้
  // เพราะโฟลเดอร์ไม่มีอยู่จริง")
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  // recursive: true ทำให้สร้างโฟลเดอร์ซ้อนกันหลายชั้นได้ในคำสั่งเดียว เช่น
  // ถ้า uploads/1/4/ ยังไม่มีทั้ง uploads/1/ และ uploads/1/4/ ก็จะถูกสร้างให้
  // ครบทุกชั้นเอง ไม่ต้องไล่สร้างทีละชั้น
}

const storage = multer.diskStorage({
  // multer.diskStorage คือการบอกว่า "เก็บไฟล์ที่อัปโหลดลงดิสก์จริง ๆ" (ต่าง
  // จาก multer.memoryStorage ที่เก็บไว้ใน RAM ชั่วคราว เหมาะกับไฟล์เล็ก ๆ ที่
  // จะประมวลผลต่อทันทีแล้วไม่เก็บถาวร) ต้องกำหนดฟังก์ชัน destination (เก็บที่
  // ไหน) และ filename (ตั้งชื่อไฟล์ว่าอะไร) เอง
  destination: (req, file, cb) => {
    // ฟังก์ชันนี้ถูกเรียกครั้งเดียวต่อไฟล์ที่อัปโหลด เพื่อตัดสินใจว่าไฟล์นี้
    // ควรถูกเก็บไว้ที่โฟลเดอร์ไหน — cb คือ callback ที่ต้องเรียกเพื่อบอกผลลัพธ์
    // (cb(error, pathที่จะเก็บ) ถ้าไม่มี error ให้ส่ง null เป็นตัวแรก)
    console.log('__dirname', __dirname);
    const base = path.join(__dirname, '..', 'uploads');
    // __dirname คือโฟลเดอร์ที่ไฟล์นี้อยู่ (backend/middlewares/) ถอยกลับไป 1
    // ชั้น (..) แล้วต่อด้วย 'uploads' จะได้ path แบบ absolute ไปที่
    // backend/uploads/ เสมอ ไม่ว่าจะรันคำสั่งจากที่ไหนก็ตาม
    const period = String(req.body.period_id || 'misc');
    // ใช้ period_id ของรอบการประเมินเป็นชื่อโฟลเดอร์ย่อย ถ้าไม่มีส่งมาให้ใช้
    // คำว่า 'misc' (เบ็ดเตล็ด) แทน กันโค้ดพังถ้า field นี้หายไป
    const evaluatee = String((req.user && req.user.id) || req.body.evaluatee_id || 'unknown');
    // ใช้ id ของผู้ถูกประเมิน (evaluatee) เป็นชื่อโฟลเดอร์ย่อยอีกชั้น — ถ้า
    // request นี้ผ่าน middleware auth มาแล้ว req.user.id จะมีค่า (กรณีผู้ใช้
    // อัปโหลดไฟล์ของตัวเอง) แต่ถ้าเป็น evaluator ที่อัปโหลดแทนคนอื่น อาจต้อง
    // พึ่ง req.body.evaluatee_id แทน ถ้าไม่มีทั้งคู่เลยใช้คำว่า 'unknown'
    const dest = path.join(base, period, evaluatee);
    // ผลลัพธ์คือโครงสร้างโฟลเดอร์แบบ uploads/<period_id>/<evaluatee_id>/
    // ทำให้ไฟล์ของแต่ละคนในแต่ละรอบประเมินแยกกันเป็นระเบียบ หาไฟล์ย้อนหลังง่าย
    ensureDir(dest);
    // สร้างโฟลเดอร์ปลายทางถ้ายังไม่มี (ดูฟังก์ชัน ensureDir ด้านบน)
    console.log('Upload destination:', dest);
    cb(null, dest);
    // บอก multer ว่า "ไม่มี error (null) ให้เก็บไฟล์นี้ที่ path dest"
  },
  filename: (req, file, cb) => {
    // ฟังก์ชันนี้ตัดสินใจว่าจะตั้งชื่อไฟล์ที่เก็บจริงบนดิสก์ว่าอะไร (ไม่ใช่ชื่อ
    // ไฟล์เดิมตรง ๆ เพราะอาจมีอักขระแปลก ๆ หรือชื่อซ้ำกันจนไฟล์เก่าโดนทับ)
    const ext = path.extname(file.originalname).toLowerCase();
    // นามสกุลไฟล์เดิม (เช่น ".PDF" -> ".pdf" แปลงเป็นตัวพิมพ์เล็กให้สม่ำเสมอ)
    const safe = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9._-]/g, '_');
    // ชื่อไฟล์เดิม (ไม่รวมนามสกุล) แล้วแทนที่อักขระที่ "ไม่ใช่" ตัวอักษร
    // อังกฤษ/ตัวเลข/จุด/ขีดกลาง/ขีดล่าง ทั้งหมดด้วย "_" — ป้องกันปัญหาชื่อไฟล์
    // มีอักขระพิเศษ (เช่น ภาษาไทย, ช่องว่าง, เครื่องหมายที่ระบบไฟล์บางตัวไม่รองรับ)
    // จนทำให้เขียนไฟล์ลงดิสก์ไม่ได้หรือเกิดปัญหา encoding ภายหลัง
    const name = `${Date.now()}_${safe}${ext}`;
    // ใส่ timestamp (Date.now() = เวลาปัจจุบันเป็นตัวเลข มิลลิวินาที) นำหน้า
    // ชื่อไฟล์เสมอ เพื่อให้ชื่อไฟล์ไม่ซ้ำกันแม้จะอัปโหลดไฟล์ชื่อเดียวกันซ้ำหลาย
    // ครั้งก็ตาม (กันไฟล์เก่าถูกเขียนทับโดยไม่ได้ตั้งใจ)
    cb(null, name);
  }
});

function fileFilter(req, file, cb) {
  // ฟังก์ชันนี้ถูกเรียกก่อนจะเริ่มเขียนไฟล์ลงดิสก์จริง เพื่อเช็กว่า "ชนิดไฟล์"
  // (file.mimetype ที่เบราว์เซอร์ส่งมาบอก) อยู่ในลิสต์ที่อนุญาต (ALLOWED) ไหม
  if (!ALLOWED.has(file.mimetype)) {
    return cb(new Error('Unsupported file type'), false);
    // เรียก cb พร้อม error และ false (false = "ไม่รับไฟล์นี้") multer จะหยุด
    // ไม่เขียนไฟล์นี้ลงดิสก์ แล้วโยน error ออกไปให้ route จัดการต่อ (สุดท้าย
    // จะไปโดน error handler กลางจับ แล้วตอบกลับไปเป็น error response)
  }
  cb(null, true);
  // ไม่มี error, true = "รับไฟล์นี้ได้ ให้เขียนลงดิสก์ตามปกติ"
}


const upload = multer({ storage, fileFilter, limits: { fileSize: MAX_BYTES } });
// ประกอบทุกอย่างเข้าด้วยกันเป็น instance ของ multer ตัวเดียว: เก็บไฟล์ตามที่
// storage กำหนด, กรองชนิดไฟล์ตาม fileFilter, และจำกัดขนาดไฟล์สูงสุดตาม
// limits.fileSize (ถ้าไฟล์ใหญ่เกินนี้ multer จะปฏิเสธเอง โดยอัตโนมัติ)
module.exports = upload;   // ← export อินสแตนซ์ตรง ๆ
// route ที่ต้องการรับไฟล์จะ import ตัวนี้มาแล้วเรียกใช้เป็น
// upload.single('file') (รับไฟล์เดียว ชื่อ field ต้องเป็น "file" พอดี ไม่งั้น
// multer จะโยน error "Unexpected field") หรือ upload.array(...)/
// upload.fields(...) ถ้าต้องรับหลายไฟล์ในอนาคต
