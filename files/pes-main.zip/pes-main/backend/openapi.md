# คู่มือ API — Personnel Evaluation System (ฉบับอ่านง่าย)

เอกสารนี้อธิบาย [openapi.json](openapi.json) (สเปก OpenAPI 3.0.3 ที่ server
ใช้สร้างหน้า Swagger UI แบบ interactive ที่ **http://localhost:7000/docs** —
เปลี่ยน `localhost` เป็น host ที่คุณใช้เปิดแอปจริงได้ตามปกติ) ด้วยภาษาธรรมดา
พร้อม cross-reference กลับไปยังไฟล์โค้ดจริงที่ implement แต่ละ endpoint ไว้
ให้คนที่เอา template นี้ไปต่อยอด เรียนรู้ได้เร็วขึ้นโดยไม่ต้องไล่อ่านทุกไฟล์
เอง

> **สเปกนี้ตรงกับโค้ดจริง 100%** — ตรวจสอบแล้วว่าทุก path/method ที่ลงไว้ใน
> `openapi.json` มี route รองรับจริงในโฟลเดอร์ `routes/*.js` (เดิม
> `openapi.json` เคยมี endpoint ที่ไม่มีโค้ดรองรับเลยอย่าง `/api/results`,
> `/api/reports/*`, `/api/assignments` ปนอยู่ ได้ลบออกแล้ว พร้อมเพิ่ม
> endpoint จริงที่ขาดไปเข้ามาครบ)

## สารบัญ

- [การยืนยันตัวตน (Authentication)](#การยืนยันตัวตน-authentication)
- [Health](#health)
- [Auth](#auth)
- [Users](#users)
- [Periods & Indicators](#periods--indicators)
- [Attachments — endpoint อัปโหลดจริงที่หน้าเว็บใช้](#attachments--endpoint-อัปโหลดจริงที่หน้าเว็บใช้)
- [Upload (legacy) — endpoint อัปโหลดอีกชุดคู่ขนาน](#upload-legacy--endpoint-อัปโหลดอีกชุดคู่ขนาน)
- [รูปแบบ response กลาง](#รูปแบบ-response-กลาง)
- [สิ่งที่ตั้งใจไม่ทำให้สมบูรณ์ (ใช้สอน)](#สิ่งที่ตั้งใจไม่ทำให้สมบูรณ์-ใช้สอน)

---

## การยืนยันตัวตน (Authentication)

เกือบทุก endpoint (ยกเว้น `/health` และ `/api/auth/login`) ต้องแนบ JWT ที่ได้
จากการ login มาด้วยทุกครั้ง ผ่าน HTTP header:

```
Authorization: Bearer <accessToken>
```

กลไกตรวจสอบอยู่ที่ [middlewares/auth.js](middlewares/auth.js) — เรียกใช้แบบ
`auth('admin')`, `auth('evaluator','admin')`, หรือ `auth()` (login เฉย ๆ พอ
role อะไรก็ได้) แล้วแต่ route แต่ละอัน ถ้าไม่แนบ token หรือ token ผิด/หมดอายุ
จะได้ `401 Unauthorized`; ถ้า token ถูกต้องแต่ role ไม่ตรงที่ route กำหนดไว้
จะได้ `403 Forbidden`

ตัวอักษร role ที่มีจริงในระบบ: `admin`, `evaluator`, `evaluatee` (ไม่มีค่า
`user` แม้สเปกเวอร์ชันเก่าจะเคยเขียนผิดไว้ก็ตาม — ดู `schema.sql` คอลัมน์
`role ENUM(...)`)

---

## Health

### `GET /health`

เช็กว่า server ยังมีชีวิตอยู่ไหม ไม่ต้อง login — [app.js](app.js:32)

```json
200 { "service": "okoak", "time": "2026-01-01T00:00:00.000Z" }
```

---

## Auth

### `POST /api/auth/login`

Login ด้วย email/password รับ JWT กลับมาใช้ในทุก request ถัดไป — ไม่ต้อง
login ก่อน (เป็นจุดเริ่มต้น) — [controllers/auth.controller.js](controllers/auth.controller.js)

**Body** (`application/json`):

```json
{ "email": "admin@vecskill.ovec", "password": "12345678" }
```

**Response:**

| สถานะ | ความหมาย |
|---|---|
| `200` | `{ success:true, accessToken, user:{ id,name,email,role } }` |
| `400` | ไม่ได้ส่ง email/password มา |
| `401` | อีเมลไม่มีในระบบ หรือรหัสผ่านผิด |

Demo credentials ทุกตัว (seed ไว้ใน `schema.sql`) ใช้รหัสผ่านเดียวกันหมด:
`admin@vecskill.ovec`, `eva.it@vecskill.ovec`, `eva.me@vecskill.ovec`,
`t.it01@vecskill.ovec`, `t.me01@vecskill.ovec`, `t.acc01@vecskill.ovec` /
`12345678`

---

## Users

จัดการผู้ใช้ — [controllers/users.controller.js](controllers/users.controller.js),
ผูก route ไว้ที่ [routes/users.routes.js](routes/users.routes.js)

### `GET /api/users/server`

รายชื่อผู้ใช้แบบแบ่งหน้าฝั่ง server (pagination/search/sort) — role ไหนก็ได้
ที่ login อยู่เรียกได้

**Query:** `page` (default 1), `itemsPerPage` (default 10), `sortBy`
(`id`|`name_th`|`email`|`role`|`created_at`, default `id`), `sortDesc`
(default `true`), `search` (ค้นแบบ LIKE ข้าม id/name_th/email/role พร้อมกัน)

```json
200 { "success":true, "items":[...], "total":6, "page":1, "itemsPerPage":10 }
```

### `GET /api/users`

รายชื่อผู้ใช้แบบง่าย (ไม่แบ่งหน้าฝั่ง server) — **admin เห็นทุกคน** ส่วน
role อื่นเห็นได้แค่ "ข้อมูลของตัวเอง" เท่านั้น (ตัวอย่างการทำ RBAC)

```json
200 { "success":true, "items":[...], "total":N }
```

### `POST /api/users`

สร้างผู้ใช้ใหม่ — **จำกัดเฉพาะ `admin`**

**Body:**

```json
{ "name_th": "ครูทดสอบ", "email": "test@vecskill.ovec", "password": "12345678", "role": "evaluatee" }
```

(`role` ไม่บังคับ — ไม่ส่งมาจะ default เป็น `evaluatee`)

| สถานะ | ความหมาย |
|---|---|
| `201` | `{ success:true, data:{ id,name_th,email,role,created_at } }` |
| `400` | ขาด `name_th`/`email`/`password` |
| `409` | อีเมลซ้ำกับที่มีอยู่แล้ว |

### `GET /api/users/{id}`

ดูข้อมูลผู้ใช้คนเดียวตาม id — role ไหนก็ได้ที่ login อยู่ (**หมายเหตุ:**
endpoint นี้ไม่ได้เช็กสิทธิ์เพิ่มแบบ `GET /api/users` ด้านบน — role ไหนก็
login อยู่ก็ดูของใครก็ได้ตาม id)

| สถานะ | ความหมาย |
|---|---|
| `200` | `{ success:true, data:{...} }` |
| `404` | ไม่พบผู้ใช้ |

### `PUT /api/users/{id}`

แก้ไขข้อมูลผู้ใช้ (partial update — ส่งแค่ฟิลด์ที่จะแก้ก็พอ) —
**จำกัดเฉพาะ `admin`**

**Body:** `{ "name_th"?, "email"?, "role"?, "password"? }` — ถ้าส่ง
`password` มาจะถูก hash แล้วเขียนทับรหัสผ่านเดิม

| สถานะ | ความหมาย |
|---|---|
| `200` | `{ success:true, data:{...} }` |
| `404` | ไม่พบผู้ใช้ |
| `409` | อีเมลใหม่ซ้ำกับคนอื่น (ไม่นับตัวเอง) |

### `DELETE /api/users/{id}`

ลบผู้ใช้ — **จำกัดเฉพาะ `admin`**

| สถานะ | ความหมาย |
|---|---|
| `200` | `{ success:true }` |
| `403` | ไม่ใช่ admin |
| `404` | ไม่พบผู้ใช้ |

---

## Periods & Indicators

ข้อมูลประกอบฟอร์มอัปโหลดหลักฐาน (หน้า `/upload` เรียกชุดนี้ก่อนให้ผู้ใช้
เลือก) — [routes/attachments.js](routes/attachments.js) — role ไหนก็ได้ที่
login อยู่ (`evaluatee`/`evaluator`/`admin`)

### `GET /api/periods/active`

รายชื่อ "รอบการประเมิน" ที่เปิดใช้งานอยู่ (`is_active = 1`)

```json
200 [ { "id":1, "code":"Y2568", "name_th":"การประเมินครูประจำปี 2568" } ]
```

### `GET /api/indicators`

รายชื่อ "ตัวชี้วัด" ที่ active อยู่ **ทั้งหมด**

**Query:** `period_id` (รับไว้เป็น parameter แต่ **ยังไม่ได้ใช้กรองจริง** —
ดูหมายเหตุ "สิ่งที่ตั้งใจไม่ทำให้สมบูรณ์" ด้านล่าง)

```json
200 [ { "id":1, "code":"T1-PLAN", "name_th":"แผนการจัดการเรียนรู้", "type":"score_1_4" } ]
```

### `GET /api/indicators/{id}/evidence-types`

รายชื่อ "ชนิดหลักฐาน" ที่อนุญาตให้แนบกับตัวชี้วัดนี้ได้ (ดึงจากตารางเชื่อม
`indicator_evidence`)

```json
200 [ { "id":1, "name_th":"แผนการจัดการเรียนรู้", "mime_list":["application/pdf","image/png","image/jpeg","image/webp"], "max_mb":10 } ]
```

> `mime_list`/`max_mb` เป็นค่าคงที่เดียวกันทุก evidence_type ตอนนี้ (ตาราง
> `evidence_types` ในฐานข้อมูลยังไม่มีคอลัมน์เก็บค่านี้แยกต่อรายการ) — ถ้าจะ
> ต่อยอดให้กำหนดชนิด/ขนาดไฟล์เฉพาะต่อ evidence_type จริงจัง ดูโค้ดที่ถูก
> comment ปิดไว้ในไฟล์เดียวกัน (เวอร์ชันที่ JOIN กับ `evidence_types` จริง)

---

## Attachments — endpoint อัปโหลดจริงที่หน้าเว็บใช้

### `POST /api/attachments`

**นี่คือ endpoint ที่ [frontend/pages/upload.vue](../frontend/pages/upload.vue)
เรียกใช้งานจริง** — [routes/attachments.js](routes/attachments.js)

**สิทธิ์:** `evaluatee` (อัปโหลดของตัวเอง) หรือ `evaluator` (อัปโหลดแทน
evaluatee ที่ตนดูแล — ต้องส่ง `evaluatee_id` มาด้วย)

**Body** (`multipart/form-data`):

| field | บังคับ | หมายเหตุ |
|---|---|---|
| `period_id` | ✅ | ต้องเป็นรอบที่ยัง active อยู่ |
| `indicator_id` | ✅ | ต้องเป็นตัวชี้วัดที่ active อยู่ |
| `evidence_type_id` | ✅ | ต้องเป็นคู่ที่ได้รับอนุญาตกับ `indicator_id` |
| `evaluatee_id` | เฉพาะ role `evaluator` | ต้องเป็นคู่ที่ถูก assign ไว้ในรอบนี้จริง |
| `note` | ไม่บังคับ | หมายเหตุ/คำอธิบายไฟล์ |
| `file` | ✅ | ชื่อ field ต้องเป็น `"file"` เป๊ะ ๆ |

**Response:**

| สถานะ | ความหมาย |
|---|---|
| `201` | `{ id, message:"uploaded", meta:{...}, file:{name,mime,size_bytes} }` |
| `403` | ไม่ได้ถูก assign ในรอบนี้ / evaluator-evaluatee ไม่ใช่คู่กัน |
| `404` | period หรือ indicator ไม่ active |
| `409` | indicator/evidence_type ไม่ได้รับอนุญาตให้คู่กัน |
| `422` | ข้อมูลไม่ครบ หรือไม่มีไฟล์แนบมา |

ชนิดไฟล์ที่อนุญาตทั้งระบบ (เช็กที่ตัว multer middleware อีกชั้นหนึ่งเสมอ
ไม่ว่า evidence_type จะกำหนดไว้ยังไง) — ดู
[middlewares/upload.js](middlewares/upload.js): PDF, PNG/JPEG/WEBP, Word,
Excel, PowerPoint, Zip — ขนาดสูงสุด default 10MB (ตั้งค่าได้ผ่าน
`.env` → `UPLOAD_MAX_MB`)

---

## Upload (legacy) — endpoint อัปโหลดอีกชุดคู่ขนาน

ชุด endpoint นี้ ([routes/upload.routes.js](routes/upload.routes.js) +
[controllers/upload.controller.js](controllers/upload.controller.js)) ใช้
ตาราง `attachments` เดียวกันกับด้านบน แต่เขียนเป็นคนละ controller/คนละ
query โดยสิ้นเชิง — ของเดิมผู้พัฒนาเขียนไว้คู่ขนานกัน 2 แนวทาง **ไม่ใช่
endpoint ที่หน้าเว็บ `/upload` เรียกใช้จริงตอนนี้** แต่ยังใช้งานได้ปกติ
ถ้าอยากต่อยอดจากแนวทางนี้แทน (มี repository layer ให้แล้ว ดู
[repositories/attachments.js](repositories/attachments.js))

### `POST /api/upload/evidence`

อัปโหลดหลักฐานของตัวเอง — **เฉพาะ `evaluatee`**

**Body** (`multipart/form-data`): `period_id`, `indicator_id`,
`evidence_type_id`, `file` (ทั้งหมดบังคับ — ไม่รองรับ `note` หรือ
`evaluatee_id` แทนคนอื่นเหมือน `/api/attachments`)

| สถานะ | ความหมาย |
|---|---|
| `201` | `{ success:true, data:{...attachment, url} }` |
| `400` | ข้อมูลไม่ครบ / ไม่มีไฟล์ |
| `401` | ไม่มี user จาก token |
| `403` | period ปิดแล้ว หรือไม่ได้ถูก assign ในรอบนี้ |

### `GET /api/upload/mine`

รายการไฟล์หลักฐานของตัวเอง — **เฉพาะ `evaluatee`**

**Query (ไม่บังคับ):** `period_id`, `indicator_id`, `evidence_type_id`

```json
200 { "success":true, "data":[ {...attachment, url} ] }
```

### `DELETE /api/upload/{id}`

ลบไฟล์หลักฐานของตัวเอง — **เฉพาะ `evaluatee`**, ลบได้เฉพาะไฟล์ของตัวเองและ
เฉพาะตอนที่ period ยังเปิดอยู่

| สถานะ | ความหมาย |
|---|---|
| `200` | `{ success:true, message:"deleted" }` |
| `403` | period ปิดแล้ว |
| `404` | ไม่พบไฟล์ หรือไม่ใช่ของคุณ |

### `PATCH /api/upload/{id}`

แก้ไข "ข้อมูลประกอบ" ของไฟล์หลักฐาน (เปลี่ยน `indicator_id`/
`evidence_type_id` ที่ผูกไว้) โดย**ไม่แตะไฟล์จริง** — เฉพาะ `evaluatee`

**Body:** `{ "indicator_id"?, "evidence_type_id"? }`

| สถานะ | ความหมาย |
|---|---|
| `200` | `{ success:true, data:{...} }` |
| `400` | คู่ indicator/evidence_type ใหม่ไม่ถูกต้อง |
| `403` | period ปิดแล้ว |
| `404` | ไม่พบไฟล์ หรือไม่ใช่ของคุณ |

### `PUT /api/upload/{id}/file`

เปลี่ยน "ไฟล์จริง" ของหลักฐานที่เคยอัปโหลดไว้ (record เดิมยังอยู่ แค่สลับ
ไฟล์ใหม่เข้ามาแทน ไฟล์เก่าถูกลบทิ้ง) — เฉพาะ `evaluatee`

**Body** (`multipart/form-data`): `file` (บังคับ)

| สถานะ | ความหมาย |
|---|---|
| `200` | `{ success:true, data:{...} }` |
| `400` | ไม่มีไฟล์แนบมา |
| `403` | period ปิดแล้ว |
| `404` | ไม่พบไฟล์ หรือไม่ใช่ของคุณ |

### `GET /api/upload/evaluatee/{evaluateeId}`

evaluator ดูรายการไฟล์หลักฐานของ evaluatee ที่ตนดูแล — **เฉพาะ
`evaluator`**

**Query (ไม่บังคับ):** `period_id`

```json
200 { "success":true, "data":[ {...attachment, url} ] }
```

> ⚠️ **หมายเหตุด้านความปลอดภัย:** endpoint นี้ยังไม่เช็กว่า evaluator คนที่
> เรียกถูก assign ให้ดูแล `evaluateeId` นี้จริงหรือเปล่า — ตอนนี้แค่ role
> ต้องเป็น `evaluator` เท่านั้นที่ถูกเช็ก (ต่างจาก `POST /api/attachments`
> ที่เช็กคู่ evaluator-evaluatee จริงก่อนเสมอ) ถ้าจะใช้งานจริงจัง ควรเพิ่มการ
> เช็กด้วย `asgRepo.hasPairInPeriod(...)` ก่อนอนุญาตให้ดูข้อมูล — ดู
> คอมเมนต์ในไฟล์ `controllers/upload.controller.js` ประกอบ

---

## รูปแบบ response กลาง

Endpoint ส่วนใหญ่ (ยกเว้นชุด `/api/periods`, `/api/indicators`,
`/api/attachments`, และ `/api/upload/evidence` ที่ตอบรูปแบบของตัวเอง) ตอบ
กลับเป็น JSON รูปแบบเดียวกัน:

```json
{ "success": true,  "data": { ... } }
{ "success": false, "message": "..." }
```

Error ที่ไม่ได้ตอบเองในแต่ละ route (เช่น error ไม่คาดคิดจากฐานข้อมูล) จะถูก
ส่งต่อให้ [middlewares/error.js](middlewares/error.js) จัดการรวมศูนย์ ตอบ
กลับเป็น `{ success:false, message }` เหมือนกันเสมอ พร้อม HTTP status ที่
ถูกต้อง (ดีฟอลต์ `500` ถ้าไม่ได้ระบุไว้)

---

## สิ่งที่ตั้งใจไม่ทำให้สมบูรณ์ (ใช้สอน)

จุดเหล่านี้เป็นข้อจำกัด/จุดที่ตั้งใจเก็บไว้ให้เรียนรู้และต่อยอดเอง ไม่ใช่
บั๊กที่ลืมแก้:

1. `GET /api/indicators?period_id=` รับ `period_id` มาแต่ยังไม่ได้ใช้กรอง
   จริง (คืนตัวชี้วัดที่ active ทั้งหมดเสมอ)
2. `GET /api/indicators/{id}/evidence-types` คืน `mime_list`/`max_mb` เป็น
   ค่าคงที่เดียวกันทุก evidence_type (ตารางจริงยังไม่มีคอลัมน์เก็บแยก)
3. `GET /api/upload/evaluatee/{evaluateeId}` ไม่เช็กว่า evaluator ถูก assign
   ให้ดูแล evaluatee คนนั้นจริงไหม (ดูหมายเหตุด้านบน)
4. มี endpoint อัปโหลด **สองชุดคู่ขนาน** (`/api/attachments` กับ
   `/api/upload/*`) ที่ทำงานคล้ายกันแต่คนละ code path — ของจริงที่ใช้งาน
   ตอนนี้คือ `/api/attachments`
5. `POST /api/attachments` ตอบ error เองใน route ตรง ๆ (ไม่เรียก `next(e)`
   ส่งต่อให้ error handler กลางเหมือน endpoint อื่น ๆ)

รายละเอียดเชิงลึกของแต่ละจุด (เหตุผล, โค้ดจริง) ดูในคอมเมนต์ของไฟล์ที่
อ้างอิงไว้ข้างบนแต่ละ endpoint ได้เลย
