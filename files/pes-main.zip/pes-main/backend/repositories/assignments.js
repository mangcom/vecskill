// repositories/assignments.js
//
// "Repository" คือชั้นที่รวบรวมการคิวรีฐานข้อมูลของตาราง "assignments"
// (ตารางที่บอกว่า evaluator (ผู้ประเมิน) คนไหน ถูกมอบหมายให้ประเมิน
// evaluatee (ผู้ถูกประเมิน) คนไหน ในรอบการประเมิน (period) ไหนบ้าง) ไว้ที่
// เดียว แทนที่จะเขียนคิวรี SQL/knex กระจัดกระจายอยู่ในหลาย controller
//
// ข้อดีของการแยกชั้นนี้ออกมา: ถ้าวันหนึ่งต้องเปลี่ยนโครงสร้างตาราง
// assignments (เช่น เปลี่ยนชื่อคอลัมน์ หรือย้ายไปใช้ตารางกลาง many-to-many
// ที่ซับซ้อนขึ้น) จะแก้แค่ไฟล์นี้ไฟล์เดียว ไม่ต้องไล่แก้ทุก controller ที่
// เคยเขียนคิวรีตรง ๆ กระจายอยู่หลายที่

const db = require('../db/knex');
// นำ instance ของ knex (ตัวเชื่อมต่อฐานข้อมูล) ที่ตั้งค่าไว้แล้วมาใช้
const TABLE = 'assignments';
// เก็บชื่อตารางไว้เป็นค่าคงที่ตัวเดียว กันพิมพ์ผิดซ้ำ ๆ ในแต่ละฟังก์ชัน

// ยืนยันว่า evaluatee อยู่ในงวดนั้น (ไม่ผูก evaluator)
exports.hasEvaluateeInPeriod = async ({ period_id, evaluatee_id }) => {
  // ใช้ destructuring รับ object ที่มี key period_id และ evaluatee_id เข้ามา
  // เลือกใช้วิธีนี้ (รับเป็น object) แทนรับทีละพารามิเตอร์ เพื่อให้เวลาเรียกใช้
  // งานชัดเจนว่าใส่ค่าไหนตรงไหน เช่น
  // hasEvaluateeInPeriod({ period_id: 1, evaluatee_id: 4 }) อ่านง่ายกว่า
  // hasEvaluateeInPeriod(1, 4) ที่ต้องจำลำดับพารามิเตอร์เอง
  const row = await db(TABLE).where({ period_id, evaluatee_id }).first();
  // db(TABLE) เริ่มคิวรีตาราง assignments, .where({...}) ใส่เงื่อนไข WHERE
  // period_id = ? AND evaluatee_id = ?, .first() ดึงแถวแรกที่เจอ (หรือ
  // undefined ถ้าไม่เจอเลย) เทียบเท่า SQL:
  //   SELECT * FROM assignments WHERE period_id = ? AND evaluatee_id = ? LIMIT 1
  return !!row;
  // แปลงผลลัพธ์เป็น boolean ด้วย !! — ถ้า row เป็น object (เจอข้อมูล) จะได้
  // true, ถ้า row เป็น undefined (ไม่เจอ) จะได้ false ฟังก์ชันนี้จึงตอบแค่
  // "มี/ไม่มี" ไม่ได้ส่งข้อมูลแถวจริงออกไป (ผู้เรียกใช้ไม่ต้องสนใจรายละเอียด
  // ของตาราง แค่อยากรู้ว่า "คนนี้อยู่ในงวดนี้ไหม")
  // ใช้ที่: controllers/upload.controller.js (ตรวจสิทธิ์ก่อนอนุญาตให้
  // evaluatee อัปโหลดหลักฐานของตัวเองในงวดนั้น)
};

// ยืนยันสิทธิ evaluator ต่อ evaluatee ในงวดนั้น
exports.hasPairInPeriod = async ({ period_id, evaluator_id, evaluatee_id }) => {
  // คล้ายฟังก์ชันด้านบน แต่เช็กทั้งคู่ evaluator-evaluatee พร้อมกันในงวด
  // เดียวกัน ใช้ตอน evaluator พยายามทำอะไรบางอย่างแทน evaluatee (เช่น
  // อัปโหลดหลักฐานแทน) ต้องเช็กว่าสองคนนี้ถูกจับคู่กันไว้จริงในงวดนี้ ไม่ใช่ว่า
  // evaluator คนไหนก็เข้าถึงข้อมูลของ evaluatee คนไหนก็ได้ตามใจชอบ
  const row = await db(TABLE)
    .where({ period_id, evaluator_id, evaluatee_id })
    .first();
  // เทียบเท่า SQL:
  //   SELECT * FROM assignments
  //   WHERE period_id = ? AND evaluator_id = ? AND evaluatee_id = ?
  //   LIMIT 1
  return !!row;
  // ใช้ที่: routes/attachments.js (ตรวจสิทธิ์ก่อนอนุญาตให้ evaluator อัปโหลด
  // หลักฐานแทน evaluatee ที่ตนดูแลอยู่ในงวดนั้น)
};
