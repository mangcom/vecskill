// repositories/attachments.js
//
// Repository ของตาราง "attachments" (ไฟล์หลักฐานที่ evaluatee อัปโหลดเพื่อ
// ยืนยันตัวชี้วัดแต่ละตัว — ดูโครงสร้างตารางเต็ม ๆ ใน schema.sql) รวบรวม
// คำสั่ง CRUD (Create, Read, Update, Delete) พื้นฐานของตารางนี้ไว้ที่เดียว
//
// หมายเหตุสำหรับคนที่จะต่อยอด: ตอนนี้มีแค่ findById ที่ถูกเรียกใช้จริงจาก
// controllers/upload.controller.js (endpoint ชุด /api/upload/*) ส่วน
// endpoint หลักที่ frontend หน้า /upload ใช้งานจริงตอนนี้ (POST
// /api/attachments) อยู่ใน routes/attachments.js ซึ่งคิวรีตารางนี้ตรง ๆ ด้วย
// knex โดยไม่ผ่าน repository ชั้นนี้ (ของเดิมเขียนไว้คู่ขนานกัน 2 แนวทาง)
// ฟังก์ชันที่เหลือ (create, listMine, listAdmin, removeByOwner,
// removeByAdmin) เตรียมไว้ให้เป็นฐานสำหรับต่อยอด เช่น ถ้าจะทำหน้า "แอดมินดู
// ไฟล์หลักฐานทั้งหมด" ก็เรียก listAdmin({ period_id }) ได้ทันทีโดยไม่ต้อง
// เขียนคิวรีใหม่

const db = require('../db/knex');

const TABLE = 'attachments';

exports.create = async (payload) => {
  // payload คือ object ของข้อมูลที่จะ insert เช่น
  // { period_id, evaluatee_id, indicator_id, evidence_type_id, file_name, ... }
  const [id] = await db(TABLE).insert(payload);
  // db(TABLE).insert(payload) คือ INSERT INTO attachments (...) VALUES (...)
  // กับ MySQL ผลลัพธ์ที่ knex คืนมาคือ array ของ auto-increment id ที่เพิ่ง
  // insert ไป (ปกติมีตัวเดียว เพราะ insert ทีละแถว) จึง destructure เอาตัวแรก
  // ([id] = ...) มาเก็บไว้
  return exports.findById(id);
  // insert เสร็จแล้วดึงแถวที่เพิ่ง insert กลับมาทั้งแถว (รวม created_at ที่
  // ฐานข้อมูลเติมให้อัตโนมัติ) แทนที่จะคืนแค่ id เฉย ๆ สะดวกกับผู้เรียกใช้ที่
  // อยากได้ข้อมูลเต็ม ๆ ไปแสดงผลต่อทันที
};

exports.findById = async (id) => {
  return db(TABLE).where({ id }).first();
  // ดึงไฟล์หลักฐาน 1 แถวตาม id เทียบเท่า
  //   SELECT * FROM attachments WHERE id = ? LIMIT 1
  // คืนค่า undefined ถ้าไม่เจอ id นั้นในตาราง (ผู้เรียกใช้ต้องเช็กเองว่า
  // ผลลัพธ์เป็น undefined หรือเปล่าก่อนใช้งานต่อ — ดูตัวอย่างใน
  // controllers/upload.controller.js ที่เช็ก !row ก่อนตอบ 404)
};

exports.listMine = async ({ evaluatee_id, period_id, indicator_id }) => {
  // ดึงรายการไฟล์หลักฐานทั้งหมดของ evaluatee คนหนึ่ง (ใช้สำหรับหน้า "ไฟล์
  // หลักฐานของฉัน") โดยกรองเพิ่มได้ตาม period_id และ/หรือ indicator_id ถ้า
  // ส่งมา (ไม่บังคับต้องมีทั้งสองค่า)
  let q = db(TABLE).where({ evaluatee_id });
  // เริ่มคิวรีพื้นฐานก่อน: ต้องเป็นของ evaluatee คนนี้เท่านั้นเสมอ
  if (period_id) q = q.andWhere({ period_id });
  // ถ้ามีการระบุ period_id มาด้วย ให้เพิ่มเงื่อนไข AND period_id = ? เข้าไป
  // (.andWhere ต่อเงื่อนไขเพิ่มแบบ AND เข้ากับ query เดิมที่สร้างไว้แล้ว)
  if (indicator_id) q = q.andWhere({ indicator_id });
  // เช่นเดียวกันสำหรับ indicator_id — เขียนแบบนี้ (ค่อย ๆ ต่อเงื่อนไขทีละ
  // if) ทำให้ query ยืดหยุ่น: ผู้เรียกใช้จะส่งมาแค่ evaluatee_id อย่างเดียว,
  // หรือใส่ period_id/indicator_id เพิ่มด้วยก็ได้ โดยไม่ต้องเขียนฟังก์ชัน
  // แยกหลายตัวสำหรับแต่ละกรณี
  return q.orderBy('created_at', 'desc');
  // เรียงผลลัพธ์จากไฟล์ที่อัปโหลดล่าสุดขึ้นก่อน (desc = descending =
  // มากไปน้อย) เหมาะกับการแสดงผลแบบ "ไฟล์ล่าสุดอยู่บนสุด"
};

exports.listAdmin = async (filters = {}) => {
  // คล้าย listMine แต่สำหรับมุมมองแอดมิน: ไม่บังคับต้องกรองด้วย
  // evaluatee_id คนใดคนหนึ่งเลยก็ได้ (ดูได้ทุกคนถ้าไม่ส่ง filter มา) จะกรอง
  // ด้วย period_id, evaluatee_id, indicator_id อันไหนก็ได้ตามต้องการ
  // filters = {} คือค่า default — ถ้าผู้เรียกใช้ไม่ส่ง argument มาเลย จะไม่
  // error ตอนเข้าถึง filters.period_id (เพราะ filters จะเป็น object ว่าง
  // แทนที่จะเป็น undefined)
  let q = db(TABLE);
  // เริ่มจากคิวรีทั้งตารางก่อน ไม่มีเงื่อนไขใด ๆ เลย
  if (filters.period_id) q = q.where({ period_id: filters.period_id });
  if (filters.evaluatee_id) q = q.where({ evaluatee_id: filters.evaluatee_id });
  if (filters.indicator_id) q = q.where({ indicator_id: filters.indicator_id });
  // ทยอยเพิ่มเงื่อนไข WHERE ทีละตัวเฉพาะ filter ที่ถูกส่งมาจริง (ใช้ .where
  // ซ้ำได้เหมือน .andWhere เพราะเป็นการเรียกต่อจาก query builder ตัวเดียวกัน)
  return q.orderBy('created_at', 'desc');
};

exports.removeByOwner = async ({ id, evaluatee_id }) => {
  // ลบไฟล์หลักฐาน "เฉพาะ" ถ้า id นั้นเป็นของ evaluatee_id คนนี้จริง ๆ —
  // การใส่เงื่อนไข evaluatee_id ไว้ใน WHERE ด้วย (ไม่ใช่แค่ id อย่างเดียว) คือ
  // กลไกป้องกันไม่ให้ user คนหนึ่งลบไฟล์ของคนอื่นได้ แม้จะเดา/รู้ id ของไฟล์
  // คนอื่นก็ตาม เพราะถ้า evaluatee_id ไม่ตรง คำสั่ง DELETE จะไม่เจอแถวไหน
  // เลยให้ลบ (ลบได้ 0 แถว ไม่ error แต่ก็ไม่มีอะไรหาย)
  return db(TABLE).where({ id, evaluatee_id }).del();
  // .del() คือ DELETE FROM attachments WHERE id = ? AND evaluatee_id = ?
  // ค่าที่คืนมาคือจำนวนแถวที่ถูกลบจริง (0 หรือ 1 ในกรณีนี้เพราะ id เป็น
  // primary key) ผู้เรียกใช้ควรเช็กค่านี้เพื่อรู้ว่าลบสำเร็จจริงไหม
};

exports.removeByAdmin = async (id) => {
  // เวอร์ชันสำหรับแอดมิน: ลบได้ตาม id อย่างเดียว ไม่ต้องเช็กว่าเป็นเจ้าของ
  // ไฟล์หรือเปล่า เพราะแอดมินมีสิทธิ์จัดการข้อมูลทุกคนอยู่แล้ว (การเช็กสิทธิ์
  // ว่า "ผู้เรียก API นี้เป็นแอดมินจริงไหม" ควรทำในชั้น middleware/route
  // ก่อนจะเรียกมาถึงฟังก์ชันนี้ ไม่ใช่หน้าที่ของ repository)
  return db(TABLE).where({ id }).del();
};
