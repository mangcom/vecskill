// repositories/indicatorEvidence.js
//
// Repository ของตาราง "indicator_evidence" — ตารางเชื่อม (mapping table)
// ที่บอกว่าตัวชี้วัด (indicator) ตัวไหน อนุญาตให้แนบหลักฐานชนิด
// (evidence_type) ไหนได้บ้าง เช่น ตัวชี้วัด "แผนการจัดการเรียนรู้" อาจอนุญาต
// เฉพาะไฟล์ชนิด "เอกสารแผนการสอน" เท่านั้น ไม่ใช่ตัวชี้วัดไหนก็แนบหลักฐาน
// ชนิดไหนก็ได้ตามใจ

const db = require('../db/knex');

exports.mapExists = async ({ indicator_id, evidence_type_id }) => {// เช็คว่ามี mapping นี้ในตาราง indicator_evidence หรือไม่
  // ฟังก์ชันเดียวของไฟล์นี้: เช็กว่า "คู่ indicator_id + evidence_type_id นี้
  // ได้รับอนุญาตไหม" (มีแถวอยู่ในตาราง indicator_evidence ที่ตรงกันทั้งคู่)
  const row = await db('indicator_evidence')
    .where({ indicator_id, evidence_type_id })
    .first();
  // เทียบเท่า SQL:
  //   SELECT * FROM indicator_evidence
  //   WHERE indicator_id = ? AND evidence_type_id = ?
  //   LIMIT 1
  return !!row;
  // คืนค่า true ถ้าเจอแถวที่ตรงกัน (แปลว่าคู่นี้ถูกอนุญาต) false ถ้าไม่เจอ
  // ใช้ที่: controllers/upload.controller.js และ routes/attachments.js —
  // ก่อนจะยอมให้อัปโหลดไฟล์ ต้องเช็กผ่านฟังก์ชันนี้ก่อนเสมอ เพื่อป้องกันไม่ให้
  // ผู้ใช้แนบไฟล์ผิดชนิดเข้ากับตัวชี้วัดที่ไม่เกี่ยวข้องกัน
};
