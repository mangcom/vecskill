// routes/attachments.js
//
// ไฟล์นี้คือ route หลักที่หน้า frontend /upload ใช้งานจริงในตอนนี้ (ดู
// frontend/pages/upload.vue) ครอบคลุมทั้งข้อมูลประกอบฟอร์ม (รอบการประเมิน,
// ตัวชี้วัด, ชนิดหลักฐาน) และ endpoint สำหรับอัปโหลดไฟล์จริง (POST
// /api/attachments) ต่างจาก routes/upload.routes.js (อีกไฟล์หนึ่ง) ที่เขียน
// endpoint อัปโหลดไว้อีกชุดคู่ขนานกันแบบแยก controller — ทั้งสองไฟล์ใช้
// ตาราง "attachments" เดียวกัน แต่คนละ query/คนละ logic
//
// mount ไว้ที่ app.js ด้วย app.use("/api", attachmentsApi) โดย "ไม่มี"
// prefix เฉพาะทาง (แค่ /api เฉย ๆ) ไฟล์นี้จึงกำหนด path เต็มของตัวเองไว้ตรง
// ๆ เลย เช่น '/periods/active', '/indicators', '/attachments'

const express = require("express");
const router = express.Router();
const db = require("../db/knex");
const asgRepo = require("../repositories/assignments");
const authz = require("../middlewares/auth"); // ถูกแก้จาก authz เป็น auth เพราะไฟล์นี้ใช้ authz ไม่ได้
// หมายเหตุ: ตัวแปรชื่อ "authz" ในไฟล์นี้คือ middleware เดียวกับ
// middlewares/auth.js (ไม่ใช่คนละไฟล์กัน) แค่ตอนเขียนโค้ดตั้งชื่อตัวแปร
// ตอน import ไว้ว่า authz เฉย ๆ — ชื่อตัวแปรฝั่งซ้ายของ require(...) ตั้งเป็น
// อะไรก็ได้ตามใจผู้เขียน ไม่จำเป็นต้องตรงกับชื่อไฟล์ที่ require มา
const upload = require("../middlewares/upload");

// GET /api/periods/active
router.get(
  "/periods/active",
  authz("evaluatee", "evaluator", "admin"),
  // อนุญาตทุก role ที่ login แล้ว เพราะทุกคนต้องรู้ว่า "ตอนนี้มีรอบการ
  // ประเมินไหนเปิดอยู่บ้าง" ไม่ว่าจะเป็นคนอัปโหลดเอง (evaluatee) คนประเมิน
  // (evaluator) หรือแอดมินที่ดูแลระบบ
  async (req, res) => {
    const rows = await db("evaluation_periods")
      .where({ is_active: 1 })
      // ดึงเฉพาะรอบประเมินที่ is_active = 1 (เปิดใช้งานอยู่) เท่านั้น ไม่เอา
      // รอบเก่าที่ปิดไปแล้วมาปนด้วย
      .orderBy("id", "desc");
      // เรียงรอบล่าสุด (id มากสุด) ขึ้นก่อน
    res.json(
      rows.map((r) => ({
        id: r.id,
        code: r.code,
        name_th: r.name_th || r.name || r.title,
        // ใช้ || ไล่ลำดับความสำคัญ: ถ้ามีคอลัมน์ name_th ใช้ก่อน ไม่มีค่อยลอง
        // name แล้วค่อยลอง title — เผื่อโครงสร้างตารางจริงบนเครื่องของ
        // ผู้ใช้แต่ละคนตั้งชื่อคอลัมน์ไม่ตรงกันเป๊ะ (schema.sql ของ template
        // นี้ใช้ name_th อยู่แล้ว แต่เขียนกันพลาดไว้เผื่อแก้ schema เอง)
      }))
    );
  }
);

// GET /api/indicators?period_id=..  (ตัวอย่าง: filter ตาม active; หากมี mapping กับ period ให้ JOIN ตามจริง)
router.get(
  "/indicators",
  authz("evaluatee", "evaluator", "admin"),
  async (req, res) => {
    const { period_id } = req.query;
    // destructure ค่า period_id ออกจาก query string (เช่น
    // /api/indicators?period_id=1 -> req.query.period_id === '1')
    // หมายเหตุ: ตัวแปรนี้ถูกดึงออกมาแต่ "ไม่ได้ถูกใช้จริง" ในคิวรีด้านล่าง —
    // ตอนนี้ endpoint นี้คืนตัวชี้วัดที่ active = 1 ทั้งหมด ไม่ได้กรองตาม
    // period_id เลย (ดูคอมเมนต์เดิมของผู้พัฒนาด้านล่าง) ถ้าระบบของคุณมีตาราง
    // เชื่อม indicator กับ period จริง ๆ ให้เพิ่มเงื่อนไขกรองตรงนี้
    let q = db("indicators").where({ active: 1 });
    // ถ้าระบบของคุณมีตารางเชื่อม indicator กับ period ให้ JOIN/WHERE เพิ่มตามจริงที่นี่
    res.json(await q.select("id", "code", "name_th", "type"));
    // .select(...) เลือกเฉพาะคอลัมน์ที่ต้องการส่งกลับ (ไม่ส่งทั้งแถวทุกคอลัมน์
    // ออกไปโดยไม่จำเป็น)
  }
);

// GET /api/indicators/:id/evidence-types
// router.get('/indicators/:id/evidence-types', authz('evaluatee','evaluator','admin'), async (req, res) => {
//   const id = req.params.id;
//   const rows = await db('indicator_evidence as ie')
//     .join('evidence_types as et', 'et.id', 'ie.evidence_type_id')
//     .where('ie.indicator_id', id)
//     .select('et.id','et.name_th','et.mime_csv','et.mime_list_json','et.max_mb');
//   const mapped = rows.map(r => ({
//     id: r.id,
//     name_th: r.name_th,
//     // รองรับได้ทั้ง mime_list_json (JSON) และ mime_csv (CSV)
//     mime_list: r.mime_list_json ? JSON.parse(r.mime_list_json) :
//                (r.mime_csv ? String(r.mime_csv).split(',').map(s => s.trim()).filter(Boolean) : []),
//     max_mb: Number(r.max_mb || 10)
//   }));
//   res.json(mapped);
// });
// ด้านบนนี้คือเวอร์ชัน "ที่ตั้งใจไว้จริง ๆ" ของ endpoint นี้ — ดึงกฎของแต่ละ
// indicator จากตาราง evidence_types ตรง ๆ (ชนิดไฟล์ที่อนุญาต/ขนาดสูงสุด
// เฉพาะของ evidence_type นั้น) แต่ตารางจริงที่ seed ไว้ใน schema.sql ของ
// template นี้ยังไม่มีคอลัมน์ mime_csv / mime_list_json / max_mb ใน
// evidence_types ให้ครบ จึงถูกคอมเมนต์ปิดไว้ก่อน แล้วใช้เวอร์ชันง่ายกว่า
// ด้านล่างแทนชั่วคราว (ถ้าจะต่อยอดเรื่องกำหนดชนิด/ขนาดไฟล์ต่อ indicator
// จริงจัง ให้เพิ่มคอลัมน์เหล่านี้ในตาราง evidence_types ก่อน แล้วค่อยสลับมา
// ใช้เวอร์ชันนี้แทน)

// GET /api/indicators/:id/evidence-types
router.get(
  "/indicators/:id/evidence-types",
  authz("evaluatee", "evaluator", "admin"),
  async (req, res) => {
    const id = req.params.id;
    // :id ใน path ถูก Express ดึงมาใส่ req.params.id ให้อัตโนมัติ
    const rows = await db("indicator_evidence as ie")
      // ตั้งชื่อเล่น (alias) ให้ตาราง indicator_evidence ว่า "ie" เพื่อให้
      // เขียนโค้ด JOIN ด้านล่างสั้นลง
      .join("evidence_types as et", "et.id", "ie.evidence_type_id")
      // JOIN ตาราง evidence_types (alias "et") เข้ากับ ie โดยจับคู่ที่
      // et.id = ie.evidence_type_id (ตัว SQL JOIN มาตรฐาน เอาไว้ดึงข้อมูล
      // จาก 2 ตารางที่เชื่อมกันมาพร้อมกันในคิวรีเดียว)
      .where("ie.indicator_id", id)
      // กรองเฉพาะ mapping ของ indicator ตัวที่ระบุใน URL
      .select("et.id", "et.name_th"); // สคีมามีเท่านี้
      // ดึงแค่ id กับ name_th จากตาราง evidence_types เท่านั้น เพราะตาราง
      // จริงในฐานข้อมูล (schema.sql) มีแค่ 2 คอลัมน์นี้ให้ดึง (ไม่มี mime_csv
      // หรือ max_mb แบบเวอร์ชันที่ comment ปิดไว้ด้านบน)
    // คืนค่าเริ่มต้น (ฝั่งหน้าเว็บก็มี default ซ้ำชั้น ปลอดภัย)
    const mapped = rows.map((r) => ({
      id: r.id,
      name_th: r.name_th,
      mime_list: ["application/pdf", "image/png", "image/jpeg", "image/webp"],
      // เนื่องจากตารางจริงยังไม่มีข้อมูล "ชนิดไฟล์ที่อนุญาต" แยกตาม
      // evidence_type แต่ละตัว จึงใส่ค่า default เดียวกันไปให้ทุกตัวก่อน
      // (frontend เองก็มี default ชุดเดียวกันซ้ำไว้อีกชั้นเผื่อ backend ไม่ได้
      // ส่งมาด้วย — ดู frontend/pages/upload.vue)
      max_mb: 10,
      // ขนาดไฟล์สูงสุด default 10 MB เท่ากันทุก evidence_type เช่นกัน
    }));
    res.json(mapped);
  }
);

// POST /api/attachments
router.post(
  "/attachments",
  authz("evaluatee", "evaluator"),
  // อนุญาตเฉพาะ evaluatee (อัปโหลดของตัวเอง) และ evaluator (อัปโหลดแทนคนที่
  // ตนดูแล) — admin ไม่ได้อยู่ในลิสต์นี้ เพราะ endpoint นี้ออกแบบมาสำหรับ
  // "คนที่เกี่ยวข้องโดยตรงกับการประเมิน" เท่านั้น
  upload.single("file"),
  // แปลง multipart/form-data ให้กลายเป็น req.file + req.body (ดู
  // middlewares/upload.js) field ของไฟล์ต้องชื่อ "file" เหมือนกับ
  // routes/upload.routes.js
  async (req, res) => {
    try {
      const {
        period_id,
        indicator_id,
        evidence_type_id,
        note,
        evaluatee_id: bodyEvaluatee,
        // destructure แล้วเปลี่ยนชื่อตัวแปรจาก evaluatee_id เป็น
        // bodyEvaluatee ในที่นี้ (เขียนว่า `evaluatee_id: bodyEvaluatee`) —
        // ทำแบบนี้เพื่อไม่ให้ชื่อตัวแปรชนกับ evaluatee_id ที่จะประกาศใหม่
        // ด้านล่าง (ตัวที่ผ่านการตรวจสอบสิทธิ์แล้วจริง ๆ)
      } = req.body;
      if (!period_id || !indicator_id || !evidence_type_id || !req.file) {
        // เช็กฟิลด์บังคับให้ครบก่อนทำอะไรต่อ — ถ้าขาดอันใดอันหนึ่ง (รวมถึง
        // ไม่มีไฟล์แนบมาเลย) ให้ตอบ 422 (Unprocessable Entity = "ข้อมูลที่
        // ส่งมาไม่ครบ/ไม่ถูกต้องตามที่ควรจะเป็น") ทันที ไม่ต้องไปคิวรี
        // ฐานข้อมูลต่อให้เสียเวลาเปล่า
        return res.status(422).json({ message: "Missing required fields" });
      }

      // 1) period active
      const per = await db("evaluation_periods")
        .where({ id: period_id, is_active: 1 })
        .first();
      // ต้องเป็นรอบประเมินที่มีอยู่จริง "และ" ยังเปิดใช้งานอยู่ (is_active=1)
      // เท่านั้น ถึงจะอัปโหลดได้ — กันไม่ให้มีการอัปโหลดย้อนหลังเข้ารอบที่ปิด
      // ไปแล้ว
      if (!per) return res.status(404).json({ message: "Period not active" });

      // 2) indicator exists
      const ind = await db("indicators")
        .where({ id: indicator_id, active: 1 })
        .first();
      // ต้องเป็นตัวชี้วัดที่มีอยู่จริงและยัง active อยู่เช่นกัน
      if (!ind) return res.status(404).json({ message: "Indicator not found" });

      // 3) indicator ↔ evidence allowed
      const allowed = await db("indicator_evidence")
        .where({ indicator_id, evidence_type_id })
        .first();
      // เช็กว่าคู่ indicator + evidence_type นี้ได้รับอนุญาตให้จับคู่กันไหม
      // (เทียบเท่ากับสิ่งที่ repositories/indicatorEvidence.js -> mapExists
      // ทำ แต่ในไฟล์นี้ query ตรง ๆ ไม่ได้เรียกผ่าน repository — เป็นตัวอย่าง
      // ของการเขียนคิวรีซ้ำกัน 2 ที่ ซึ่งถ้าจะต่อยอดควรรวมให้เรียกผ่าน
      // repository เดียวกันเพื่อไม่ให้ logic เพี้ยนไปคนละทางในอนาคต)
      if (!allowed)
        return res
          .status(409)
          // 409 Conflict = คำขอนี้ขัดแย้งกับสถานะปัจจุบันของข้อมูล (ตัวชี้วัด
          // กับชนิดหลักฐานนี้ไม่ได้ถูกอนุญาตให้คู่กัน)
          .json({ message: "Evidence type not allowed for this indicator" });

      // 4) resolve evaluatee + check rights
      const { id: userId, role } = req.user;
      // req.user ถูกแนบมาโดย middleware authz (auth.js) หลังจากตรวจสอบ
      // token ผ่านแล้ว — destructure พร้อมเปลี่ยนชื่อ id -> userId (กันชน
      // กับตัวแปร id อื่น ๆ ในไฟล์นี้)
      let evaluatee_id;
      if (role === "evaluatee") {
        // กรณีที่ 1: คนที่กำลังอัปโหลด "คือ" evaluatee เอง (อัปโหลดของ
        // ตัวเอง) — evaluatee_id ก็คือ userId ของคนที่ login อยู่นั่นเอง ไม่
        // ต้องพึ่งค่าที่ client ส่งมาเลย (ป้องกันไม่ให้ evaluatee สวมรอยส่ง
        // evaluatee_id ของคนอื่นมาแทนตัวเองได้)
        evaluatee_id = userId;
        const ok = await asgRepo.hasEvaluateeInPeriod({
          period_id,
          evaluatee_id,
        });
        // ต้องถูก "มอบหมาย" ให้อยู่ในรอบประเมินนี้จริง ๆ ก่อน ไม่ใช่ว่า
        // evaluatee คนไหนก็อัปโหลดเข้ารอบไหนก็ได้ตามใจ
        if (!ok)
          return res
            .status(403)
            .json({ message: "You are not in this period" });
      } else if (role === "evaluator") {
        // กรณีที่ 2: คนที่กำลังอัปโหลด "คือ" evaluator ที่อัปโหลดแทน
        // evaluatee ที่ตนดูแล — ในกรณีนี้ evaluatee_id "ต้อง" มาจากที่ client
        // ระบุมาใน body (bodyEvaluatee) เพราะ evaluator ไม่ใช่เจ้าของไฟล์
        // หลักฐานนี้โดยตรง
        evaluatee_id = Number(bodyEvaluatee);
        if (!evaluatee_id)
          return res
            .status(422)
            .json({ message: "evaluatee_id required for evaluator" });
        const ok = await asgRepo.hasPairInPeriod({
          period_id,
          evaluator_id: userId,
          evaluatee_id,
        });
        // ต้องเช็กว่า evaluator คนนี้ "ถูกจับคู่" ให้ดูแล evaluatee คนนี้ใน
        // รอบประเมินนี้จริง ๆ ไม่ใช่ evaluator คนไหนก็อัปโหลดแทนใครก็ได้
        if (!ok)
          return res
            .status(403)
            .json({ message: "Not assigned to this evaluatee in this period" });
      } else {
        // role อื่นที่ไม่ใช่ evaluatee/evaluator เลย (ในทางปฏิบัติจะไม่เกิด
        // เคสนี้ เพราะ middleware authz("evaluatee","evaluator") ด้านบน
        // กรองไปแล้วชั้นหนึ่ง แต่ใส่ else ไว้กันเหนียวอีกชั้น)
        return res.status(403).json({ message: "Unsupported role" });
      }

      // 5) Optional: ตรวจ MIME/size ตาม policy ฝั่ง server (แนะนำให้มีตารางกำหนดชัด)
      // ข้ามในตัวอย่างนี้ (เพราะได้ตรวจหน้าเว็บแล้ว) แต่ควรเพิ่มจริงจังในระบบ production
      // หมายเหตุ: การเช็กแค่ฝั่ง frontend (JavaScript ในเบราว์เซอร์) อย่างเดียว
      // ไม่ปลอดภัยพอสำหรับระบบจริง เพราะผู้ใช้สามารถยิง request ตรงมาที่ API
      // นี้โดยข้ามหน้าเว็บไปเลยได้ (เช่นใช้ curl/Postman) ระบบ production ควร
      // ตรวจ MIME/ขนาดไฟล์ซ้ำอีกชั้นที่นี่ด้วยเสมอ (middlewares/upload.js มี
      // การเช็กชนิดไฟล์แบบรวม ๆ ทั้งระบบอยู่แล้ว ส่วนนี้คือการเช็กเพิ่มแบบ
      // เจาะจงตาม evidence_type_id แต่ละตัว)

      const [id] = await db("attachments").insert({
        period_id,
        evaluatee_id,
        indicator_id,
        evidence_type_id,
        file_name: req.file.originalname,
        // ชื่อไฟล์ "เดิม" ที่ผู้ใช้อัปโหลดมา (ไม่ใช่ชื่อไฟล์ที่เก็บจริงบนดิสก์
        // ซึ่งถูกเปลี่ยนให้ไม่ซ้ำกันแล้วใน middlewares/upload.js) เก็บไว้
        // เพื่อแสดงผลให้ผู้ใช้เห็นชื่อไฟล์ที่ตัวเองอัปโหลดจริง ๆ
        mime_type: req.file.mimetype,
        size_bytes: req.file.size,
        storage_path: req.file.path,
        // path แบบ absolute เต็ม ๆ บนดิสก์ที่ multer เก็บไฟล์จริงไว้ (ต่างจาก
        // controllers/upload.controller.js ที่แปลงเป็น path แบบ relative
        // ก่อนเก็บ — จุดนี้เป็นความไม่สอดคล้องกันเล็กน้อยระหว่าง endpoint
        // อัปโหลด 2 ชุดที่มีอยู่คู่ขนานกันในระบบ ถ้าจะต่อยอดควรเลือกใช้
        // แนวทางใดแนวทางหนึ่งให้สอดคล้องกันทั้งระบบ)
        note: note || null,
        // ถ้าผู้ใช้ไม่ได้กรอกหมายเหตุมา ให้เก็บเป็น NULL แทนสตริงว่าง
      });

      res.status(201).json({
        // 201 Created = สร้างข้อมูลใหม่สำเร็จ (มาตรฐานของ REST API สำหรับ
        // การ POST ที่สร้างทรัพยากรใหม่สำเร็จ)
        id,
        message: "uploaded",
        meta: {
          period_id: Number(period_id),
          indicator_id: Number(indicator_id),
          evidence_type_id: Number(evidence_type_id),
          evaluatee_id,
        },
        file: {
          name: req.file.originalname,
          mime: req.file.mimetype,
          size_bytes: req.file.size,
        },
      });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Internal error", detail: err.message });
      // หมายเหตุ: route นี้ "ไม่ได้" โยน error ต่อให้ error-handling
      // middleware กลาง (middlewares/error.js) จัดการ แต่ตอบ response เองใน
      // try/catch ตรงนี้เลย — ต่างจาก controller อื่น ๆ ในระบบที่ใช้วิธี
      // next(err) ส่งต่อให้ตัวกลางจัดการ (ดู
      // controllers/upload.controller.js เป็นตัวอย่างแนวทางนั้น) ทั้งสอง
      // แนวทางใช้งานได้ แต่ถ้าจะต่อยอดควรเลือกแนวทางเดียวให้สอดคล้องกันทั้ง
      // ระบบ เพื่อให้รูปแบบ error response เหมือนกันทุก endpoint
    }
  }
);

module.exports = router;
