// routes/auth.routes.js
//
// Route เรื่องการยืนยันตัวตน (authentication) — ตอนนี้มีแค่ endpoint เดียว
// คือ login เพราะระบบนี้ไม่มีหน้า "สมัครสมาชิกเอง" (ผู้ใช้ถูกสร้างไว้ล่วงหน้า
// ในฐานข้อมูลผ่านหน้าแอดมัน /users หรือ seed ข้อมูลใน schema.sql เท่านั้น)
//
// ไฟล์นี้ถูก mount (ผูกเข้ากับแอปหลัก) ไว้ที่ app.js ด้วยบรรทัด
// app.use("/api/auth", authRoutes) ทำให้ path ที่ประกาศในไฟล์นี้ทุกอันถูก
// เติม "/api/auth" นำหน้าโดยอัตโนมัติ เช่น router.post('/login', ...)
// ด้านล่างนี้ จะกลายเป็น POST /api/auth/login จริง ๆ เวลาเรียกใช้งาน

const router = require('express').Router();
// express.Router() คือการสร้าง "router ย่อย" ขึ้นมาชุดหนึ่ง แยกเป็นไฟล์ของ
// ตัวเอง แล้วค่อยเอาไปประกอบรวมกับแอปหลักใน app.js ทีหลัง (ทำให้แยกไฟล์ route
// ตามหมวดหมู่ได้ ไม่ต้องยัดทุก route ไว้ในไฟล์ app.js ไฟล์เดียว)
const ctrl = require('../controllers/auth.controller');
// controller คือชั้นที่ใส่ "ตรรกะจริง" ของแต่ละ endpoint (route ไฟล์นี้แค่บอก
// ว่า "path ไหน method ไหน ให้เรียกฟังก์ชันไหนทำงาน" ไม่ได้เขียน logic เอง)

// POST /api/auth/login
// Login user
// Body: { email, password }
// Response: { success, accessToken, user: { id, name, email, role } }
// Roles: all
//http://localhost:7000/api/auth/login
router.post('/login', ctrl.login);
// ผูก path '/login' method POST เข้ากับฟังก์ชัน ctrl.login (ดูรายละเอียด
// การทำงานจริงใน controllers/auth.controller.js) — endpoint นี้ "ไม่ต้อง"
// ผ่าน middleware auth() ก่อน (ต่างจาก route อื่น ๆ ในระบบ) เพราะเป็น
// ขั้นตอนแรกสุดที่ยังไม่มี token ใด ๆ จะเอามาตรวจสอบได้เลย

module.exports = router;
// ส่งออก router ชุดนี้ ให้ app.js เอาไปผูกกับ path prefix "/api/auth"
