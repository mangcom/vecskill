// routes/upload.routes.js
//
// Route ชุดสำหรับจัดการ "ไฟล์หลักฐาน" (evidence) ฝั่ง evaluatee/evaluator —
// mount ไว้ที่ app.js ด้วย app.use("/api/upload", uploadRoutes) ทำให้ทุก
// path ในไฟล์นี้ถูกเติม "/api/upload" นำหน้า
//
// หมายเหตุสำหรับคนต่อยอด: endpoint หลักที่ frontend หน้า /upload เรียกใช้
// จริงตอนนี้คือ POST /api/attachments (อยู่ในไฟล์ routes/attachments.js
// คนละไฟล์) ไม่ใช่ POST /api/upload/evidence ในไฟล์นี้ — ของเดิมผู้พัฒนาเขียน
// endpoint อัปโหลดไว้ "สองชุดคู่ขนานกัน" (คนละแนวทาง คนละ controller) ไฟล์
// นี้ยังใช้งานได้ปกติ เผื่อจะเลือกต่อยอดจากฝั่งนี้แทนก็ได้ (ดู
// controllers/upload.controller.js ประกอบ)

const router = require('express').Router();
const auth = require('../middlewares/auth');
const upload = require('../middlewares/upload');
// middleware ของ multer (ดูรายละเอียดเต็ม ๆ ใน middlewares/upload.js) ใช้
// แปลง request แบบ multipart/form-data (ฟอร์มที่มีไฟล์แนบ) ให้กลายเป็น
// req.file / req.body ที่ควบคุมใน controller ได้
const ctrl = require('../controllers/upload.controller');

// ===== Evaluatee =====
router.post('/evidence', auth('evaluatee'), upload.single('file'), ctrl.uploadEvidence);
// POST /api/upload/evidence — evaluatee อัปโหลดไฟล์หลักฐานของตัวเอง
// ลำดับ middleware สำคัญ: auth('evaluatee') ต้องเช็ก login/role ก่อน แล้ว
// upload.single('file') ค่อยแปลงไฟล์ที่แนบมา แล้วสุดท้าย ctrl.uploadEvidence
// ถึงจะทำงานจริง (บันทึกข้อมูลลงฐานข้อมูล)
// upload.single('file'), file คือ ชื่อ field ใน form-data ไม่ถูกต้อง error multer แสดงว่า "Unexpected field"
// ชื่อ field ของไฟล์ในฟอร์มฝั่ง frontend "ต้อง" ตั้งชื่อว่า "file" เป๊ะ ๆ
// (ตรงกับ 'file' ที่ส่งเข้า upload.single('file')) ถ้าฝั่ง frontend ใช้
// fd.append('อย่างอื่น', ...) แทน multer จะปฏิเสธด้วย error "Unexpected field"
// ทันที เพราะมันถูกตั้งค่าให้รับไฟล์จาก field ชื่อ "file" เท่านั้น
router.get('/mine', auth('evaluatee'), ctrl.listMine);
// GET /api/upload/mine — evaluatee ดูรายการไฟล์หลักฐานทั้งหมดของตัวเอง
// (กรองเพิ่มได้ด้วย query string เช่น ?period_id=1 — ดูใน controller)
router.delete('/:id', auth('evaluatee'), ctrl.deleteMine);
// DELETE /api/upload/5 — evaluatee ลบไฟล์หลักฐานของตัวเอง (เฉพาะไฟล์ที่เป็น
// ของตัวเองจริง ๆ และเฉพาะตอนที่ period ยังเปิดอยู่เท่านั้น — ดู logic เต็ม
// ๆ ใน controller)
router.put('/:id/file', auth('evaluatee'), upload.single('file'), ctrl.updateFileMine);
// PUT /api/upload/5/file — evaluatee เปลี่ยนไฟล์ของหลักฐานที่เคยอัปโหลดไว้
// (อัปโหลดไฟล์ใหม่มาแทนที่ไฟล์เดิม แต่ข้อมูล record เดิม (id) ยังอยู่)
router.patch('/:id', auth('evaluatee'), ctrl.updateMetaMine);
// PATCH /api/upload/5 — แก้ไข "ข้อมูลประกอบ" ของไฟล์หลักฐาน (เช่น
// เปลี่ยน indicator_id/evidence_type_id ที่ผูกไว้) โดยไม่แตะไฟล์จริง
// (ต่างจาก PUT /:id/file ด้านบนที่เปลี่ยนตัวไฟล์)

// ===== Evaluator =====
router.get('/evaluatee/:evaluateeId', auth('evaluator'), ctrl.listForEvaluator);
// GET /api/upload/evaluatee/4 — evaluator ดูรายการไฟล์หลักฐานของ evaluatee
// คนที่ตนดูแล (ตรวจตาม evaluateeId ใน URL)

// ===== Admin =====
// (ยังไม่มี endpoint ของแอดมินในไฟล์นี้ — ถ้าจะต่อยอด เช่น ให้แอดมินดู/ลบ
// ไฟล์หลักฐานของทุกคนได้ ให้เพิ่ม route ตรงนี้ แล้วเขียนฟังก์ชันใหม่ใน
// controllers/upload.controller.js โดยอาจเรียกใช้
// repositories/attachments.js -> listAdmin() / removeByAdmin() ที่เตรียมไว้
// ให้แล้ว)


module.exports = router;
