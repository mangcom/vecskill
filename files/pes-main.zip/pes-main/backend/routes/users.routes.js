// routes/users.routes.js
//
// Route สำหรับจัดการผู้ใช้ (CRUD: Create, Read, Update, Delete) — mount ไว้
// ที่ app.js ด้วย app.use("/api/users", userRoutes) ทำให้ path ทุกอันในไฟล์
// นี้ถูกเติม "/api/users" นำหน้า เช่น router.get('/', ...) จะกลายเป็น
// GET /api/users จริง ๆ

const router = require('express').Router();
const auth = require('../middlewares/auth');
// middleware ตรวจสอบ login + role (ดูรายละเอียดเต็ม ๆ ใน
// middlewares/auth.js) — เรียก auth('role1', 'role2', ...) เพื่อบอกว่า
// "เฉพาะ role เหล่านี้เท่านั้นที่เรียก route นี้ได้"
const ctrl = require('../controllers/users.controller');

// หมายเหตุเพื่อการสอน:
// - list/listServer/get: ให้ทุกบทบาทที่ล็อกอินแล้วเรียกได้ (admin/evaluator/evaluatee)
// - create/update/delete: ตัวอย่างนี้จำกัด admin (นักเรียนจะเห็นการควบคุมสิทธิ์ชัดเจน)
//
// ข้อสังเกตสำคัญสำหรับคนเริ่มต้น: Express จะจับคู่ route "จากบนลงล่าง ตัว
// แรกที่ match ก่อน" ดังนั้น '/server' ต้องประกาศไว้ "ก่อน" '/:id' เสมอ ไม่งั้น
// Express จะเข้าใจว่า "server" คือค่าพารามิเตอร์ :id (เช่นเดียวกับที่ GET
// /api/users/5 จะส่ง "5" เป็น :id) แล้วจะไม่มีวันไปถึง route '/server' เลย

router.get('/server', auth('admin','evaluator','evaluatee'), ctrl.listServer);
// GET /api/users/server — ดึงรายชื่อผู้ใช้แบบที่ให้ "ฐานข้อมูล/เซิร์ฟเวอร์"
// เป็นคนจัดเรียง/กรอง/แบ่งหน้าให้ (เหมาะกับตารางข้อมูลเยอะ ๆ ที่ต้องแบ่งหน้า
// จริงจัง) ดูรายละเอียดการ query ใน controllers/users.controller.js
router.get('/',       auth('admin','evaluator','evaluatee'), ctrl.list);
// GET /api/users — ดึงรายชื่อผู้ใช้ทั้งหมดแบบง่าย ๆ (ไม่แบ่งหน้าฝั่ง
// เซิร์ฟเวอร์ ปล่อยให้ frontend จัดการเองถ้าต้องการ) ใช้แสดงในหน้า /users
router.get('/:id',    auth('admin','evaluator','evaluatee'), ctrl.get);
// GET /api/users/5 — ดึงข้อมูลผู้ใช้คนเดียวตาม id ที่ระบุใน URL (:id คือ
// "route parameter" — Express จะดึงค่าจาก URL จริงมาใส่ไว้ที่ req.params.id
// ให้ควบคุมเองใน controller)

router.post('/',      auth('admin'), ctrl.create);
// router.post('/',  ctrl.create);
// POST /api/users — สร้างผู้ใช้ใหม่ จำกัดเฉพาะ role 'admin' เท่านั้น (เห็น
// ชัดเจนว่า auth('admin') ไม่ได้ใส่ role อื่นเลย ต่างจาก 3 บรรทัดด้านบนที่
// อนุญาตหลาย role) — บรรทัดที่ comment ไว้ด้านบน (router.post('/', ctrl.create);)
// คือตัวอย่างเก่าที่ "ไม่มี" การเช็กสิทธิ์เลย เก็บไว้เป็นตัวอย่างเปรียบเทียบ
// ให้เห็นว่าทำไมต้องมี middleware auth('admin') คั่นกลางไว้ (ถ้าไม่มี ใคร
// login มาด้วย role ไหนก็สร้างผู้ใช้ใหม่ได้หมด)
router.put('/:id',    auth('admin'), ctrl.update);
// PUT /api/users/5 — แก้ไขข้อมูลผู้ใช้ตาม id จำกัดเฉพาะ admin
router.delete('/:id', auth('admin'), ctrl.remove);
// DELETE /api/users/5 — ลบผู้ใช้ตาม id จำกัดเฉพาะ admin

module.exports = router;
