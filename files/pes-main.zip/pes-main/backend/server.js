// server.js
// trigger: test_backend/build_backend CI job (mysql_native_password fix)
//
// นี่คือ "จุดเริ่มต้นจริง" ของ backend (entry point) — ไฟล์ที่ package.json สั่ง
// ให้รันด้วยคำสั่ง `npm start` (node server.js) หรือ `npm run dev` (nodemon server.js)
//
// ทำไมต้องแยกไฟล์นี้ออกจาก app.js?
// - app.js (ไฟล์ข้าง ๆ กัน) มีหน้าที่แค่ "ประกอบร่าง" Express app (ตั้ง
//   middleware, ผูก route ต่าง ๆ) แล้ว export ตัว app ออกมาเฉย ๆ ไม่ได้สั่ง
//   .listen() เอง
// - server.js เป็นคนนำ app ที่ประกอบเสร็จแล้วมาสั่ง .listen() เปิดพอร์ตจริง
// ข้อดีของการแยกแบบนี้คือ ไฟล์ test (ดู backend/test/*.js) สามารถ
// import app จาก app.js ไปยิง request ทดสอบได้ตรง ๆ โดยไม่ต้องเปิดพอร์ตจริง
// (ไม่ชนพอร์ตกัน ไม่ต้องรอ server start ก่อนเทส)

const path = require('path');
const dotenv = require('dotenv');
// dotenv คือไลบรารีที่อ่านไฟล์ .env แล้วเอาค่าไปใส่ไว้ใน process.env ให้อัตโนมัติ
dotenv.config({ path: path.resolve(__dirname, '../.env') });
// เรียก .config() เพื่อให้มันไปหาไฟล์ .env ที่ root ของโปรเจกต์ (ไฟล์เดียว
// กับที่ docker-compose.yml ใช้ตั้งค่าทั้ง frontend และ backend — ไม่ใช่
// backend/.env แยกต่างหากเหมือนเดิม) แล้วโหลดค่าตัวแปรต่าง ๆ เช่น PORT,
// DB_HOST, JWT_SECRET เข้ามาใช้งานได้ผ่าน process.env — ระบุ path ด้วย
// path.resolve(__dirname, '../.env') ตรง ๆ แทนที่จะปล่อยให้ dotenv เดาจาก
// working directory ปัจจุบันของโปรเซส (ซึ่งจะเจอแค่ถ้า cwd เป็น root พอดี
// เท่านั้น) ต้องเรียกบรรทัดนี้ "ก่อน" require('./app') เสมอ เพราะ app.js
// (และไฟล์อื่นที่มันเรียกต่อ เช่น db/knex.js) จะอ่านค่า process.env ทันทีตอน
// ถูก require

const app = require('./app');
// นำ Express app ที่ตั้งค่าทุกอย่างเสร็จแล้ว (routes, middleware, cors, ฯลฯ)
// จาก app.js เข้ามาใช้

const PORT = process.env.PORT || 7000;
// อ่านค่าพอร์ตจาก .env (ตัวแปร PORT) ถ้าไม่ได้ตั้งไว้ ให้ใช้ 7000 เป็นค่าเริ่มต้น

app.listen(PORT, () => {
  // app.listen(...) คือคำสั่งที่แท้จริงที่เปิดให้ server เริ่มรอรับ request
  // จากภายนอก (เปิดพอร์ตของเครื่อง) ฟังก์ชัน callback ด้านในจะถูกเรียกครั้งเดียว
  // ตอนเปิดพอร์ตสำเร็จ ใช้สำหรับ log บอกว่า server พร้อมใช้งานแล้วที่ URL ไหน
  console.log(`API running on http://localhost:${PORT}`);
});
