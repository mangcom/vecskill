// auth.fixed.spec.js
//
// เหมือนกับ auth.spec.js (ไฟล์ข้าง ๆ กัน — ทดสอบ endpoint เดียวกันทุก
// test case) ต่างกันแค่วิธี import app: ไฟล์นี้ใช้ dynamic import()
// (importApp() ด้านล่าง) แทนการ import app ด้วย static `import app from
// '../app'` ตรง ๆ ที่หัวไฟล์ — ข้อดีของ dynamic import คือควบคุมได้ว่าจะให้
// โหลดไฟล์ app.js (และทุกไฟล์ที่มันเรียกต่อ เช่น db/knex.js) "ตอนไหน" ได้
// แม่นยำกว่า (เช่น รอให้ beforeAll ตั้งค่า process.env ให้เสร็จก่อนค่อยโหลด)
// ต่างจาก static import ที่ไฟล์จะถูกโหลดทันทีตั้งแต่ก่อนโค้ดอื่นในไฟล์นี้
// รันเลยด้วยซ้ำ (เป็นพฤติกรรมมาตรฐานของ ES Module)
import { describe, it, expect, beforeAll } from 'vitest'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import request from 'supertest'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 👇 ปรับให้ตรงกับไฟล์ที่ export ตัว app (ไม่ใช่ไฟล์ที่ .listen)
const APP_PATH = path.resolve(__dirname, '../app.js')

beforeAll(() => {
  process.env.JWT_SECRET = 'test-secret'
})

// หมายเหตุ: ไม่ mock repository/bcrypt ที่นี่ — auth.controller.js คิวรี DB ผ่าน
// knex ตรง ๆ (ไม่มี repository layer ให้ mock) และ bcrypt เป็น native module ที่
// vi.mock ไม่ intercept การ require() ของ controller ได้จริง เทสต์ชุดนี้จึงยิงใส่
// DB จริงที่ seed ไว้จาก schema.sql (ต้องรัน `docker compose up -d db` ก่อน)
const REAL_EMAIL = 't.it01@vecskill.ovec'
const REAL_PASSWORD = '12345678' // ตรงกับรหัสผ่านที่ seed ไว้จริงใน schema.sql

// นำเข้าแอปจริง
const importApp = async () => {
  const mod = await import(APP_PATH)
  return mod.default || mod.app || mod
}

describe('POST /api/auth/login', () => {
  it('400 when email/password missing', async () => {
    const app = await importApp()
    const r = await request(app).post('/api/auth/login').send({})
    expect(r.status).toBe(400)
    expect(r.body.success).toBe(false)
  })

  it('401 when email not found', async () => {
    const app = await importApp()
    const r = await request(app).post('/api/auth/login').send({
      email: 'no-such-user@vecskill.ovec', password: REAL_PASSWORD
    })
    expect(r.status).toBe(401)
    expect(r.body.success).toBe(false)
  })

  it('401 when wrong password', async () => {
    const app = await importApp()
    const r = await request(app).post('/api/auth/login').send({
      email: REAL_EMAIL, password: 'wrong-password'
    })
    expect(r.status).toBe(401)
    expect(r.body.success).toBe(false)
  })

  it('200 returns accessToken and user', async () => {
    const app = await importApp()
    const r = await request(app).post('/api/auth/login').send({
      email: REAL_EMAIL, password: REAL_PASSWORD
    })
    expect(r.status).toBe(200)
    expect(r.body.success).toBe(true)
    expect(r.body).toHaveProperty('accessToken')
    expect(r.body.user).toMatchObject({
      email: REAL_EMAIL, role: 'evaluatee'
    })
  })
})
