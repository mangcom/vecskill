// ============================================================
//  วิชา: Software Testing & DevOps Integration
//  หัวข้อ: Integration Test ด้วย Vitest + Supertest
//  ตัวอย่างทดสอบ API /api/auth/login ของระบบ Backend จริง
//
//  "Integration test" ต่างจาก "unit test" (ดู auth.unit.test.js,
//  auth.unit1.test.js ในโฟลเดอร์นี้) ตรงที่ไฟล์นี้ยิง HTTP request จริงผ่าน
//  supertest เข้า Express app ทั้งก้อน (ผ่าน middleware ทุกตัว, route จริง,
//  คุยกับฐานข้อมูลจริง) ทดสอบว่า "ระบบทั้งระบบทำงานร่วมกันถูกต้องไหม" ไม่ใช่
//  แค่ฟังก์ชันเดียวโดด ๆ
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest'
import request from 'supertest'  // ใช้ยิง HTTP Request จำลองโดยไม่ต้อง start server

// ------------------------------------------------------------
// 🔹 ขั้นตอนเตรียม Environment ก่อนทุก Test (Arrange ระดับ Global)
// ------------------------------------------------------------
beforeEach(() => {
  // ตั้งค่าตัวแปรสภาพแวดล้อมให้คงที่
  // เพื่อไม่ต้องพึ่ง .env ของระบบจริง (ทำให้ผลลัพธ์แน่นอนทุกครั้ง)
  process.env.JWT_SECRET = 'test-secret'
})

// ------------------------------------------------------------
// 🔹 หมายเหตุ: ไม่ mock repository/bcrypt ที่นี่
// ------------------------------------------------------------
// auth.controller.js คิวรี DB ผ่าน knex ตรง ๆ (ไม่มี repository layer ให้ mock)
// และ bcrypt เป็น native module ที่ vi.mock ไม่ intercept การ require() ของ
// controller ได้จริง — เทสต์ชุดนี้จึงยิงใส่ DB จริงที่ seed ไว้จาก schema.sql
// (ต้องรัน `docker compose up -d db` หรือทั้งสแตคก่อนรันเทสต์)
const REAL_EMAIL = 't.it01@vecskill.ovec'
const REAL_PASSWORD = '12345678' // ตรงกับรหัสผ่านที่ seed ไว้จริงใน schema.sql

// ------------------------------------------------------------
// 🔹 นำเข้า Express App จริง (แต่ไม่ start server)
// ------------------------------------------------------------
import app from '../app'
// supertest จะจำลอง request ผ่าน app ได้โดยตรง เช่น request(app).post(...)

// ============================================================
// 🔸 เริ่มต้นชุดทดสอบ (Integration Test)
// ============================================================
describe('POST /api/auth/login', () => {

  // ----------------------------------------------------------
  // 🧩 CASE 1: ไม่ส่ง email/password → ควรได้ 400 Bad Request
  // ----------------------------------------------------------
  it('400 when email/password missing', async () => {
    // 🔹 Arrange: (เตรียมพร้อม) — mock และ env ถูก set แล้ว
    // 🔹 Act: ยิง request โดยไม่ส่ง body
    const r = await request(app).post('/api/auth/login').send({})
    // 🔹 Assert: ตรวจว่าระบบตอบ 400
    expect(r.status).toBe(400)
  })

  // ----------------------------------------------------------
  // 🧩 CASE 2: อีเมลไม่อยู่ในระบบ → 401 Unauthorized
  // ----------------------------------------------------------
  it('401 when email not found', async () => {
    const r = await request(app).post('/api/auth/login')
      .send({ email: 'no-such-user@vecskill.ovec', password: REAL_PASSWORD })
    expect(r.status).toBe(401)
  })

  // ----------------------------------------------------------
  // 🧩 CASE 3: อีเมลถูก แต่รหัสผ่านผิด → 401 Unauthorized
  // ----------------------------------------------------------
  it('401 when wrong password', async () => {
    const r = await request(app).post('/api/auth/login')
      .send({ email: REAL_EMAIL, password: 'wrong-password' })
    expect(r.status).toBe(401)
  })

  // ----------------------------------------------------------
  // 🧩 CASE 4: ข้อมูลถูกต้อง → 200 OK + JWT Token + User Info
  // ----------------------------------------------------------
  it('200 returns accessToken and user', async () => {
    const r = await request(app).post('/api/auth/login')
      .send({ email: REAL_EMAIL, password: REAL_PASSWORD })

    // ตรวจสอบผลลัพธ์ (Assert)
    expect(r.status).toBe(200)                 // สถานะ HTTP ต้องเป็น 200
    expect(r.body.success).toBe(true)          // success flag ต้องเป็น true
    expect(r.body).toHaveProperty('accessToken') // ต้องมี accessToken
    // ตรวจสอบข้อมูล user ว่ามีค่าตรงตามที่ seed ไว้จริงใน schema.sql
    expect(r.body.user).toMatchObject({
      email: REAL_EMAIL,
      role: 'evaluatee'
    })
  })
})
