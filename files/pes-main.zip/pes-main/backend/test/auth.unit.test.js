// test/auth.unit.test.js
//
// ทดสอบแบบ "unit test": เรียกฟังก์ชัน authCtrl.login() ตรง ๆ โดยไม่ผ่าน
// Express/HTTP เลย (ต่างจาก auth.spec.js / auth.fixed.spec.js ที่ยิง HTTP
// request จริงผ่าน supertest) — ต้องสร้าง req/res/next ปลอมขึ้นมาเอง (ดู
// mockReq/mockRes ด้านล่าง) เพราะ Express ไม่ได้เป็นคน "เรียก" ฟังก์ชันให้
// เราในเทสต์แบบนี้
import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest'

// หมายเหตุ: ไม่ mock db/knex, repository หรือ bcrypt ที่นี่ — auth.controller.js
// คิวรี DB ผ่าน knex ตรง ๆ (ไม่มี repository layer ให้ mock) และ bcrypt เป็น
// native module ที่ vi.mock ไม่ intercept การ require() ของ controller ได้จริง
// เทสต์ชุดนี้จึงเรียก authCtrl.login() ตรง ๆ (ไม่ผ่าน Express) แต่ยังยิงใส่ DB
// จริงที่ seed ไว้จาก schema.sql (ต้องรัน `docker compose up -d db` ก่อน)
const REAL_EMAIL = 't.it01@vecskill.ovec'
const REAL_PASSWORD = '12345678' // ตรงกับรหัสผ่านที่ seed ไว้จริงใน schema.sql

let authCtrl
beforeAll(async () => {
  // import() แบบ dynamic (ไม่ใช่ static import ด้านบนสุดไฟล์) เพื่อให้แน่ใจ
  // ว่าโหลดไฟล์ controller "หลังจาก" ตั้งค่า test setup ต่าง ๆ แล้ว
  const mod = await import('../controllers/auth.controller.js')
  // controller ไฟล์นี้เขียนแบบ CommonJS (module.exports.login = ...) พอถูก
  // import แบบ ESM จะได้ mod.default เป็น object ที่มี .login อยู่ข้างใน
  // (ไม่ใช่ mod.login ตรง ๆ) เงื่อนไขนี้จึงเช็กทั้งสองแบบไว้กันเหนียว เผื่อ
  // รูปแบบการ export เปลี่ยนไปในอนาคต
  authCtrl = mod.default?.login ? mod.default : mod
})

function mockReq(body = {}) { return { body } }
// สร้าง request object ปลอมขึ้นมาเอง — ของจริง Express req มี property อีก
// เยอะมาก (headers, params, query, ...) แต่ authCtrl.login ใช้แค่ req.body
// เท่านั้น จึงปลอมมาแค่เท่าที่จำเป็นพอ
function mockRes() {
  const res = {}
  res.status = vi.fn(() => res)
  // vi.fn(() => res) สร้างฟังก์ชันปลอมที่ "จำ" ได้ว่าเคยถูกเรียกด้วยอะไรบ้าง
  // (เช็กย้อนหลังได้ผ่าน res.status.mock.calls) แล้วคืนค่า res ตัวเอง
  // กลับไป เพื่อให้เขียนแบบ res.status(401).json({...}) ต่อกันได้เหมือน
  // Express ของจริง (เรียกว่า "method chaining")
  res.json   = vi.fn(() => res)
  return res
}

beforeEach(() => {
  vi.clearAllMocks()
  // ล้างประวัติการเรียกของทุก mock ก่อนเริ่มแต่ละ test case ใหม่ (ไม่งั้น
  // res.status.mock.calls ของ test ก่อนหน้าจะค้างมาปนกับ test ถัดไป)
  process.env.JWT_SECRET = 'test-secret'
})

function expect401Either(res, next) {
  // ฟังก์ชันนี้มีไว้เพราะ controller ตอบ error ได้ "สองแบบ" แล้วแต่สถานการณ์
  // (ดู controllers/auth.controller.js: บางจุด res.status(401).json(...)
  // เองตรง ๆ) — เทสต์นี้จึงยอมรับทั้งสองแบบว่า "ถือว่าเป็น 401 เหมือนกัน"
  // แทนที่จะผูกติดกับรูปแบบใดรูปแบบหนึ่งเป๊ะ ๆ ซึ่งจะเปราะบางเกินไปถ้า
  // controller เปลี่ยนวิธีตอบ error ในอนาคต
  // A) ตอบเองด้วย res.status(401)
  const viaStatus = res.status.mock.calls.some(([code]) => code === 401)
  // .some(...) เช็กว่า "มีครั้งไหนเลยไหม" ที่ res.status ถูกเรียกด้วย
  // argument เป็น 401 (เผื่อกรณีถูกเรียกหลายครั้งด้วยค่าต่างกัน)
  // B) ส่งผ่าน next(err) โดยมี status = 401
  const viaNext = next.mock.calls[0] &&
    ((next.mock.calls[0][0]?.status ?? next.mock.calls[0][0]?.statusCode) === 401)
  // next.mock.calls[0] คือ argument ของการเรียก next(...) ครั้งแรก — ถ้า
  // controller เรียก next(err) ให้ดู err.status (ที่ middlewares/auth.js
  // ใช้ชื่อนี้) หรือ err.statusCode (ชื่อทางเลือกที่บาง error object ใช้)
  expect(viaStatus || viaNext).toBe(true)
}

describe('auth.controller.login (unit)', () => {
  it('400 when email/password missing', async () => {
    const res  = mockRes()
    const next = vi.fn()

    await authCtrl.login(mockReq({}), res, next)

    // กรณี 400 ส่วนใหญ่คอนโทรลเลอร์ตอบเอง
    const viaStatus400 = res.status.mock.calls.some(([code]) => code === 400)
    const viaNext400   = next.mock.calls[0] &&
      ((next.mock.calls[0][0]?.status ?? next.mock.calls[0][0]?.statusCode) === 400)
    expect(viaStatus400 || viaNext400).toBe(true)
  })

  it('401 when email not found', async () => {
    const res  = mockRes()
    const next = vi.fn()

    await authCtrl.login(
      mockReq({ email: 'no-such-user@vecskill.ovec', password: REAL_PASSWORD }),
      res,
      next
    )

    expect401Either(res, next)
  })

  it('401 when wrong password', async () => {
    const res  = mockRes()
    const next = vi.fn()

    await authCtrl.login(
      mockReq({ email: REAL_EMAIL, password: 'wrong-password' }),
      res,
      next
    )

    expect401Either(res, next)
  })

  it('200 returns token and user', async () => {
    const res  = mockRes()
    const next = vi.fn()

    await authCtrl.login(
      mockReq({ email: REAL_EMAIL, password: REAL_PASSWORD }),
      res,
      next
    )

    // สำเร็จ → ไม่ควรไป next(err)
    expect(next).not.toHaveBeenCalled()
    expect(res.json).toHaveBeenCalled()
    const payload = res.json.mock.calls[0][0]
    expect(payload.success).toBe(true)
    expect(payload).toHaveProperty('accessToken')
    expect(payload.user).toMatchObject({ email: REAL_EMAIL, role: 'evaluatee' })
  })
})
