// test/auth.unit1.test.js
//
// อีกเวอร์ชันของ unit test สำหรับ authCtrl.login() (เทียบกับ
// auth.unit.test.js ที่อยู่ข้าง ๆ กัน) — ไฟล์นี้สั้นกว่า มีแค่ 1 test case
// (เฉพาะกรณี login สำเร็จ) และ import controller ใหม่ "ทุก" test case (ใน
// beforeEach) แทนที่จะ import แค่ครั้งเดียวใน beforeAll เหมือนไฟล์โน้น — ทั้ง
// สองแบบใช้ได้ผลเหมือนกันในที่นี้ เพราะ controller ไม่มี state ภายในตัวเองที่
// ต้องรีเซ็ตระหว่าง test case เก็บไว้เป็นตัวอย่างสองสไตล์การเขียน setup ที่
// ต่างกันให้เปรียบเทียบ
import { describe, it, expect, vi, beforeEach } from 'vitest'

// หมายเหตุ: ไม่ mock repository/bcrypt/jwt ที่นี่ — auth.controller.js คิวรี DB
// ผ่าน knex ตรง ๆ (ไม่มี repository layer ให้ mock) และ bcrypt เป็น native module
// ที่ vi.mock ไม่ intercept การ require() ของ controller ได้จริง เทสต์นี้จึงเรียก
// authCtrl.login() ตรง ๆ แต่ยังยิงใส่ DB จริงที่ seed ไว้จาก schema.sql
// (ต้องรัน `docker compose up -d db` ก่อน)
const REAL_EMAIL = 't.it01@vecskill.ovec'
const REAL_PASSWORD = '12345678' // ตรงกับรหัสผ่านที่ seed ไว้จริงใน schema.sql

let authCtrl

beforeEach(async () => {
  process.env.JWT_SECRET = 'test-secret'
  const mod = await import('../controllers/auth.controller.js')
  authCtrl = mod.default?.login ? mod.default : mod
})

function mockReq(body = {}) { return { body } }
function mockRes() {
  const res = {}
  res.status = vi.fn(() => res)
  res.json = vi.fn(() => res)
  return res
}

describe('auth.controller.login (unit)', () => {
  it('200 returns token and user', async () => {
    const req = mockReq({ email: REAL_EMAIL, password: REAL_PASSWORD })
    const res = mockRes()

    await authCtrl.login(req, res, vi.fn())

    // ✅ ยืนยันผลลัพธ์
    expect(res.status).not.toHaveBeenCalled() // 200 โดยปริยาย
    expect(res.json).toHaveBeenCalled()

    const payload = res.json.mock.calls[0][0]
    expect(payload.success).toBe(true)
    expect(payload).toHaveProperty('accessToken')
    expect(payload.user).toMatchObject({ email: REAL_EMAIL, role: 'evaluatee' })
  })
})
