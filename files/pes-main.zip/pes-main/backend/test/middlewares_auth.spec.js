// tests/middlewares_auth.spec.js
//
// ทดสอบ middlewares/auth.js (ฟังก์ชัน auth(...roles)) แบบแยกเดี่ยว ๆ โดยไม่
// พึ่ง app.js ของระบบจริงเลย — สร้าง Express app จำลองเล็ก ๆ ของตัวเองขึ้นมา
// (ดูฟังก์ชัน mini() ด้านล่าง) ที่มีแค่ route เดียวพอทดสอบ แนวทางนี้ต่างจาก
// auth.spec.js ที่ทดสอบผ่าน app จริงทั้งก้อน — ข้อดีของการทดสอบแบบนี้คือ
// โฟกัสเฉพาะ "พฤติกรรมของ middleware ตัวนี้เพียว ๆ" ไม่ปนกับ logic อื่นของ
//ระบบ (เช่น logic ของ auth.controller.js) และไม่ต้องพึ่งฐานข้อมูลเลย
// (middleware นี้ตรวจแค่ตัว token เอง ไม่ได้คิวรีฐานข้อมูล)

import { describe, it, expect, beforeEach } from 'vitest'
import request from 'supertest'
import express from 'express'
import jwt from 'jsonwebtoken'
import auth from '../middlewares/auth'

beforeEach(() => { process.env.JWT_SECRET = 'test-secret' })

function mini(roleRequired) {
  // สร้าง Express app เปล่า ๆ ขึ้นมาใหม่ทุกครั้งที่เรียกฟังก์ชันนี้ แล้วผูก
  // route ทดสอบ GET /p ไว้ "หลัง" middleware auth(roleRequired) — ถ้า
  // middleware ปล่อยผ่าน (เรียก next()) ถึงจะมาถึง handler ที่ตอบ
  // { ok:true, user:req.user } กลับไป (req.user คือสิ่งที่ auth middleware
  // แนบไว้ให้ ใช้ตรวจสอบได้ด้วยว่า payload ที่ decode ออกมาถูกต้องไหม)
  const app = express()
  app.get('/p', auth(roleRequired), (req,res)=>res.json({ok:true, user:req.user}))
  return app
}
const bearer = (payload) => `Bearer ${jwt.sign(payload, process.env.JWT_SECRET)}`
// ฟังก์ชันช่วยสร้าง header Authorization แบบเต็ม ๆ จาก payload ที่ต้องการ
// ให้ฝังอยู่ใน token (jwt.sign ใช้ JWT_SECRET เดียวกับที่ auth middleware
// ใช้ verify จึงถือว่าเป็น token ที่ "ถูกต้อง" ในสายตาของ middleware)

describe('auth(role)', () => {
  it('401 when missing token', async () => {
    // ไม่แนบ header Authorization มาเลย -> ต้องโดน 401 (ดู
    // middlewares/auth.js บรรทัดที่เช็ก !token)
    const r = await request(mini('admin')).get('/p')
    expect(r.status).toBe(401)
  })
  it('403 when role mismatch', async () => {
    // แนบ token ที่ถูกต้อง (เซ็นด้วยกุญแจตรงกัน) แต่ role ในนั้นคือ
    // 'evaluatee' ขณะที่ route ต้องการ 'admin' เท่านั้น -> ต้องโดน 403
    // (ผ่านการตรวจสอบตัวตนแล้ว แต่ไม่มีสิทธิ์)
    const r = await request(mini('admin')).get('/p')
      .set('Authorization', bearer({ id:1, role:'evaluatee' }))
    expect(r.status).toBe(403)
  })
  it('200 when role ok', async () => {
    // role ตรงกับที่ route ต้องการพอดี ('admin') -> ต้องผ่านไปถึง handler
    // จริง ได้ 200 กลับมา พร้อม req.user ที่ middleware แนบไว้ให้
    const r = await request(mini('admin')).get('/p')
      .set('Authorization', bearer({ id:2, role:'admin' }))
    expect(r.status).toBe(200)
    expect(r.body.ok).toBe(true)
  })
})
