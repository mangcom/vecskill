// tests/repositories_indicatorEvidence.spec.js
//
// ทดสอบ repositories/indicatorEvidence.js -> mapExists() ฟังก์ชันเดียวของ
// ไฟล์นั้น (เช็กว่าคู่ indicator_id + evidence_type_id นี้ได้รับอนุญาตไหม)
//
// หมายเหตุสำคัญ (เหมือนกับไฟล์ auth.*.spec.js ในโฟลเดอร์นี้): เดิมไฟล์นี้
// เคย vi.mock('../db/knex', ...) เพื่อจำลองฐานข้อมูลในหน่วยความจำ แต่ด้วย
// การตั้งค่า Vitest + CommonJS ("type":"commonjs" ใน package.json) ของ
// โปรเจกต์นี้ vi.mock ไม่ได้ intercept การ require('../db/knex') ที่เกิดขึ้น
// ข้างในไฟล์ repository จริง ๆ (เหมือนปัญหาเดียวกับที่พบใน bcrypt ของชุดเทส
// auth) ทำให้โค้ดวิ่งไปชนฐานข้อมูลจริงอยู่ดี แต่ไม่มีตาราง indicator_evidence
// ที่ seed ไว้ตรงกับข้อมูลปลอมในมือก็เลย error "Undefined binding(s)" — อีก
// จุดหนึ่งคือของเดิมเรียก `repo.mapExists(2, 3)` แบบส่ง 2 พารามิเตอร์แยกกัน
// ทั้งที่ฟังก์ชันจริงรับพารามิเตอร์เดียวเป็น object
// ({ indicator_id, evidence_type_id }) — เรียกแบบเดิมจะได้ indicator_id/
// evidence_type_id เป็น undefined เสมอ ทดสอบจึงพังทั้งคู่
//
// แก้ไขโดยเปลี่ยนมาทดสอบแบบ integration เหมือนชุด auth: ยิงใส่ฐานข้อมูล
// จริงที่ seed ไว้จาก schema.sql ตรง ๆ (ต้องรัน `docker compose up -d db`
// หรือทั้งสแตคก่อนรันเทสต์) และเรียกฟังก์ชันด้วย signature ที่ถูกต้อง

import { describe, it, expect } from 'vitest'
import repo from '../repositories/indicatorEvidence'

// ค่าที่ seed จริงไว้ใน schema.sql: indicator_id=1 (T1-PLAN) ผูกกับ
// evidence_type_id=1 (E-PLAN) ไว้แล้ว (ดูตาราง indicator_evidence)
const REAL_INDICATOR_ID = 1
const REAL_EVIDENCE_TYPE_ID = 1
const NOT_MAPPED_EVIDENCE_TYPE_ID = 999999 // id ที่ไม่น่ามีอยู่จริงในตารางนี้แน่ ๆ

describe('indicatorEvidence.mapExists', () => {
  it('true when mapping exists', async () => {
    const ok = await repo.mapExists({
      indicator_id: REAL_INDICATOR_ID,
      evidence_type_id: REAL_EVIDENCE_TYPE_ID,
    })
    // ต้อง "ส่งเป็น object" ({ indicator_id, evidence_type_id }) เท่านั้น —
    // ตรงกับวิธีเรียกจริงใน controllers/upload.controller.js และ
    // routes/attachments.js
    expect(ok).toBe(true)
  })

  it('false when mapping absent', async () => {
    const ok = await repo.mapExists({
      indicator_id: REAL_INDICATOR_ID,
      evidence_type_id: NOT_MAPPED_EVIDENCE_TYPE_ID,
    })
    expect(ok).toBe(false)
  })
})
