// test/server.spec.js
//
// เทสต์ที่สั้นและง่ายที่สุดในระบบ: แค่เช็กว่า GET /health ตอบกลับถูกต้อง
// (ดู endpoint จริงใน app.js) มีประโยชน์เป็น "เทสต์ชิมลาง" ตรวจว่า Express
// app โหลดขึ้นมาได้โดยไม่ error เลยตั้งแต่ชั้นพื้นฐานที่สุด ก่อนจะไปเทสต์
// เรื่องซับซ้อนกว่านี้ (login, upload) ในไฟล์อื่น

import { describe, it, expect } from 'vitest'
import request from 'supertest'
import app from '../app.js'        // ✅ default import ให้ตรงกับ module.exports = app

describe('HEALTH CHECK', () => {
  it('GET /health ตอบกลับ service and time', async () => {
    const r = await request(app).get('/health')
    expect(r.status).toBe(200)
    // ✓ ตรวจว่าเป็น JSON ที่มี service และ time
    expect(r.body).toHaveProperty('service', 'vecskill-backend')
    expect(typeof r.body.time).toBe('string') // เป็น ISO string
  })
})
