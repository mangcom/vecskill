// tests/upload.spec.js
//
// ทดสอบ POST /api/upload/evidence (ดู routes/upload.routes.js ->
// controllers/upload.controller.js -> uploadEvidence)
//
// หมายเหตุสำคัญ (เหมือนกับไฟล์ auth.*.spec.js และ
// repositories_indicatorEvidence.spec.js ในโฟลเดอร์นี้): เดิมไฟล์นี้เคย
// vi.mock(...) ทั้ง middlewares/upload (ปลอม req.file), repositories/
// assignments, repositories/indicatorEvidence, repositories/attachments
// และ db/knex (ฐานข้อมูลปลอมในหน่วยความจำ) แต่ด้วยการตั้งค่า Vitest + CommonJS
// ของโปรเจกต์นี้ vi.mock ไม่ได้ intercept การ require(...) ที่เกิดขึ้นจริง
// ข้างในไฟล์ repository/middleware เลย (ปัญหาเดียวกับที่พบในชุดเทส auth —
// ดูคอมเมนต์ใน auth.spec.js) ผลคือ:
//   - middlewares/upload (multer) ของจริงถูกใช้งาน แต่ request ไม่ได้แนบไฟล์
//     จริงมาด้วย (.field() เฉย ๆ ไม่มี .attach()) req.file จึงเป็น undefined
//     เสมอ ไม่ใช่ไฟล์ปลอมที่ตั้งใจ mock ไว้
//   - repositories/assignments, indicatorEvidence ตัวจริงถูกเรียก แล้วไปชน
//     db/knex "ปลอม" ที่ mock ไว้ (ซึ่งก็ดันถูก intercept จริงในจุดนี้ เพราะ
//     repository require('../db/knex') เป็นแค่การ require ปกติ) แต่ db ปลอม
//     นั้นไม่ได้ทำ table 'assignments' ไว้เลย จึงคืน null -> hasEvaluateeInPeriod
//     ได้ false เสมอ -> อัปโหลดไม่ผ่านด้วยเหตุผลคนละอย่างกับที่ตั้งใจทดสอบ
//
// แก้ไขโดยเปลี่ยนมาทดสอบแบบ integration เหมือนชุด auth: ไม่ mock อะไรเลย
// ยิง request จริงเข้า Express app จริง แนบไฟล์จริง (.attach) และใช้ข้อมูล
// ที่ seed ไว้จริงใน schema.sql (ต้องรัน `docker compose up -d db` หรือทั้ง
// สแตคก่อนรันเทสต์)

import { describe, it, expect, beforeEach, afterAll } from 'vitest'
import request from 'supertest'
import jwt from 'jsonwebtoken'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import app from '../app'
import db from '../db/knex'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const UPLOADS_DIR = path.join(__dirname, '..', 'uploads')

beforeEach(() => { process.env.JWT_SECRET = 'test-secret' })

const bearer = (payload) => `Bearer ${jwt.sign(payload, process.env.JWT_SECRET)}`

// ข้อมูลจริงที่ seed ไว้ใน schema.sql:
// - user id=4 (t.it01@vecskill.ovec) role 'evaluatee' ถูก assign อยู่ใน
//   period_id=1 จริง (ดูตาราง assignments)
// - period_id=1 ยัง is_active=1 อยู่
// - indicator_id=1 (T1-PLAN) จับคู่กับ evidence_type_id=1 (E-PLAN) ไว้แล้ว
//   ในตาราง indicator_evidence
const REAL_EVALUATEE_ID = 4
const REAL_PERIOD_ID = 1
const REAL_INDICATOR_ID = 1
const REAL_EVIDENCE_TYPE_ID = 1

// เก็บ id ของแถวที่สร้างขึ้นระหว่างเทสต์ไว้ เพื่อลบทิ้งหลังจบ (ไม่อยากให้
// รันเทสต์ซ้ำ ๆ แล้วมีไฟล์/ข้อมูลขยะสะสมอยู่ในฐานข้อมูล dev เรื่อย ๆ)
let createdAttachmentId

afterAll(async () => {
  if (createdAttachmentId) {
    const row = await db('attachments').where({ id: createdAttachmentId }).first()
    await db('attachments').where({ id: createdAttachmentId }).del()
    if (row) {
      const abs = path.join(UPLOADS_DIR, row.storage_path)
      try { fs.unlinkSync(abs) } catch {}
    }
  }
  await db.destroy()
  // ปิด connection pool ของ knex หลังเทสต์ทั้งไฟล์จบ ไม่งั้น vitest process
  // จะค้างรอ (connection ที่เปิดไว้ใน pool ไม่ได้ปิดเอง)
})

describe('POST /api/upload/evidence', () => {
  it('401 without token', async () => {
    const r = await request(app).post('/api/upload/evidence')
    expect(r.status).toBe(401)
  })

  it('400 when missing required fields', async () => {
    const r = await request(app).post('/api/upload/evidence')
      .set('Authorization', bearer({ id: REAL_EVALUATEE_ID, role: 'evaluatee' }))
      .field('period_id', String(REAL_PERIOD_ID)) // ขาด indicator_id/evidence_type_id
    expect(r.status).toBe(400)
  })

  it('201 when upload ok', async () => {
    const r = await request(app).post('/api/upload/evidence')
      .set('Authorization', bearer({ id: REAL_EVALUATEE_ID, role: 'evaluatee' }))
      .field('period_id', String(REAL_PERIOD_ID))
      .field('indicator_id', String(REAL_INDICATOR_ID))
      .field('evidence_type_id', String(REAL_EVIDENCE_TYPE_ID)) // mapping ถูกต้องตามสคีมาจริง
      .attach('file', Buffer.from('tiny-test-file'), {
        filename: 'tiny.png',
        contentType: 'image/png',
      })
      // .attach(...) คือการแนบไฟล์จริง (ไม่ใช่แค่ field ข้อความ) — ชื่อ field
      // ต้องเป็น "file" ให้ตรงกับที่ upload.single('file') คาดหวังไว้ (ดู
      // routes/upload.routes.js)

    expect(r.status).toBe(201)
    expect(r.body.success).toBe(true)
    expect(r.body.data).toMatchObject({
      period_id: REAL_PERIOD_ID,
      evaluatee_id: REAL_EVALUATEE_ID,
      indicator_id: REAL_INDICATOR_ID,
      evidence_type_id: REAL_EVIDENCE_TYPE_ID,
      file_name: 'tiny.png',
      mime_type: 'image/png',
    })
    expect(r.body.data).toHaveProperty('url') // controller คืน url ที่คำนวณจาก storage_path
    createdAttachmentId = r.body.data.id
  })
})
