# Nuxt3 Minimal Frontend

## Quick Start (without Docker)
1) `npm install`
2) Create `.env` (optional) — only needed if the backend is NOT reachable at
   `<same-host-as-this-page>:7000`: `NUXT_PUBLIC_API_BASE=http://127.0.0.1:7000`
3) `npm run dev` then open http://localhost:3000

Default login (matches backend seed — see root schema.sql):
- admin@vecskill.ovec / 12345678
