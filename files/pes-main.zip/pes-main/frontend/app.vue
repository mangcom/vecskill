<!-- app.vue (minimum) -->
<!--
  นี่คือ "component รากของทั้งแอป" — ไฟล์ app.vue ที่ Nuxt 3 จะมองหาเป็น
  อันดับแรกเสมอ (ถ้าไม่มีไฟล์นี้ Nuxt จะใช้ค่า default ของตัวเองแทน) ทุกหน้า
  ในโฟลเดอร์ pages/ จะถูก render เข้ามาแทนที่ <NuxtPage /> ด้านล่างนี้เสมอ

  ไฟล์นี้เรียกว่า "minimum" (ขั้นต่ำสุด) เพราะมีแค่ 2 บรรทัดเนื้อหาจริง ไม่มี
  logic อะไรเพิ่มเติมเลย — โครงสร้างหน้าตาจริง (แถบเมนู, app bar, footer)
  ไปอยู่ในไฟล์ layouts/*.vue แทน (ดู layouts/default.vue, dashboard.vue,
  auth-login.vue)
-->
<template>
  <NuxtLayout>
    <!-- <NuxtLayout> คือกรอบที่เลือก "layout" ให้อัตโนมัติตามที่แต่ละหน้า
         ประกาศไว้ด้วย definePageMeta({ layout: '...' }) (ถ้าหน้าไหนไม่ได้
         ประกาศไว้ จะใช้ layouts/default.vue เป็นค่าเริ่มต้น) -->
    <NuxtPage />
    <!-- <NuxtPage /> คือจุดที่เนื้อหาจริงของแต่ละหน้า (ไฟล์ใน pages/)
         จะถูกสอดเข้ามาแสดงผล ขึ้นอยู่กับ URL ปัจจุบันว่าตรงกับหน้าไหน -->
  </NuxtLayout>
</template>
