// ~/composables/useApiBase.js
//
// ที่มาของ URL backend ที่ frontend เรียกใช้:
// 1) ถ้าตั้งค่า NUXT_PUBLIC_API_BASE ไว้ (ไม่ว่างเปล่า) ใช้ค่านั้น — รับได้ทั้ง
//    URL เต็ม ("http://host:7000") และ host/IP/domain เปล่า ๆ ("host" หรือ
//    "host:port") แล้วเติม scheme/port ให้อัตโนมัติถ้าขาด (กันพิมพ์ผิดแบบ
//    ลืมใส่ http:// หรือพอร์ต)
// 2) ถ้าไม่ได้ตั้งค่าไว้ (ค่าว่าง) ให้เดาจาก host ที่ browser ใช้เปิดหน้านี้เอง
//    (protocol + hostname เดียวกับที่อยู่บน address bar) + พอร์ตของ backend
//    (ค่าจาก NUXT_PUBLIC_API_PORT — ดีฟอลต์ "7000" ถ้าไม่ได้ตั้งไว้) วิธีนี้
//    ทำให้เปิดผ่าน localhost, 127.0.0.1, IP วง LAN (เช่น 192.168.100.102)
//    หรือ domain จริง (เช่น apps.vecskill.ovec) ก็ใช้งานได้ทันทีโดยไม่ต้องแก้ .env
//
// พอร์ตของ backend ("7000" ดีฟอลต์) ไม่ได้ hardcode ไว้ในไฟล์นี้โดยตรง —
// อ่านจาก config.public.apiPort แทน (มาจาก NUXT_PUBLIC_API_PORT ที่
// docker-compose.yml ตั้งให้ตรงกับค่า BACKEND_PORT ใน .env อัตโนมัติ —
// เปลี่ยนพอร์ตที่ .env ค่าเดียว ไม่ต้องมาแก้ไฟล์นี้)
//
// composable นี้ถูกเรียกใช้จาก 2 ที่หลัก: plugins/axios.client.js (ตั้งเป็น
// baseURL ของ axios instance กลางทั้งแอป) และ composables/useMenu.js (สร้าง
// ลิงก์ API Docs แบบ dynamic) — การรวม logic คำนวณ URL ไว้ที่เดียวแบบนี้
// ทำให้ไม่ต้องเขียนเงื่อนไขเดียวกันซ้ำหลายที่
export function useApiBase() {
  const config = useRuntimeConfig()
  // useRuntimeConfig() คือฟังก์ชันของ Nuxt ที่ดึงค่าจาก runtimeConfig ใน
  // nuxt.config.ts ออกมาใช้ตอนรันจริง (auto-import ให้แล้ว ไม่ต้อง import
  // เอง) — .public.apiBase คือค่าที่มาจากตัวแปรสภาพแวดล้อม
  // NUXT_PUBLIC_API_BASE (ถ้าตั้งไว้ใน .env ที่ root ตอน build/รัน
  // docker compose)
  const explicit = (config.public.apiBase || '').trim()
  // (... || '') กันกรณี apiBase เป็น undefined แล้ว .trim() ตัดช่องว่าง
  // หน้า-หลังออก — ผลลัพธ์คือ explicit จะเป็นสตริงว่างก็ต่อเมื่อไม่ได้ตั้งค่า
  // NUXT_PUBLIC_API_BASE ไว้เลย (หรือตั้งไว้เป็นค่าว่าง/ช่องว่างล้วน ๆ)
  const apiPort = config.public.apiPort || '7000'
  // พอร์ตของ backend ที่จะใช้เติมให้อัตโนมัติเวลาค่าที่ตั้งไว้ไม่มีพอร์ตต่อ
  // ท้ายมา (หรือตอน auto-detect จาก host ปัจจุบัน) — ดูคอมเมนต์หัวไฟล์

  if (explicit) {
    // เข้าเงื่อนไขนี้เมื่อมีคนตั้งค่า NUXT_PUBLIC_API_BASE ไว้จริง (ไม่ว่าง)
    if (/^https?:\/\//.test(explicit)) return explicit
    // ถ้าค่าที่ตั้งไว้ขึ้นต้นด้วย http:// หรือ https:// อยู่แล้ว (เป็น URL
    // เต็มรูปแบบ) ก็ใช้ตรง ๆ เลย ไม่ต้องแก้ไขอะไรเพิ่ม (เช่นถ้าตั้งไว้เป็น
    // "http://127.0.0.1:7000" ก็คืนค่านี้กลับไปทันที)
    const protocol = process.client ? window.location.protocol : 'http:'
    // ถ้าค่าที่ตั้งไว้เป็นแค่ host/IP เปล่า ๆ (ไม่มี http://) ต้องหา protocol
    // (scheme) มาเติมให้เอง — process.client เป็น true เฉพาะตอนรันอยู่ใน
    // เบราว์เซอร์จริง (ถ้าเป็น false คือรันฝั่งเซิร์ฟเวอร์ตอน build/SSR ซึ่ง
    // ไม่มี window ให้ใช้ จึง fallback เป็น 'http:' เฉย ๆ) ถ้าเป็น client
    // จริง ให้ใช้ protocol เดียวกับที่หน้าเว็บปัจจุบันถูกเปิดอยู่ (เช่นถ้า
    // frontend เปิดด้วย https:// ก็ให้เรียก backend ด้วย https:// เหมือนกัน
    // กัน mixed-content ที่เบราว์เซอร์บล็อก)
    const hasPort = /:\d+$/.test(explicit)
    // เช็กว่าค่าที่ตั้งไว้มีพอร์ตต่อท้ายอยู่แล้วไหม (regex /:\d+$/ แปลว่า
    // "ลงท้ายด้วยเครื่องหมาย : ตามด้วยตัวเลขหนึ่งตัวขึ้นไป") เช่น
    // "127.0.0.1:8080" จะ match (hasPort = true) แต่ "127.0.0.1" เปล่า ๆ
    // จะไม่ match (hasPort = false)
    return `${protocol}//${hasPort ? explicit : `${explicit}:${apiPort}`}`
    // ประกอบ URL สุดท้าย: ถ้ามีพอร์ตอยู่แล้วก็ใช้ explicit ตรง ๆ ต่อท้าย
    // protocol// ถ้ายังไม่มีพอร์ต ให้เติมพอร์ตของ backend (apiPort) ต่อท้าย
    // ให้เอง — นี่คือจุดที่ทำให้พิมพ์แค่ "127.0.0.1" หรือ
    // "192.168.100.102" เฉย ๆ ใน .env ก็ใช้งานได้ถูกต้อง ไม่ต้องจำว่าต้อง
    // พิมพ์ "http://" และพอร์ตให้ครบเองทุกครั้ง
  }

  // ถึงตรงนี้แปลว่าไม่ได้ตั้งค่า NUXT_PUBLIC_API_BASE ไว้เลย (ค่าแนะนำ/
  // ค่าเริ่มต้นของระบบนี้) ต้อง "เดา" เอาเองจาก host ปัจจุบัน
  if (process.client) {
    return `${window.location.protocol}//${window.location.hostname}:${apiPort}`
    // window.location.protocol คือ "http:" หรือ "https:" (มี : ต่อท้ายอยู่
    // แล้วในตัวมันเอง) window.location.hostname คือชื่อ host/IP ที่อยู่บน
    // address bar ของเบราว์เซอร์ตอนนี้ "โดยไม่รวม" พอร์ต (ต่างจาก
    // window.location.host ที่จะรวมพอร์ตมาด้วยถ้ามี) — ประกอบกับพอร์ตของ
    // backend (apiPort) ต่อท้ายเอง ได้ URL ที่ "ชี้กลับไปที่ host เดียวกับ
    // ที่เปิด frontend อยู่ แต่เปลี่ยนไปที่พอร์ตของ backend แทน" ซึ่งถูกต้อง
    // เสมอตราบใดที่ frontend กับ backend รันอยู่บนเครื่อง/โดเมนเดียวกัน
    // (กรณีปกติของการใช้ docker compose ตามที่ตั้งไว้ในโปรเจกต์นี้)
  }
  return `http://127.0.0.1:${apiPort}`
  // กรณีสุดท้าย: process.client เป็น false (ไม่มี window ให้ใช้เลย เช่นตอน
  // build ฝั่งเซิร์ฟเวอร์) ไม่มีทางรู้ได้ว่าจะถูกเปิดจาก host ไหนในอนาคต จึง
  // คืนค่า fallback ที่ปลอดภัยที่สุดไปก่อน (127.0.0.1 คือค่าที่ใช้ได้เสมอบน
  // เครื่องเดียวกัน) — ค่านี้จะไม่ถูกใช้งานจริงตอน browser โหลดหน้าเว็บ
  // เสร็จแล้ว เพราะโค้ดจะกลับไปเข้าเงื่อนไข process.client ด้านบนแทน
}
