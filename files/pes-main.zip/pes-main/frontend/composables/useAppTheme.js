// ~/composables/useAppTheme.js
//
// รวม logic ของการสลับโหมดสว่าง/มืด (light/dark theme) ไว้ที่เดียว ให้ทั้ง
// layouts/default.vue และ layouts/dashboard.vue เรียกใช้ร่วมกัน — เดิมแต่ละ
// layout เขียน logic นี้แยกกันเอง (จริง ๆ คือ layouts/dashboard.vue มีของ
// ตัวเอง ส่วน layouts/default.vue ไม่มีเลย มีแค่ลิงก์ "Theme" ที่ไม่ได้ทำงาน
// จริง) ทำให้สลับธีมได้ไม่สม่ำเสมอกันทั้งระบบ — ไฟล์นี้แก้ปัญหานั้นโดยให้มี
// แหล่งความจริงเดียว (single source of truth) ที่ทุกหน้าพึ่งพาเหมือนกันหมด
//
// ทำไมใช้ module-level variable (initialized) แทนที่จะเก็บไว้ใน useState?
// เพราะอยากให้ "ขั้นตอนกู้คืนธีมจาก localStorage" เกิดขึ้นแค่ครั้งเดียวจริง ๆ
// ต่อการโหลดแอปหนึ่งรอบ ไม่ว่าจะมีกี่ layout/กี่หน้าที่เรียก initTheme() ก็
// ตาม (เช่น ผู้ใช้กด navigate ไปมาระหว่างหน้าที่ใช้ default.vue กับ
// dashboard.vue หลายรอบ initTheme() จะถูกเรียกซ้ำทุกครั้งที่ layout mount
// ใหม่ แต่ตัวแปร initialized นี้กันไม่ให้มันไปอ่าน localStorage/เขียนทับธีม
// ซ้ำโดยไม่จำเป็น) — ตัวแปรนี้อยู่นอกฟังก์ชัน useAppTheme() จึงถูกสร้างแค่
// ครั้งเดียวตอนไฟล์นี้ถูก import ครั้งแรก แล้วคงค่าอยู่ตลอดอายุของแอป
import { useTheme } from 'vuetify'
// ต้อง import useTheme เองตรง ๆ (ไม่ได้อยู่ในรายการ auto-import ของ Nuxt —
// Nuxt auto-import ให้เฉพาะไฟล์ในโฟลเดอร์ composables/, utils/ ฯลฯ ของ
// โปรเจกต์เราเองเท่านั้น ไม่ได้ไล่เข้าไปดู export ของ package ภายนอกอย่าง
// 'vuetify' ให้อัตโนมัติ) ถ้าลืมบรรทัดนี้จะได้ error "useTheme is not
// defined" ทันทีตอน runtime (เจอบั๊กนี้จริงตอนเขียนไฟล์นี้ครั้งแรก)

let initialized = false

export function useAppTheme() {
  const theme = useTheme()
  // useTheme() ของ Vuetify คืนตัวควบคุมธีมสีที่เป็น "global" ตัวเดียวทั้งแอป
  // เสมอ ไม่ว่าจะเรียกจาก component ไหนก็ได้ตัวเดียวกัน (ดู
  // plugins/vuetify.ts ที่ตั้งค่าธีม light/dark ไว้) เรียกใช้ได้ปลอดภัยจาก
  // ทั้งสอง layout เพราะ Vuetify ถูกติดตั้งเข้าแอปแล้วตั้งแต่ก่อนที่ layout
  // ไหนจะ mount อยู่แล้วเสมอ (plugin ทำงานก่อน component)
  const themeName = useState('theme', () => 'light')
  // useState('theme', ...) ของ Nuxt คือ state ที่ "ใช้ร่วมกันได้ข้าม
  // component" ทั้งแอป (ผูกกับ key ชื่อ 'theme') — เรียกจาก layout ไหนก็ได้
  // ค่าเดียวกันเสมอ ไม่ได้สร้างใหม่แยกกันทีละ layout

  function applyTheme(name) {
    theme.global.name.value = name
    // สั่งให้ Vuetify เปลี่ยนธีมสีทั้งแอปจริง ๆ (ทุก component ของ Vuetify
    // จะเปลี่ยนสีตามทันที เพราะ theme.global.name.value เป็น reactive ref)
    if (process.client) {
      document.documentElement.setAttribute('data-theme', name)
      // ตั้ง attribute data-theme บน <html> ไว้ด้วย เผื่อ CSS ของ DaisyUI
      // หรือ CSS เองต้องใช้ selector [data-theme="dark"] เลือกสไตล์ตามธีม
      try { localStorage.setItem('theme', name) } catch {}
      // จำค่าธีมที่เลือกไว้ใน localStorage เพื่อให้เปิดแอปรอบถัดไปยังจำธีม
      // ที่เคยเลือกไว้ได้ (try/catch กันกรณี localStorage ใช้ไม่ได้ เช่น
      // โหมด private browsing บางเบราว์เซอร์)
    }
  }

  function toggleTheme() {
    themeName.value = themeName.value === 'dark' ? 'light' : 'dark'
    applyTheme(themeName.value)
  }

  function initTheme() {
    // เรียกจาก onMounted() ของแต่ละ layout — กู้คืนธีมที่เคยเลือกไว้จาก
    // localStorage กลับมาใช้ตอนเปิดแอปรอบใหม่ (เช่น กด refresh หน้าเว็บ)
    if (initialized || !process.client) return
    initialized = true
    let saved = null
    try { saved = localStorage.getItem('theme') } catch {}
    themeName.value = saved || themeName.value
    applyTheme(themeName.value)
  }

  return { themeName, toggleTheme, initTheme }
}
