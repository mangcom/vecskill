// ~/composables/useMenu.js
//
// "Composable" ในภาษา Vue 3 คือฟังก์ชันที่รวม logic/state ที่ใช้ซ้ำได้ไว้
// ด้วยกัน (ชื่อขึ้นต้นด้วย "use" ตามธรรมเนียม) ไฟล์นี้มีหน้าที่เดียวคือ "คืน
// รายการเมนูด้านซ้าย (sidebar) ที่ถูกต้องตาม role ของผู้ใช้ที่ login อยู่"
// ให้ layout เรียกใช้ (ดู layouts/default.vue และ layouts/dashboard.vue ว่า
// เรียกใช้ยังไง) — ไฟล์นี้อยู่ในโฟลเดอร์ composables/ จึงถูก Nuxt
// auto-import ให้อัตโนมัติ ไม่ต้องเขียน import useMenu ... เองในไฟล์ที่ใช้งาน

import { ref, isRef, computed } from 'vue'

// ถ้า backend ส่ง 'evaluatee' ให้ map มาเป็น 'user'
function normalizeRole(r) {
  // ฟังก์ชันนี้แปลง role ดิบ ๆ ที่อาจมาจากหลายแหล่ง (ฐานข้อมูลใช้คำว่า
  // 'evaluatee' แต่เมนูฝั่ง frontend อยากเรียกกลุ่มนี้ว่า 'user' ให้สื่อ
  // ความหมายง่ายกว่า) ให้กลายเป็นค่าที่ MAP ด้านล่างรู้จักแน่นอน
  const x = (r || '').toString().toLowerCase()
  // (r || '') กัน r เป็น null/undefined ก่อนเรียก .toString() (ไม่งั้นจะ
  // error ถ้า r เป็น null/undefined ตรง ๆ) แล้วแปลงเป็นตัวพิมพ์เล็กทั้งหมด
  // เผื่อ role ที่ส่งมาเขียนตัวพิมพ์ใหญ่/เล็กไม่ตรงกัน (เช่น "Admin" vs
  // "admin")
  if (x === 'evaluatee') return 'user'
  // เคสพิเศษ: role ของระบบจริงชื่อ 'evaluatee' แต่ในไฟล์นี้อยากใช้ key ว่า
  // 'user' แทน (อ่านเมนูของกลุ่มนี้ง่ายกว่า เพราะคำว่า user สั้นและเข้าใจ
  // ง่ายกว่า evaluatee สำหรับคนที่เพิ่งมาอ่านโค้ดนี้)
  return ['admin', 'evaluator', 'user'].includes(x) ? x : 'user'
  // ถ้า role เป็นหนึ่งใน 3 ค่าที่รู้จัก (admin/evaluator/user) ให้ใช้ค่านั้น
  // ตรง ๆ ถ้าเป็นค่าอื่นที่ไม่รู้จักเลย (เช่น role แปลก ๆ ที่ไม่น่าเกิดขึ้น)
  // ให้ fallback เป็น 'user' (เมนูน้อยที่สุด ปลอดภัยที่สุด) แทนที่จะ error
  // หรือคืนเมนูว่างเปล่าไปเลย
}

// MAP คือ "พจนานุกรม" role -> รายการเมนู โครงสร้างของแต่ละ role เป็น array
// ของ "หมวดหมู่" (section) แต่ละหมวดมี label (หัวข้อกลุ่ม เช่น "MAIN",
// "MANAGEMENT") และ items (array ของเมนูย่อยในหมวดนั้น) แต่ละ item มี label
// (ข้อความที่แสดง), icon (ไอคอนของ Material Design Icons), แล้วมีได้ทั้ง
// to (เส้นทางภายในแอป ใช้กับ <NuxtLink>/<router-link>) หรือ href (ลิงก์
// ภายนอก/เปิดแท็บใหม่ เช่น API Docs) อย่างใดอย่างหนึ่ง
const MAP = {
  admin: [
    {
      label: 'MAIN',
      items: [
        { label: 'Dashboard', to: '/',              icon: 'mdi-view-dashboard-outline' },
        { label: 'Upload',    to: '/upload',        icon: 'mdi-tray-arrow-up' },
      ]
    },
    {
      label: 'MANAGEMENT',
      // หมวดเฉพาะของแอดมิน: จัดการผู้ใช้/รอบประเมิน/ตัวชี้วัด/การมอบหมายงาน
      // ฯลฯ — role อื่นจะไม่เห็นหมวดนี้เลย (ดูค่า MAP.evaluator/MAP.user
      // ด้านล่างที่ไม่มีหมวดนี้)
      items: [
        { label: 'Users',         to: '/users',            icon: 'mdi-account-cog-outline' },
        { label: 'Periods',       to: '/admin/periods',    icon: 'mdi-calendar-range' },
        { label: 'Topics',        to: '/admin/topics',     icon: 'mdi-format-list-bulleted' },
        { label: 'Assignments',   to: '/admin/assignments',icon: 'mdi-account-multiple-check' },
        { label: 'Monitor',       to: '/admin/monitor',    icon: 'mdi-progress-check' },
        { label: 'Reports',       to: '/reports',          icon: 'mdi-chart-areaspline' },
        { label: 'Settings',      to: '/settings',         icon: 'mdi-cog-outline' },
        { label: 'API Docs', apiDocs: true, target: '_blank', icon: 'mdi-book-open-outline' },
        // apiDocs: true คือ "flag พิเศษ" ไม่ใช่ field มาตรฐานของเมนูทั่วไป
        // (ที่ปกติมีแค่ to/href) — เหตุผลที่ไม่ใส่ href ตรง ๆ แบบ item อื่น
        // (เช่น href: 'http://localhost:7000/docs') เพราะ URL ของหน้า
        // Swagger ต้องเปลี่ยนไปตาม host ที่ผู้ใช้เปิดเว็บอยู่จริง (localhost,
        // 127.0.0.1, IP วง LAN, โดเมนจริง ฯลฯ) จึงต้องคำนวณ href แบบไดนามิก
        // ที่ฟังก์ชัน useMenu() ด้านล่าง (ดูคอมเมนต์ตรงนั้นประกอบ) แทนที่จะ
        // ฝัง URL คงที่ไว้ตรงนี้เหมือนเดิม
      ]
    }
  ],

  evaluator: [
    {
      label: 'MAIN',
      items: [
        { label: 'Dashboard', to: '/',       icon: 'mdi-view-dashboard-outline' },
        { label: 'Upload',    to: '/upload', icon: 'mdi-tray-arrow-up' },
      ]
    },
    {
      label: 'EVALUATION',
      items: [
        { label: 'Assigned Tasks',  to: '/eval/tasks',   icon: 'mdi-clipboard-check-outline' },
        { label: 'Scoring',         to: '/eval/scoring', icon: 'mdi-lead-pencil' },
        { label: 'Results',         to: '/eval/results', icon: 'mdi-file-check-outline' },
        { label: 'Users',           to: '/users',        icon: 'mdi-account-multiple-outline' },
        { label: 'API Docs', apiDocs: true, target: '_blank', icon: 'mdi-book-open-outline' },
      ]
    }
  ],

  user: [
    {
      label: 'MAIN',
      items: [
        { label: 'Dashboard', to: '/',           icon: 'mdi-view-dashboard-outline' },
        { label: 'Upload',    to: '/upload',     icon: 'mdi-tray-arrow-up' }, // ✅ บังคับมีแน่
      ]
    },
    {
      label: 'MY EVALUATION',
      items: [
        { label: 'Profile',         to: '/me',             icon: 'mdi-account' },
        { label: 'Indicators',      to: '/me/indicators',  icon: 'mdi-format-list-bulleted-square' },
        { label: 'Self Assessment', to: '/me/self-score',  icon: 'mdi-star-check-outline' },
        { label: 'Progress',        to: '/me/progress',    icon: 'mdi-progress-clock' },
        { label: 'Export',          to: '/me/export',      icon: 'mdi-tray-arrow-down' },
        { label: 'Feedback',        to: '/me/feedback',    icon: 'mdi-message-draw' },
        { label: 'API Docs', apiDocs: true, target: '_blank', icon: 'mdi-book-open-outline' },
      ]
    }
  ]
}

export function useMenu(roleInput = 'user') {
  // roleInput รับได้ทั้งค่าธรรมดา (string) หรือ ref/computed ของ Vue — ทำแบบ
  // นี้เพื่อให้ layout ส่ง role แบบ reactive เข้ามาได้ (เช่น
  // computed(() => auth.user?.role)) แล้วเมนูจะอัปเดตตามโดยอัตโนมัติทันทีที่
  // ค่า role เปลี่ยน (เช่น ตอน login/logout) โดยไม่ต้อง reload หน้าเว็บ
  const r = isRef(roleInput) ? roleInput : ref(roleInput)
  // isRef(...) เช็กว่า roleInput ที่ส่งเข้ามาเป็น ref ของ Vue อยู่แล้วไหม
  // ถ้าใช่ ใช้ตัวนั้นตรง ๆ ถ้าไม่ใช่ (เช่นส่ง string ธรรมดาเข้ามา) ให้ห่อด้วย
  // ref(...) ให้กลายเป็น reactive ให้เอง — ทำให้ฟังก์ชันนี้ใช้งานได้ทั้งสอง
  // แบบโดยโค้ดด้านล่างไม่ต้องสนใจว่าตอนเรียกมาเป็นแบบไหน

  // ให้เมนูปลอดภัยแม้ role ยังไม่พร้อม (ตอน hydrate แรก ๆ)
  const menu = computed(() => {
    // computed(...) คือค่าที่คำนวณใหม่อัตโนมัติทุกครั้งที่ dependency ของมัน
    // เปลี่ยน (ในที่นี้คือ r.value) — ผลลัพธ์ถูก cache ไว้ ไม่คำนวณซ้ำถ้า
    // dependency ไม่เปลี่ยน
    const key = normalizeRole(r.value)
    const sections = MAP[key] || MAP.user
    // MAP[key] ควรจะเจอเสมอเพราะ normalizeRole การันตีว่า key เป็นหนึ่งใน
    // 'admin'/'evaluator'/'user' แล้ว แต่ใส่ || MAP.user ไว้กันเหนียวอีกชั้น
    const apiDocsUrl = `${useApiBase()}/docs`
    // เติม href ของ API Docs ตาม host จริงที่เปิดหน้าเว็บ (เหมือน useApiBase)
    // useApiBase() คือ composable อีกตัวในโปรเจกต์นี้ (ดู
    // composables/useApiBase.js) ที่คำนวณ URL ของ backend แบบไดนามิกจาก
    // host ที่ browser ใช้เปิดหน้าเว็บอยู่ตอนนี้ — เอามาต่อ "/docs" (path ที่
    // app.js ฝั่ง backend เปิดหน้า Swagger UI ไว้) ได้ URL เต็มที่ใช้งานได้
    // จริงไม่ว่าจะเปิดแอปจาก host ไหนก็ตาม
    return sections.map(section => ({
      ...section,
      // spread (...section) คัดลอกทุก field เดิมของ section มาก่อน (label,
      // items เดิม) แล้วค่อย "เขียนทับ" เฉพาะ field ที่ต้องการเปลี่ยนด้านล่าง
      items: section.items.map(it => it.apiDocs ? { ...it, href: apiDocsUrl } : it)
      // ไล่ดูทุก item ในหมวดนั้น ถ้า item ไหนมี flag apiDocs: true (ที่ตั้ง
      // ไว้ใน MAP ด้านบน) ให้สร้าง object ใหม่ที่มีทุก field เดิม (...it)
      // บวก href ที่คำนวณสด ๆ เพิ่มเข้าไป ส่วน item อื่นที่ไม่มี flag นี้
      // (เมนูปกติที่มี to/href ของตัวเองอยู่แล้ว) ให้ปล่อยผ่านไปตามเดิม
      // ไม่แตะต้อง
    }))
  })

  return { menu }
  // คืนออกมาเป็น object ที่มี key ชื่อ menu (เป็น computed ref) — รูปแบบ
  // "คืน object ที่ห่อค่าไว้" แบบนี้เป็นธรรมเนียมมาตรฐานของ composable ใน
  // Vue 3 (เทียบกับการคืนค่าตรง ๆ) เพราะถ้าในอนาคตอยากเพิ่มค่าอื่นคืนออกไป
  // ด้วย (เช่นฟังก์ชันสำหรับ refresh เมนู) จะเพิ่มเข้ามาใน object นี้ได้ง่าย
  // โดยไม่กระทบโค้ดเดิมที่เรียกใช้ useMenu() อยู่แล้ว
}
