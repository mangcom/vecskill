// e2e/login.e2e.spec.ts
//
// ตัวอย่าง E2E test เทียบเท่า "E2E-001" ที่เกณฑ์การแข่งขันยกตัวอย่างไว้ (ดู
// เกณฑ์ข้อ 4.6: "มี E to E Test เป็นการทดสอบ Work flow ตั้งแต่เริ่มต้นจนจบ")
//
//   E2E-001: ผู้ใช้เข้าสู่ระบบสำเร็จ
//   ขั้นตอน:
//     1. เปิดหน้า Login
//     2. กรอก username/password
//     3. กดปุ่ม Login
//     4. ระบบพาไปหน้า Dashboard
//   ผลที่คาดหวัง: ผู้ใช้เข้าสู่ระบบได้ และเห็นหน้า Dashboard
//
// ต่างจาก tests/login.spec.ts (Vitest + @vue/test-utils) ตรงที่ไฟล์นั้น
// "mount" แค่ component เดียวใน jsdom (ไม่มีเบราว์เซอร์จริง ไม่มี backend
// จริง ต้อง mock ทุกอย่างเอง) ส่วนไฟล์นี้เปิด "เบราว์เซอร์ Chromium จริง" ไป
// ที่ frontend ที่รันอยู่จริง ซึ่งคุยกับ backend และฐานข้อมูลจริงทั้งหมด —
// เป็นการทดสอบ "ทั้งระบบทำงานร่วมกันถูกต้องไหม" ไม่ใช่แค่ component เดียว
//
// ก่อนรันไฟล์นี้ต้องมีสแตคทั้งหมดรันอยู่แล้ว (docker compose up -d — ดู README.md) พร้อมข้อมูล seed จาก schema.sql ครบ (ใช้บัญชี
// demo ที่ seed ไว้จริงด้านล่าง)

import { test, expect } from '@playwright/test'

test('E2E-001: ผู้ใช้เข้าสู่ระบบสำเร็จแล้วเห็นหน้า Dashboard', async ({ page }) => {
  // ขั้นตอน 1: เปิดหน้า Login
  await page.goto('/login')
  // page.goto('/login') ต่อกับ baseURL ที่ตั้งไว้ใน playwright.config.ts
  // (ค่าเริ่มต้น http://localhost:3000) ได้เป็น http://localhost:3000/login

  // ขั้นตอน 2: กรอก username/password
  // ใช้ page.getByLabel(...) หา input โดยอิง <label for="..."> ที่ผูกกับ
  // input จริง (Vuetify สร้าง label แบบนี้ให้อัตโนมัติ) — วิธีนี้ทนทานกว่า
  // การหาด้วย CSS class/id ที่ auto-generate เปลี่ยนไปมาได้ทุกครั้งที่ build
  // ใช้ .first() เสมอ เพราะ Vuetify คำนวณ accessible name ของ field พวกนี้
  // ซ้อนทับกับ element อื่นข้าง ๆ (เช่น ไอคอนรูปตาเปิด/ปิดของช่อง Password
  // ที่มี aria-label ขึ้นต้นด้วยคำว่า "Password" เหมือนกัน) getByLabel แบบ
  // ไม่ exact จะ match ได้มากกว่า 1 element เสมอ — องค์ประกอบจริงที่กรอกได้
  // (input) จะมาก่อนเสมอตามลำดับ DOM จึง .first() ได้ตัวที่ถูกต้องชัวร์
  await page.getByLabel('Email').first().fill('admin@vecskill.ovec')
  await page.getByLabel('Password').first().fill('12345678')
  // ใช้ account จริงที่ seed ไว้ใน schema.sql (ดู README.md หัวข้อ "Demo
  // login") — ไม่ได้ mock การ login เลย เพราะเป็น E2E test ต้องยิงไป backend
  // จริง ฐานข้อมูลจริง ถึงจะเรียกว่าทดสอบ "ทั้งระบบ" ได้จริง

  // ขั้นตอน 3: กดปุ่ม Login
  await page.getByRole('button', { name: 'Sign in' }).click()

  // ขั้นตอน 4 + ผลที่คาดหวัง: ระบบพาไปหน้า Dashboard (URL กลับไปที่ "/")
  // และเห็นเนื้อหาจริงของหน้า Dashboard (ตาราง Users) ไม่ใช่แค่ URL เปลี่ยน
  // เฉย ๆ — ต้องเห็น "เนื้อหา" จริงด้วยถึงจะมั่นใจว่า login สำเร็จจริง ๆ
  // (ถ้า login ล้มเหลว layouts/default.vue จะโชว์การ์ด "คุณยังไม่ได้เข้าสู่
  // ระบบ" แทน ซึ่งเป็นคนละข้อความกับที่เช็กด้านล่างนี้)
  await expect(page).toHaveURL(/\/$/)
  await expect(page.getByRole('button', { name: 'Logout' })).toBeVisible()
  // ปุ่ม "Logout" มีเฉพาะตอน auth.isLogged === true เท่านั้น (ดู
  // layouts/default.vue) — ถ้า login ล้มเหลว จะเห็นการ์ด "คุณยังไม่ได้เข้า
  // สู่ระบบ" แทน ไม่มีปุ่มนี้เลย
  await expect(page.getByText('admin@vecskill.ovec')).toBeVisible()
  // ยืนยันเพิ่มอีกชั้นว่าดึงข้อมูลจริงจาก backend/ฐานข้อมูลจริงมาแสดงได้
  // (เห็นอีเมลของผู้ใช้ที่ seed ไว้จริงในตาราง Users ของหน้า Dashboard) ไม่ใช่
  // อาศัยแค่ URL ตรงกันเฉย ๆ โดยเนื้อหาจริงยังไม่โหลด
})

test('E2E-001b (กรณีผิด): กรอกรหัสผ่านผิด ระบบต้องไม่พาเข้าสู่ระบบ', async ({ page }) => {
  // เทสต์เสริม (ไม่ใช่ข้อบังคับของเกณฑ์ แต่เป็นตัวอย่างที่ดีว่า E2E test ควร
  // ครอบคลุมทั้ง "กรณีสำเร็จ" และ "กรณีล้มเหลว" ไม่ใช่เช็กแค่ happy path
  // อย่างเดียว) — กรอกรหัสผ่านผิด แล้วต้องยังอยู่หน้า login พร้อมข้อความ
  // error ไม่ใช่หลุดเข้าระบบไปได้
  await page.goto('/login')
  await page.getByLabel('Email').first().fill('admin@vecskill.ovec')
  await page.getByLabel('Password').first().fill('wrong-password')
  await page.getByRole('button', { name: 'Sign in' }).click()

  await expect(page.getByText('Invalid credentials-password')).toBeVisible()
  // ข้อความนี้มาจาก backend/controllers/auth.controller.js ตรง ๆ (ดูไฟล์
  // นั้นประกอบ) — ยืนยันว่า error message จาก backend ถูกส่งต่อมาแสดงผลที่
  // หน้าเว็บจริง ไม่ใช่ error ทั่วไปที่ frontend เดาเอาเอง
  await expect(page).toHaveURL(/\/login$/)
  // ต้องยังอยู่หน้า /login เหมือนเดิม ไม่ถูกพาไปหน้า Dashboard
})
