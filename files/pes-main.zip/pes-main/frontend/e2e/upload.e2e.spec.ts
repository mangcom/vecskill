// e2e/upload.e2e.spec.ts
//
// ตัวอย่าง E2E test เทียบเท่า "E2E-002" ที่เกณฑ์การแข่งขันยกตัวอย่างไว้ (ดู
// เกณฑ์ข้อ 4.6) ปรับจากตัวอย่าง "ผู้ใช้ส่งข้อมูลสำเร็จ" ในเกณฑ์ ให้ตรงกับ
// ฟีเจอร์จริงของระบบนี้ (อัปโหลดไฟล์หลักฐานแทน "เพิ่มข้อมูลทั่วไป" เพราะเป็น
// ฟีเจอร์หลักของ template นี้ และมีข้อความ "สำเร็จ" แสดงผลจริงให้ตรวจสอบได้)
//
//   E2E-002: ผู้ใช้ส่งข้อมูล(อัปโหลดหลักฐาน)สำเร็จ
//   ขั้นตอน:
//     1. Login เข้าระบบ
//     2. เปิดหน้าเพิ่มข้อมูล (หน้า Upload)
//     3. กรอกข้อมูลในฟอร์ม (เลือกรอบประเมิน/ตัวชี้วัด/ชนิดหลักฐาน + แนบไฟล์)
//     4. กดปุ่มบันทึก (Upload)
//     5. ระบบแสดงข้อความสำเร็จ
//   ผลที่คาดหวัง: ข้อมูลถูกบันทึก และแสดงข้อความ "อัปโหลดสำเร็จ"
//
// ใช้ข้อมูล seed จริงจาก schema.sql: user "t.it01@vecskill.ovec" (role
// evaluatee) ถูก assign ไว้ในรอบประเมิน Y2568 (period_id=1) จริง และตัวชี้วัด
// แรก (T1-PLAN) จับคู่กับชนิดหลักฐานแรกไว้ถูกต้องแล้วในตาราง
// indicator_evidence — จึงเลือก "ตัวเลือกแรก" ของแต่ละ dropdown ได้เลยโดยไม่
// ต้องเจาะจงชื่อ (ทนทานกว่า ถ้ามีใครแก้ไขชื่อตัวชี้วัดใน schema.sql ภายหลัง
// เทสต์นี้จะยังผ่านอยู่ ตราบใดที่ตัวเลือกแรกยังจับคู่กันถูกต้อง)

import { test, expect } from '@playwright/test'

test('E2E-002: ผู้ใช้ login แล้วอัปโหลดไฟล์หลักฐานสำเร็จ', async ({ page }) => {
  // ขั้นตอน 1: Login เข้าระบบ (ใช้ evaluatee ไม่ใช่ admin เพราะหน้า Upload
  // ของ evaluatee จะอิง evaluatee_id จาก JWT ให้อัตโนมัติ ไม่ต้องเลือก
  // evaluatee_id เองเหมือนตอน login ด้วย role evaluator)
  await page.goto('/login')
  // ใช้ .first() เพราะ getByLabel('Password') match ได้มากกว่า 1 element
  // เสมอ (ชนกับ aria-label ของไอคอนรูปตาเปิด/ปิดรหัสผ่านข้าง ๆ ที่ขึ้นต้น
  // ด้วยคำว่า "Password" เหมือนกัน) — ดูคำอธิบายเต็ม ๆ ใน login.e2e.spec.ts
  await page.getByLabel('Email').first().fill('t.it01@vecskill.ovec')
  await page.getByLabel('Password').first().fill('12345678')
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page).toHaveURL(/\/$/)
  // ยืนยันว่า login ผ่านจริงก่อน ค่อยไปขั้นตอนถัดไป (ถ้า login ไม่ผ่าน
  // เทสต์นี้ควรพังตรงนี้ทันที ไม่ใช่ไปพังทีหลังด้วยสาเหตุที่สับสนกว่า)

  // ขั้นตอน 2: เปิดหน้า Upload
  await page.goto('/upload')
  await expect(page.getByText('Upload Evidence')).toBeVisible()

  // ขั้นตอน 3: กรอกข้อมูลในฟอร์ม
  // "รอบการประเมิน (Period)" ถูกเลือกให้อัตโนมัติอยู่แล้วตอนหน้าโหลดเสร็จ
  // (ดู function init() ใน pages/upload.vue) จึงไม่ต้องเลือกเอง — แต่
  // "ตัวชี้วัด" กับ "ชนิดหลักฐาน" ต้องเลือกเองเสมอ
  // เปิดเมนู dropdown ของ Vuetify (<v-select>) — ไม่ใช้ getByLabel/getByRole
  // จับคู่ด้วยชื่อ label เลย เพราะพบว่า Vuetify v-select คำนวณ accessible
  // name ของตัว combobox จริง ๆ ออกมาเป็นคำว่า "Open" เฉย ๆ (ไม่ใช่ข้อความ
  // label ที่เห็นบนจอ) ส่วน aria-label ของปุ่ม "ล้างค่า" (clear) ข้าง ๆ ก็ดัน
  // มีข้อความ label เดิมปนอยู่ด้วย (เช่น "Clear ตัวชี้วัด (Indicator)") ทำให้
  // getByLabel แบบ substring จับผิดตัวได้ง่ายมาก (ลองมาแล้วจริงระหว่างเขียน
  // เทสต์นี้) — วิธีที่ชัวร์กว่าคือหา .v-field (กรอบของ field ทั้งก้อน) ที่
  // "มีข้อความ label นี้อยู่ข้างใน" แล้วคลิกที่กรอบนั้นตรง ๆ แทน
  await page.locator('.v-field', { hasText: 'ตัวชี้วัด (Indicator)' }).click()
  await page.getByRole('option').first().click()
  // เลือกตัวเลือกแรกในเมนูที่เปิดอยู่ (role="option" ซ้อนอยู่ใน
  // role="listbox" ที่ Vuetify สร้างเป็น overlay ลอยขึ้นมา — ส่วนนี้ชื่อ role
  // ถูกต้องตรงไปตรงมาดี ไม่มีปัญหาแบบ combobox ด้านบน)

  await page.locator('.v-field', { hasText: 'ชนิดหลักฐาน (Evidence Type)' }).click()
  // ตอนนี้ field นี้ enable แล้ว เพราะเลือกตัวชี้วัดไปแล้วในขั้นก่อนหน้า
  // (ดู :disabled="!form.indicator_id" ใน pages/upload.vue)
  await page.getByRole('option').first().click()

  // แนบไฟล์ — สร้างไฟล์ปลอมขึ้นมาในหน่วยความจำตรง ๆ (ไม่ต้องมีไฟล์จริงบน
  // ดิสก์) ด้วย buffer ของรูปภาพ PNG เล็ก ๆ ให้ตรงกับชนิดไฟล์ที่ backend
  // อนุญาต (ดู middlewares/upload.js: ALLOWED mimetypes)
  await page.locator('input[type="file"]').setInputFiles({
    name: 'e2e-evidence.png',
    mimeType: 'image/png',
    buffer: Buffer.from(
      // PNG เปล่า ๆ ขนาด 1x1 พิกเซล แบบ base64 — เล็กที่สุดเท่าที่จะเป็น
      // ไฟล์ PNG ที่ถูกต้องตามรูปแบบได้ (ไม่ต้องมีเนื้อหาภาพจริงจัง แค่ให้
      // ผ่านการตรวจ MIME type ของระบบ)
      'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
      'base64'
    ),
  })

  // ขั้นตอน 4: กดปุ่มบันทึก (Upload)
  // ดัก response ของ POST /api/attachments ไว้ด้วย (ไม่ใช่แค่คลิกปุ่มเฉย ๆ)
  // เพื่อเอา id ของแถวที่เพิ่งสร้างไปลบทิ้งหลังเทสต์จบ (ดูด้านล่าง) — ไม่งั้น
  // ทุกครั้งที่รันเทสต์นี้จะมีไฟล์/record ค้างเพิ่มขึ้นเรื่อย ๆ ในฐานข้อมูล
  // dev จริง ซึ่งไม่ควรเกิดกับเทสต์ที่ดี (เทสต์ควรรันซ้ำกี่ครั้งก็ได้ผลเหมือน
  // เดิมเสมอ ไม่ทิ้งขยะสะสมไว้)
  const [uploadResponse] = await Promise.all([
    page.waitForResponse((res) => res.url().includes('/api/attachments') && res.request().method() === 'POST'),
    page.getByRole('button', { name: 'Upload', exact: true }).click(),
  ])
  const uploadResult = await uploadResponse.json()

  // ขั้นตอน 5 + ผลที่คาดหวัง: ระบบแสดงข้อความสำเร็จ
  await expect(page.getByText('อัปโหลดสำเร็จ')).toBeVisible()
  // ข้อความนี้มาจาก successMsg.value ใน pages/upload.vue หลังจากเรียก
  // POST /api/attachments สำเร็จ (ดู backend/routes/attachments.js) —
  // ถ้าอัปโหลดจริงไม่สำเร็จ (เช่น mapping indicator/evidence_type ไม่ถูก
  // ต้อง หรือ period ปิดไปแล้ว) ข้อความนี้จะไม่ปรากฏ แล้วเทสต์นี้จะ fail
  // ทันที — พิสูจน์ว่าทั้ง frontend + backend + ฐานข้อมูลทำงานร่วมกันถูกต้อง
  // จริง ๆ ตลอดทั้ง workflow ไม่ใช่แค่ส่วนใดส่วนหนึ่ง

  // เก็บกวาด: ลบไฟล์หลักฐานที่เพิ่งสร้างไว้ทิ้ง ผ่าน endpoint จริงของระบบ
  // (DELETE /api/upload/:id — ดู backend/routes/upload.routes.js) เรียกผ่าน
  // page.evaluate ให้ fetch ทำงาน "ในบริบทของเบราว์เซอร์" ที่ login อยู่แล้ว
  // จะได้หยิบ token จาก localStorage มาแนบให้เองโดยไม่ต้องส่งต่อ token มาเอง
  await page.evaluate(async (id) => {
    const token = localStorage.getItem('auth_token')
    await fetch(`${location.protocol}//${location.hostname}:7000/api/upload/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    })
  }, uploadResult.id)
})
