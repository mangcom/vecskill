<!-- error.vue -->
<!-- หน้า error กลางของแอป: 404 (เส้นทางที่ยังไม่มีหน้าจริง) ให้แสดงเป็น
     "กำลังพัฒนา" แทนคำว่า "Page not found" ที่ดูเหมือนแอปพัง -->
<script setup>
const props = defineProps({ error: Object })

const isNotFound = computed(() => Number(props.error?.statusCode) === 404)

function goHome() {
  clearError({ redirect: '/' })
}
</script>

<template>
  <v-app>
    <v-main>
      <v-container class="d-flex align-center justify-center" style="min-height: 100vh">
        <v-card max-width="460" class="w-100 text-center pa-4">
          <template v-if="isNotFound">
            <v-icon icon="mdi-wrench-clock-outline" size="56" color="primary" class="mb-2" />
            <v-card-title class="justify-center">กำลังพัฒนา</v-card-title>
            <v-card-text>
              หน้านี้ยังไม่พร้อมใช้งานในขณะนี้ ทีมงานกำลังพัฒนาเพิ่มเติม
              <br />กรุณากลับมาใหม่อีกครั้งในโอกาสหน้า
            </v-card-text>
          </template>
          <template v-else>
            <v-icon icon="mdi-alert-circle-outline" size="56" color="error" class="mb-2" />
            <v-card-title class="justify-center">เกิดข้อผิดพลาด</v-card-title>
            <v-card-text>
              {{ error?.statusCode }} — {{ error?.message || 'Something went wrong' }}
            </v-card-text>
          </template>
          <v-card-actions class="justify-center">
            <v-btn color="primary" variant="elevated" @click="goHome">กลับหน้าหลัก</v-btn>
          </v-card-actions>
        </v-card>
      </v-container>
    </v-main>
  </v-app>
</template>
