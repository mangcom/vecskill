<!--
  layouts/auth-login.vue

  Layout เฉพาะสำหรับหน้า login (ดู pages/login.vue ที่ประกาศ
  definePageMeta({ layout: 'auth-login' }) ไว้ถึงจะมาใช้ layout นี้) —
  ต่างจาก layouts/default.vue และ layouts/dashboard.vue ตรงที่ไฟล์นี้ "ไม่มี"
  app bar หรือเมนูด้านข้างเลย เพราะหน้า login ยังไม่มีใคร login อยู่ ไม่มี
  role ให้โชว์เมนูตาม role ได้ (และยังไม่ควรให้เห็นเมนูเหล่านั้นด้วย)
  เป็นแค่กรอบการ์ดกลางจอง่าย ๆ ให้ฟอร์ม login มาแสดงอยู่ข้างใน
-->
<template>
  <v-app>
    <!-- <v-app> คือ component รากของ Vuetify — ทุกหน้าที่ใช้ Vuetify
         component (เช่น <v-main>, <v-card>) ต้องอยู่ภายใน <v-app> เสมอ
         ไม่งั้น Vuetify จะทำงานผิดเพี้ยน (จุดนี้คือเหตุผลที่ทุก layout ใน
         โปรเจกต์นี้มี <v-app> ครอบอยู่ชั้นนอกสุดเหมือนกันหมด) -->
    <v-main>
      <v-container class="d-flex align-center justify-center" style="min-height: 100vh">
        <!-- min-height: 100vh ทำให้ container สูงเต็มจอเสมอ (100% ของ
             viewport height) แล้วใช้ d-flex + align-center + justify-center
             (utility class ของ Vuetify) จัดการ์ดให้อยู่กึ่งกลางจอพอดีทั้ง
             แนวตั้งแนวนอน ไม่ว่าจอจะสูง/กว้างแค่ไหนก็ตาม -->
        <v-card max-width="420" class="w-100">
          <!-- max-width จำกัดไม่ให้การ์ดกว้างเกินไปบนจอใหญ่ (420px กำลังดี
               สำหรับฟอร์ม login) ส่วน w-100 (width: 100%) ทำให้บนจอเล็ก
               (มือถือ) การ์ดขยายเต็มความกว้างที่มีได้ (ไม่แคบจนเกินไป) -->
          <v-card-title class="text-h6 text-center">Personnel evaluation system</v-card-title>
          <v-card-text>
            <slot /> <!-- ฟอร์ม login ของเพจ -->
            <!-- <slot /> คือจุดที่เนื้อหาจริงของหน้า (เช่น ฟอร์ม input
                 email/password ของ pages/login.vue) จะถูกสอดเข้ามาแสดง —
                 layout ไฟล์นี้แค่เตรียม "กรอบ" ไว้ให้ ไม่รู้และไม่สนใจว่า
                 ข้างในจะมีอะไรบ้าง -->
          </v-card-text>
        </v-card>
      </v-container>
    </v-main>
  </v-app>
</template>
