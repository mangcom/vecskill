<!-- layouts/dashboard.vue -->
<!--
  Layout ที่สองของแอป (นอกจาก default.vue) — ใช้กับหน้าที่ประกาศ
  definePageMeta({ layout: 'dashboard' }) ไว้ (เช่น pages/upload.vue,
  pages/me/*.vue) หน้าตา/โครงสร้างคล้าย default.vue มาก (มี app bar + เมนู
  ซ้ายจาก useMenu เหมือนกัน) แต่มีของเพิ่มที่ default.vue ไม่มี: ปุ่มสลับ
  โหมดมืด/สว่าง (dark/light theme) และเมนูโปรไฟล์ผู้ใช้ที่กดแล้วเห็น
  ชื่อ/อีเมล + ปุ่ม Logout ได้จริง

  หมายเหตุ: ต่างจาก default.vue ตรงที่ไฟล์นี้ "ไม่ได้" เช็ก auth.isLogged
  ก่อนแสดงผล (ไม่มีการ์ด "คุณยังไม่ได้เข้าสู่ระบบ" เหมือน default.vue) — ถ้า
  จะใช้ layout นี้กับหน้าใหม่ ควรพึ่งพาการที่ route นั้นถูกป้องกันด้วยทางอื่น
  อยู่แล้ว (เช่นตรวจสอบ auth.isLogged เองในหน้านั้น หรือผ่าน middleware)
-->
<template>
  <v-app>
    <!-- Drawer -->
    <v-navigation-drawer
      v-model="drawer"
      :permanent="!smAndDown"
      :temporary="smAndDown"
      app
    >
      <!-- :permanent="!smAndDown" / :temporary="smAndDown" คือการสลับ
           พฤติกรรมของ drawer ตามขนาดจอ: smAndDown (จาก useDisplay() ของ
           Vuetify) เป็น true บนจอเล็ก (มือถือ/แท็บเล็ต) — ตอนนั้น drawer
           จะเป็นแบบ "temporary" (ลอยทับเนื้อหา ปิดเองเมื่อคลิกข้างนอก)
           ส่วนจอใหญ่ (desktop) drawer จะเป็นแบบ "permanent" (แสดงค้างอยู่
           ข้าง ๆ เนื้อหาเสมอ ไม่ปิดเอง) -->
      <v-list density="compact" nav>
        <template v-for="sec in menu" :key="sec.label">
          <v-list-subheader class="text-uppercase text-caption">{{ sec.label }}</v-list-subheader>

          <template v-for="it in sec.items" :key="it.to || it.href">
            <!-- ต่างจาก default.vue ที่ใช้ <v-list-item :to="..." :href="..."/>
                 ตัวเดียวแล้วปล่อยให้ Vuetify เลือก tag ที่ถูกต้องเอง ไฟล์นี้
                 เขียนแยกเป็น 2 กรณีชัดเจนด้วย v-if/v-else (ทั้งสองวิธีได้
                 ผลลัพธ์คล้ายกัน แต่วิธีนี้ควบคุม class ที่ active ได้ตรงกว่า
                 — ดู exact-active-class ด้านล่าง) -->
            <NuxtLink
              v-if="it.to"
              :to="it.to"
              class="no-underline"
              exact-active-class="bg-primary text-white rounded-lg"
            >
              <!-- it.to มีค่า = เมนูนี้เป็นลิงก์ภายในแอป ใช้ <NuxtLink> ให้
                   นำทางแบบ SPA (ไม่โหลดหน้าใหม่ทั้งหน้า) -->
              <!-- exact-active-class คือ class พิเศษที่ Vue Router จะเติมให้
                   อัตโนมัติเฉพาะตอน URL ปัจจุบัน "ตรงกับ to เป๊ะ ๆ" เท่านั้น
                   (ไม่ใช่แค่ขึ้นต้นด้วย) ใช้ไฮไลต์เมนูที่กำลังเปิดอยู่ให้เห็น
                   ชัดเจนว่า "ตอนนี้อยู่หน้าไหน" -->
              <v-list-item :title="it.label" :active="route.path.startsWith(it.to)">
                <!-- :active ควบคุมเองอีกชั้นด้วย route.path.startsWith(it.to)
                     (ไม่ใช่ exact match แบบ exact-active-class ด้านบน) เพื่อ
                     ให้เมนูแม่ยังถูกไฮไลต์อยู่แม้ URL จะลึกกว่า to ของมันก็
                     ตาม เช่น it.to = '/me' ควรไฮไลต์ตอนอยู่ที่ /me/export
                     ด้วย ไม่ใช่แค่ /me เป๊ะ ๆ เท่านั้น -->
                <template #prepend>
                  <v-icon :icon="it.icon || 'mdi-circle-small'" />
                  <!-- ถ้าเมนูไม่ได้กำหนด icon ไว้ ใช้จุดกลม ๆ เล็ก ๆ แทน
                       (กันไอคอนหายไปเฉย ๆ จนเมนูดูเยื้องไม่ตรงแถวกัน) -->
                </template>
              </v-list-item>
            </NuxtLink>

            <a v-else :href="it.href" :target="it.target || '_blank'" class="no-underline">
              <!-- ไม่มี it.to เลย = ต้องเป็นลิงก์ภายนอก (เช่น API Docs) ใช้
                   <a> ธรรมดา เปิดแท็บใหม่เป็นค่าเริ่มต้นถ้าไม่ได้ระบุ target
                   ไว้ (กันผู้ใช้เผลอกดแล้วหลุดออกจากแอปไปเลย) -->
              <v-list-item :title="it.label">
                <template #prepend>
                  <v-icon :icon="it.icon || 'mdi-circle-small'" />
                </template>
              </v-list-item>
            </a>
          </template>

          <v-divider class="my-2" />
        </template>
      </v-list>
    </v-navigation-drawer>

    <!-- App Bar -->
    <v-app-bar app flat>
      <v-app-bar-nav-icon @click="drawer = !drawer" aria-label="Toggle menu" />
      <v-toolbar-title class="font-semibold">Personnel evaluation system</v-toolbar-title>

      <v-spacer />

      <v-btn icon @click="toggleTheme" :aria-label="`Switch to ${themeName === 'dark' ? 'light':'dark'} theme`">
        <v-icon>mdi-theme-light-dark</v-icon>
      </v-btn>
      <!-- ปุ่มสลับธีมมืด/สว่าง — aria-label เปลี่ยนข้อความตามธีมปัจจุบัน
           (ถ้าตอนนี้เป็น dark จะบอกว่า "Switch to light theme" และกลับกัน)
           เพื่อให้ screen reader อ่านออกมาได้ถูกต้องว่ากดแล้วจะเกิดอะไรขึ้น -->

      <!-- Profile -->
      <!-- Profile -->
<v-menu>
  <template #activator="{ props }">
    <v-btn v-bind="props" icon>
      <!-- v-bind="props" คือการส่ง attribute/event handler ที่ <v-menu>
           เตรียมให้ (เช่น @click เปิดเมนู) ไปติดกับปุ่มนี้โดยอัตโนมัติ —
           เป็นรูปแบบมาตรฐานของ Vuetify สำหรับทำ "ปุ่มที่กดแล้วเปิดเมนูลอย" -->
      <v-avatar size="36">
        <!-- ✅ แสดงรูปจริง ถ้ามี -->
        <v-img
          v-if="auth.user?.avatar_url"
          :src="auth.user.avatar_url"
          alt="User avatar"
          cover
        />
        <!-- 🧩 fallback ถ้าไม่มีรูป -->
        <span
          v-else
          class="font-semibold text-white bg-primary w-full h-full flex items-center justify-center"
        >
          {{ initials }}
        </span>
        <!-- ถ้าผู้ใช้ไม่มีรูปโปรไฟล์ (avatar_url) ให้แสดงตัวอักษรย่อของชื่อ
             แทน (ดูการคำนวณ initials ด้านล่างใน <script>) พื้นหลังสีหลัก
             ของธีม ตัวหนังสือสีขาว ดูเป็นวงกลม avatar เหมือนแอปทั่วไป -->
      </v-avatar>
    </v-btn>
  </template>

  <v-list>
    <v-list-item
      :title="auth.user?.name || 'ไม่ระบุชื่อ'"
      :subtitle="auth.user?.email || '-'"
      prepend-icon="mdi-account"
    />
    <!-- แถวแรกของเมนู: ไม่ใช่ลิงก์ให้กดอะไร แค่แสดงชื่อ+อีเมลของผู้ใช้ที่
         login อยู่ตอนนี้ (title/subtitle) เป็นการยืนยันตัวตนให้ผู้ใช้เห็น
         ชัดเจนว่ากำลัง login ด้วยบัญชีไหนอยู่ -->
    <v-divider class="my-2" />
    <NuxtLink to="/me" class="no-underline">
      <v-list-item title="Profile" prepend-icon="mdi-account-cog-outline" />
    </NuxtLink>
    <v-list-item title="Logout" prepend-icon="mdi-logout" @click="logout" />
  </v-list>
</v-menu>

    </v-app-bar>

    <!-- Content -->
    <v-main>
      <!-- แก้ไข: เดิมมี class="bg-gray-50" (Tailwind) ติดอยู่ตรงนี้ ซึ่งเป็น
           สีเทาอ่อนคงที่ ไม่เปลี่ยนตามธีม — ทำให้ตอนสลับเป็นโหมดมืด มีแค่
           app bar กับเมนูซ้าย (ที่ใช้สีจากธีมของ Vuetify) เปลี่ยนเป็นสีเข้ม
           แต่พื้นที่เนื้อหาหลักยังเป็นสีเทาอ่อนเดิมอยู่ดี (ตามที่เห็นในภาพ
           หน้าจอตอนแจ้งปัญหา) เอา class นี้ออก แล้วปล่อยให้ <v-main> ใช้สี
           พื้นหลังตามธีมปัจจุบันของ Vuetify เอง (ดู background ที่กำหนดไว้ใน
           plugins/vuetify.ts ทั้งสองธีม) จะได้เปลี่ยนสีพร้อมกันทั้งหน้าจริง -->
      <div class="p-4 lg:p-6">
        <slot />
      </div>
    </v-main>

    <v-footer app class="text-caption justify-center">
      © {{ year }} VEC Skills
    </v-footer>
  </v-app>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { useDisplay } from 'vuetify'
// useDisplay() ให้ข้อมูล breakpoint ปัจจุบันของจอ (เช่น smAndDown)
import { useAuthStore } from '~/stores/auth'
import { useMenu } from '~/composables/useMenu'
import { useAppTheme } from '~/composables/useAppTheme'

const route = useRoute()
// useRoute() คือ composable มาตรฐานของ Vue Router/Nuxt ให้ข้อมูล route
// ปัจจุบัน (route.path คือ URL path ตอนนี้) ใช้เช็กว่าเมนูไหนควรไฮไลต์อยู่
const { smAndDown } = useDisplay()

// Drawer responsive
const drawer = ref(!smAndDown.value)
// เริ่มต้น: ถ้าจอใหญ่ (ไม่ใช่ smAndDown) ให้เปิด drawer ไว้ก่อนเลย ถ้าจอเล็ก
// ให้ปิดไว้ก่อน (ไม่บังจอทั้งหมดตั้งแต่เปิดมา)
watch(smAndDown, v => { drawer.value = !v })
// watch(...) คอยดูว่าขนาดจอเปลี่ยนไปมา (เช่นหมุนจอมือถือ หรือย่อ/ขยาย
// หน้าต่างเบราว์เซอร์) ถ้าเปลี่ยนจากจอใหญ่เป็นจอเล็ก (v = true) ให้ปิด
// drawer อัตโนมัติ ถ้าเปลี่ยนกลับเป็นจอใหญ่ (v = false) ให้เปิดกลับมา

// Auth + role
const auth = useAuthStore()
const role = computed(() => auth?.user?.role ?? 'user')

// ✅ ดึงชื่อย่อ (initials) สำหรับ fallback avatar
const initials = computed(() => {
  if (!auth?.user?.name) return '?'
  const parts = auth.user.name.trim().split(' ')
  // แยกชื่อเต็มด้วยช่องว่าง เช่น "ครูไอที 01" -> ["ครูไอที", "01"]
  if (parts.length === 1) return parts[0][0]?.toUpperCase() || '?'
  // ถ้ามีคำเดียว (ไม่มีช่องว่างเลย) ใช้แค่ตัวอักษรแรกตัวเดียว
  return (parts[0][0] + parts[1][0]).toUpperCase()
  // ถ้ามีหลายคำ ใช้ตัวอักษรแรกของคำแรก + ตัวอักษรแรกของคำที่สอง (เหมือน
  // การย่อชื่อ-นามสกุลภาษาอังกฤษทั่วไป เช่น "John Doe" -> "JD")
})

// เมนูตาม role (ส่ง ref/computed เข้าไป)
const { menu } = useMenu(role)

// Theme — logic จริงอยู่ที่ composables/useAppTheme.js (ใช้ร่วมกับ
// layouts/default.vue ด้วย ไม่ให้แต่ละ layout เขียนแยกกันเองจนไม่ตรงกัน)
const { themeName, toggleTheme, initTheme } = useAppTheme()
onMounted(initTheme)
// กู้คืนธีมที่เคยเลือกไว้จาก localStorage ตอน component นี้ mount เสร็จ —
// initTheme() ข้างในมีกันไว้แล้วว่าจะทำงานแค่ครั้งเดียวจริงต่อการโหลดแอป
// (เผื่อ layouts/default.vue mount ไปแล้วก่อนหน้านี้ในเซสชันเดียวกัน)

// Footer year
const year = new Date().getFullYear()
// คำนวณปีปัจจุบันครั้งเดียวตอนโหลด component (ไม่ต้องเป็น reactive เพราะปี
// ไม่เปลี่ยนระหว่างที่หน้าเว็บเปิดอยู่)

// Logout
function logout () {
  try { auth.logout() } catch {}
  // เรียก auth.logout() (ดู stores/auth.js) ล้าง token/ข้อมูลผู้ใช้ออกจาก
  // store + localStorage — ครอบด้วย try/catch กันเหนียวเผื่อ error ไม่
  // คาดคิดระหว่างล้างข้อมูล ไม่อยากให้ปุ่ม logout พังจนกดไม่ได้เลย
  navigateTo('/login')
  // พาไปหน้า login ทันทีหลัง logout (ต่างจากตอนยังไม่เคย login เลยที่ไม่
  // force redirect — เคสนี้คือ "เพิ่งกด logout เอง" จึงสมเหตุสมผลที่จะพาไป
  // หน้า login ต่อทันที)
}
</script>

<style scoped>
.no-underline { text-decoration: none; color: inherit; }
/* เอาเส้นใต้ของลิงก์ (<a>/<NuxtLink>) ออก และให้สีตัวหนังสือสืบทอดจาก
   element แม่แทนสีลิงก์ default ของเบราว์เซอร์ (ปกติจะเป็นสีฟ้ามีขีดเส้นใต้) */
.v-avatar span {
  font-size: 0.9rem;
  text-transform: uppercase;
}
/* ปรับขนาดตัวอักษรย่อ (initials) ใน avatar ให้พอดีกับวงกลมขนาด 36px และ
   บังคับให้เป็นตัวพิมพ์ใหญ่เสมอ (เผื่อ initials คำนวณออกมาเป็นตัวเล็ก) */

</style>
<!-- layouts/dashboard.vue -->
