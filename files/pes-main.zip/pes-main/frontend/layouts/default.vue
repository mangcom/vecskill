<!--
  layouts/default.vue

  Layout เริ่มต้นของแอป — หน้าไหนที่ไม่ได้ระบุ layout เองไว้ชัดเจน (ด้วย
  definePageMeta({ layout: '...' })) จะมาใช้ไฟล์นี้โดยอัตโนมัติ (ดู
  pages/index.vue ที่ตั้ง layout: 'default' ไว้ตรง ๆ ด้วยเช่นกัน)

  หน้าที่หลักของไฟล์นี้: แสดงแถบเมนูด้านบน (app bar) + เมนูด้านซ้าย
  (navigation drawer ที่เนื้อหาตาม role มาจาก composables/useMenu.js) "เมื่อ
  ล็อกอินอยู่เท่านั้น" — ถ้ายังไม่ได้ login จะโชว์การ์ดข้อความแจ้งเตือนแทน
  เนื้อหาจริงทั้งหมด (ดูคำอธิบายเหตุผลด้านล่างที่ v-else)
-->
<script setup>
import { ref, computed, onMounted } from 'vue'
import { useMenu } from '~/composables/useMenu'  // มีอยู่แล้วในโปรเจกต์ครู
import { useAuthStore } from '~/stores/auth'
import { useAppTheme } from '~/composables/useAppTheme'
const auth = useAuthStore()
// auth คือ Pinia store ที่เก็บสถานะ login (ดู stores/auth.js) — เรียกใช้ที่
// นี่เพื่อเช็กทั้ง auth.isLogged (login อยู่ไหม) และ auth.user?.role (role
// อะไร) มาตัดสินใจว่าจะแสดงเมนูแบบไหน

const role = computed(() => auth.user?.role ?? 'user') // 'admin' | 'evaluator' | 'user'
// ต้องเป็น computed (ไม่ใช่อ่านค่าตรง ๆ ครั้งเดียว) เพื่อให้ role อัปเดตตาม
// auth.user โดยอัตโนมัติทุกครั้งที่ login/logout — ถ้าใช้ตัวแปรธรรมดาแทน
// เมนูจะค้างอยู่กับ role เดิมตั้งแต่ตอนโหลดหน้าครั้งแรก ไม่ว่าจะ
// login/logout กี่รอบก็ตาม (จุดนี้เคยเป็นบั๊กของเวอร์ชันเก่าของไฟล์นี้ ที่
// เขียน const role = ref('user') ไว้ตรง ๆ แบบไม่อิงจาก auth store เลย ทำให้
// ไม่ว่า login ด้วย role ไหนก็เห็นแต่เมนูของ 'user' เสมอ — แก้โดยเปลี่ยนมา
// อ่านจาก auth.user?.role จริงแบบ computed แทน)
// ?? 'user' (nullish coalescing) คือ fallback ไปใช้ 'user' เฉพาะตอน
// auth.user?.role เป็น null/undefined เท่านั้น (เช่นตอนยังโหลดข้อมูล user
// ไม่เสร็จ) ต่างจาก || ตรงที่ ?? จะไม่ fallback ถ้าค่าเป็น 0 หรือ "" (ไม่มี
// ผลต่างในกรณีนี้เพราะ role ไม่มีทางเป็น 0/"" แต่เป็นธรรมเนียมที่ดีกว่า)
const { menu } = useMenu(role)                   // จะคืนเมนูตามบทบาทให้อัตโนมัติ :contentReference[oaicite:5]{index=5}
// ส่ง role (เป็น computed ref) เข้าไปใน useMenu — เพราะเป็น ref ที่ reactive
// เมนูที่ได้กลับมาจะเปลี่ยนตาม role โดยอัตโนมัติ ไม่ต้อง re-mount component
const drawer = ref(true)
// สถานะเปิด/ปิดเมนูด้านซ้าย (navigation drawer) — เริ่มต้นเปิดไว้ก่อนเสมอ

// Theme — ใช้ composable ร่วมกับ layouts/dashboard.vue (ดู
// composables/useAppTheme.js) แก้ไข: เดิม layout นี้ไม่มีปุ่มสลับธีมที่ใช้
// งานได้จริงเลย มีแต่ลิงก์ "Theme" ที่ชี้ไปหน้า /theme ซึ่งไม่มีอยู่จริง (เจอ
// หน้า "กำลังพัฒนา") ทำให้สลับธีมได้ไม่สม่ำเสมอกันทั้งระบบ (หน้าที่ใช้
// layout นี้ เช่น Dashboard หน้าแรก สลับธีมไม่ได้เลย ต้องไปหน้าอื่นที่ใช้
// layouts/dashboard.vue ถึงจะสลับได้)
const { themeName, toggleTheme, initTheme } = useAppTheme()
onMounted(initTheme)
</script>

<template>
  <v-app>
    <template v-if="auth.isLogged">
      <!-- เนื้อหาในกลุ่ม template นี้ทั้งหมดจะแสดงเฉพาะตอน login อยู่
           เท่านั้น (auth.isLogged === true) -->
      <v-app-bar color="surface" flat>
        <v-app-bar-nav-icon @click="drawer = !drawer" />
        <!-- ปุ่ม hamburger menu มุมซ้ายบน กดแล้วสลับเปิด/ปิด drawer
             (toggle ค่า drawer ไปมาระหว่าง true/false) -->
        <v-toolbar-title>Personnel evaluation system</v-toolbar-title>
        <v-spacer />
        <!-- <v-spacer /> ดันทุกอย่างที่อยู่หลังจากนี้ไปชิดขวาสุดของแถบ
             (ใช้พื้นที่ว่างที่เหลือทั้งหมดไปเป็นช่องว่างตรงนี้แทน) -->
        <v-btn icon @click="toggleTheme" :aria-label="`Switch to ${themeName === 'dark' ? 'light' : 'dark'} theme`" class="mr-2">
          <v-icon>mdi-theme-light-dark</v-icon>
        </v-btn>
        <!-- ปุ่มสลับธีมมืด/สว่างตัวจริง (เดิมตรงนี้เป็นแค่ <NuxtLink
             to="/theme">Theme</NuxtLink> ที่ชี้ไปหน้าที่ไม่มีอยู่จริง กดแล้ว
             เจอหน้า "กำลังพัฒนา" เฉย ๆ ไม่ได้สลับธีมอะไรเลย) ใช้
             useAppTheme() ตัวเดียวกับที่ layouts/dashboard.vue ใช้ ทำให้สลับ
             ธีมจากหน้าไหนก็ได้ผลเหมือนกันทั้งระบบ ไม่ใช่สลับได้แค่บางหน้า -->
        <!-- โปรไฟล์ -->
        <v-btn icon="mdi-account-circle" variant="text" />
        <!-- หมายเหตุ: ปุ่มนี้ยังไม่ได้ผูก @click ไว้ (กดแล้วไม่มีอะไรเกิดขึ้น)
             — เทียบกับ layouts/dashboard.vue ที่ทำเมนูโปรไฟล์ (คลิกแล้วเห็น
             ชื่อ/อีเมล + ปุ่ม Logout) ไว้สมบูรณ์กว่า ถ้าจะต่อยอด layout นี้
             ให้ทำแบบเดียวกันได้ -->
      </v-app-bar>

      <v-navigation-drawer v-model="drawer" width="260">
        <v-list density="comfortable" nav>
          <template v-for="(section, i) in menu" :key="i">
            <!-- menu คือ array ของหมวดหมู่ (ดูโครงสร้างเต็ม ๆ ใน
                 composables/useMenu.js) วนลูปทีละหมวด -->
            <v-list-subheader class="text-caption">{{ section.label }}</v-list-subheader>
            <!-- หัวข้อของแต่ละหมวด เช่น "MAIN", "MANAGEMENT" -->
            <v-list-item
              v-for="(it, j) in section.items"
              :key="j"
              :to="it.to"
              :href="it.href"
              :target="it.target"
              :prepend-icon="it.icon"
              :title="it.label"
              :value="it.to || it.href"
            />
            <!-- วนลูปทีละเมนูย่อยในหมวดนั้น — <v-list-item> ของ Vuetify ฉลาด
                 พอที่จะรู้เองว่าถ้ามี :to ให้ render เป็น <router-link>
                 (นำทางภายในแอปแบบ SPA ไม่โหลดหน้าใหม่) แต่ถ้ามี :href แทน
                 ให้ render เป็น <a> ธรรมดา (ลิงก์ภายนอก เช่น API Docs ที่
                 ต้องเปิดแท็บใหม่ตาม :target="_blank") รายการที่ไม่มี :to
                 เลยจะได้ค่า undefined ซึ่ง Vuetify จัดการให้ไม่ error -->
            <v-divider class="my-2" />
            <!-- เส้นคั่นระหว่างแต่ละหมวด -->
          </template>
        </v-list>
      </v-navigation-drawer>

      <v-main>
        <v-container fluid class="py-6">
          <slot />
          <!-- เนื้อหาจริงของแต่ละหน้า (เช่น pages/index.vue) ถูกสอดเข้ามา
               ตรงนี้ -->
        </v-container>
        <v-footer app class="text-caption justify-center">© 2025 VEC Skills</v-footer>
      </v-main>
    </template>

    <!-- ยังไม่ได้ login: โชว์ข้อความแจ้งเตือนแทนเนื้อหาจริง ไม่เด้งหน้าทันที -->
    <v-main v-else>
      <!-- ทำไมไม่ redirect ไปหน้า /login ตรง ๆ ด้วย navigateTo('/login')?
           เพราะอยากให้ URL เดิมที่ผู้ใช้ตั้งใจเปิดยังคงอยู่ (เช่นถ้าแชร์ลิงก์
           /users ให้เพื่อนที่ยังไม่ได้ login เพื่อนจะเห็น URL /users เดิม
           พร้อมข้อความแจ้งเตือนนี้ ไม่ใช่ถูกเด้งไป /login เฉย ๆ จนไม่รู้ว่า
           เดิมทีตั้งใจจะเปิดหน้าไหน) หลัง login สำเร็จแล้วกด refresh หน้า
           เดิม (หรือมี middleware พากลับมา) จะเห็นเนื้อหาจริงของหน้านั้นทันที
           — ดู middleware/auth.global.js ประกอบ ที่เขียนไว้ไม่ force
           redirect กรณีนี้โดยตั้งใจเช่นกัน -->
      <v-container class="d-flex align-center justify-center" style="min-height: 100vh">
        <v-card max-width="420" class="w-100 text-center pa-2">
          <v-card-title class="justify-center">คุณยังไม่ได้เข้าสู่ระบบ</v-card-title>
          <v-card-text>กรุณาคลิกเพื่อเข้าสู่ระบบก่อนใช้งาน</v-card-text>
          <v-card-actions class="justify-center">
            <v-btn color="primary" variant="elevated" to="/login">เข้าสู่ระบบ</v-btn>
          </v-card-actions>
        </v-card>
      </v-container>
    </v-main>
  </v-app>
</template>
