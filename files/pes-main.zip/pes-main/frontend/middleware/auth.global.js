// ~/middleware/auth.global.js
//
// นี่คือ "global route middleware" ของ Nuxt 3 — ไฟล์ที่อยู่ในโฟลเดอร์
// middleware/ และมีคำว่า ".global" ต่อท้ายชื่อไฟล์ (auth.global.js) จะถูก
// Nuxt เรียกให้ทำงานอัตโนมัติ "ทุกครั้ง" ก่อนเปลี่ยนหน้า (ทุกเส้นทาง) โดยไม่ต้อง
// ไปประกาศ middleware นี้ไว้ในแต่ละหน้าเอง (ต่างจาก middleware ธรรมดาที่ต้อง
// เรียกใช้เองผ่าน definePageMeta({ middleware: [...] }))
//
// หน้าที่ของไฟล์นี้มีอย่างเดียว: ถ้า "login อยู่แล้ว" แต่ดันพยายามเปิดหน้า login
// ซ้ำ ให้เด้งกลับไปหน้าแรก (/) แทน จะได้ไม่เห็นฟอร์ม login ซ้อนทั้งที่ login แล้ว
//
// ส่วนกรณีตรงข้าม (ยังไม่ login แต่พยายามเปิดหน้าอื่นที่ต้อง login) ไฟล์นี้
// "ไม่" เด้งออกไปเอง — ปล่อยให้ layouts/default.vue และ layouts/dashboard.vue
// เป็นผู้ตัดสินใจแสดงข้อความ "คุณยังไม่ได้เข้าสู่ระบบ" แทนเนื้อหาจริงแทน
// (ดูเหตุผลในคอมเมนต์ของ layouts/default.vue)

import { useAuthStore } from '~/stores/auth'
// useAuthStore คือ Pinia store ที่เก็บสถานะการ login ปัจจุบัน (ดูไฟล์
// stores/auth.js) — เราต้องใช้มันเพื่อเช็กว่า user คนนี้ login อยู่หรือยัง

// รายชื่อ "หน้า login" ทั้งหมดในระบบ ตอนนี้มีหน้าเดียวคือ /login
// (ถ้าในอนาคตเพิ่มหน้า login แบบอื่นเข้ามาอีก ให้เติม path ใหม่ลงใน array นี้)
const PUBLIC_PAGES = ['/login']

// defineNuxtRouteMiddleware คือ helper ของ Nuxt สำหรับประกาศ route middleware
// ฟังก์ชันที่ส่งเข้าไปจะได้รับพารามิเตอร์ `to` = route ปลายทางที่กำลังจะไป
// และ `from` = route ปัจจุบัน (ไฟล์นี้ใช้แค่ `to`)
export default defineNuxtRouteMiddleware((to) => {
  // process.client เป็น true เฉพาะตอนโค้ดรันอยู่ในเบราว์เซอร์ (ฝั่ง client)
  // เนื่องจากแอปนี้ตั้งค่า ssr: false (ดู nuxt.config.ts) หน้าเว็บทุกหน้าจึง
  // render ฝั่ง client ล้วน ๆ อยู่แล้ว แต่ middleware ตัวนี้ยังถูกเรียกครั้งแรก
  // ตอนเซิร์ฟเวอร์ประมวลผล route ด้วย (ก่อนโหลด JS ฝั่ง client) ซึ่งตอนนั้นยัง
  // ไม่มี localStorage ให้เช็กสถานะ login ได้ จึง return ออกไปเฉย ๆ ก่อน เพื่อ
  // รอให้ไปทำงานจริงตอนรันบน client เท่านั้น
  if (!process.client) return

  // ดึง instance ของ auth store ปัจจุบันออกมาใช้
  const auth = useAuthStore()

  // เงื่อนไข: "login อยู่แล้ว (auth.isLogged === true)" และ "กำลังจะไปหน้า login"
  // (to.path อยู่ใน PUBLIC_PAGES) → ให้เปลี่ยนเส้นทางไปหน้าแรกแทน
  // navigateTo('/') คือฟังก์ชันของ Nuxt สำหรับ redirect ไปอีก route หนึ่ง
  // การ return ค่าที่ navigateTo คืนมา คือวิธีบอก Nuxt middleware ว่า "ให้ redirect"
  if (auth.isLogged && PUBLIC_PAGES.includes(to.path)) {
    return navigateTo('/')
  }

  // ถ้าไม่เข้าเงื่อนไขด้านบน ฟังก์ชันจะจบลงโดยไม่ return อะไร (undefined)
  // ซึ่งแปลว่า "ปล่อยผ่าน ให้ไปหน้าที่ต้องการได้ตามปกติ"
  //
  // หมายเหตุสำคัญ: กรณี "ยังไม่ได้ login แต่พยายามเข้าหน้าที่ต้อง login"
  // (เช่น /upload, /users) ไฟล์นี้จะไม่เด้งออกไปเอง เพราะเราออกแบบให้ layout
  // (default.vue / dashboard.vue) เป็นคนเช็ก auth.isLogged อีกชั้นหนึ่งแทน
  // แล้วแสดงข้อความ "คุณยังไม่ได้เข้าสู่ระบบ" คลุมทับเนื้อหาจริงไว้ โดยไม่ต้อง
  // เปลี่ยน URL ออกจากหน้าที่ผู้ใช้ตั้งใจเปิด — ทำให้ URL เดิมยังอยู่ กด refresh
  // หลัง login แล้วจะกลับมาที่หน้าเดิมได้พอดี แทนที่จะถูกเด้งไปหน้า login เสมอ
})
