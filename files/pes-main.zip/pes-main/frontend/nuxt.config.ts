// nuxt.config.ts
// หมายเหตุ: บรรทัดนี้เคยแก้เพื่อกระตุ้นให้ job build_frontend ใน Pipeline ทำงาน
// (ทดสอบ push image ขึ้น Registry)
//
// ไฟล์ตั้งค่ากลางของทั้งแอป Nuxt 3 — ทุก option ที่เขียนในนี้มีผลตอน
// `npm run dev` / `npm run build` ทันที (ต้อง restart dev server เองถ้าแก้
// ไฟล์นี้ตอน dev อยู่ Nuxt จะไม่ hot-reload การตั้งค่าระดับนี้ให้อัตโนมัติ)
// อ้างอิงตัวเลือกทั้งหมดได้ที่ https://nuxt.com/docs/api/configuration/nuxt-config
import vuetify, { transformAssetUrls } from 'vite-plugin-vuetify'
// ปลั๊กอินที่เชื่อม Vuetify (ไลบรารี UI component ที่ใช้ทั้งแอป เช่น
// <v-btn>, <v-card>) เข้ากับ Vite (เครื่องมือ build ที่ Nuxt 3 ใช้อยู่ข้างใน)

export default defineNuxtConfig({
  // ✅ ทั้งแอปเป็น SPA (ไม่ render ฝั่ง server) เพราะ auth เก็บ token ใน localStorage
  //    ล้วนๆ — ถ้าเปิด SSR หน้า protected จะ flash ให้เห็นก่อน middleware เด้งไป /login
  ssr: false,
  // ssr: false คือปิดโหมด Server-Side Rendering ทั้งหมด (แอปจะ render หน้า
  // เว็บด้วย JavaScript ในเบราว์เซอร์ล้วน ๆ เหมือนแอป React/Vue SPA ทั่วไป
  // ไม่ใช่ render เป็น HTML สำเร็จรูปจากฝั่งเซิร์ฟเวอร์ก่อนส่งมา) เหตุผลที่
  // ต้องปิด: localStorage (ที่เก็บ token การ login ไว้ — ดู stores/auth.js)
  // มีอยู่เฉพาะในเบราว์เซอร์เท่านั้น ไม่มีบนฝั่งเซิร์ฟเวอร์ ถ้าเปิด SSR ไว้
  // หน้าที่ต้อง login ก่อนจะ render เนื้อหาจริงออกมาให้เห็นชั่วพริบตาหนึ่ง
  // (ฝั่งเซิร์ฟเวอร์ยังไม่รู้ว่า login อยู่หรือเปล่า) ก่อนที่ JavaScript ฝั่ง
  // client จะโหลดเสร็จแล้วค่อยรู้ตัวว่าต้องเด้งไปหน้า login — เรียกอาการนี้ว่า
  // "flash of protected content" ปิด SSR ไปเลยคือทางแก้ที่ตรงที่สุดสำหรับ
  // แอปขนาดเล็กแบบนี้
  nitro: {
    // Nitro คือเซิร์ฟเวอร์เอนจินที่ Nuxt 3 ใช้ข้างใน (จัดการ routing,
    // build output ฯลฯ)
    compatibilityDate: '2025-10-12', // 🔥 วันที่ตามที่ Nuxt แนะนำใน warning
    // ค่านี้บอก Nitro ว่าให้ใช้พฤติกรรม/API เวอร์ชันไหนเป็นมาตรฐานอ้างอิง —
    // ถ้าไม่ตั้งไว้ Nuxt จะเตือนตอน dev/build (ตั้งตามที่ warning แนะนำมา
    // พอดี ไม่มีผลต่อ logic ของแอปโดยตรง)
  },

  modules: ['@pinia/nuxt'],
  // โหลดปลั๊กอิน Pinia (ตัวจัดการ state กลางของแอป) เข้ามาใช้งาน — ดู
  // stores/auth.js ว่าเก็บ state อะไรไว้บ้าง
  pinia: {
    autoImports: ['defineStore', 'storeToRefs']
    // ให้ Nuxt auto-import สองฟังก์ชันนี้ (defineStore ใช้สร้าง store,
    // storeToRefs ใช้แปลง state ของ store ให้เป็น reactive refs) ทำให้ไม่
    // ต้องเขียน import { defineStore } from 'pinia' เองทุกไฟล์ที่ใช้งาน
  },
  devtools: { enabled: false },
  // ปิด Nuxt DevTools (แถบเครื่องมือ debug ที่ลอยอยู่มุมจอตอน dev) — เปิดเป็น
  // true ได้ถ้าอยากใช้เครื่องมือ debug เพิ่มเติมตอนพัฒนา
  runtimeConfig: {
    public: {
      // ค่าว่าง = ให้ frontend เดา URL ของ backend จาก host ที่ browser ใช้เปิดเว็บเอง
      // (ดู composables/useApiBase.js) — ตั้งค่านี้เฉพาะตอน backend อยู่คนละ
      // host/port กับหน้าเว็บจริง ๆ (เช่น deploy หลัง reverse proxy)
      apiBase: process.env.NUXT_PUBLIC_API_BASE || '',
      // runtimeConfig.public.* คือค่าตั้งค่าที่ "เข้าถึงได้จากฝั่ง client"
      // (ต่างจาก runtimeConfig เฉย ๆ ที่เข้าถึงได้แค่ฝั่งเซิร์ฟเวอร์เท่านั้น
      // — แต่เพราะแอปนี้ ssr:false ทั้งหมด ค่าที่ไม่ได้อยู่ใต้ .public จะไม่มี
      // ประโยชน์เลย เพราะไม่มี "ฝั่งเซิร์ฟเวอร์" ให้ใช้งานจริง) อ่านค่านี้ได้
      // ผ่าน useRuntimeConfig().public.apiBase ที่ไหนก็ได้ในแอป (ดูตัวอย่าง
      // การใช้งานจริงใน composables/useApiBase.js)

      // พอร์ตที่ backend ฟังอยู่ (ใช้ตอน auto-detect URL ของ backend จาก
      // host ปัจจุบัน — ดู composables/useApiBase.js) มาจากตัวแปร
      // NUXT_PUBLIC_API_PORT ที่ docker-compose.yml ตั้งให้อัตโนมัติตาม
      // BACKEND_PORT ใน .env (ไม่ต้องแก้ไฟล์นี้เองถ้าแค่เปลี่ยนพอร์ตใน .env)
      apiPort: process.env.NUXT_PUBLIC_API_PORT || '7000'
    }
  },
  // ✅ ย้าย PostCSS มาตั้งค่าที่นี่
  postcss: {
    plugins: {
      tailwindcss: {},
      autoprefixer: {},
      // tailwindcss แปลง utility class (เช่น class="flex gap-2") ให้เป็น
      // CSS จริง, autoprefixer เติม vendor prefix (เช่น -webkit-) ให้ CSS
      // อัตโนมัติเพื่อรองรับเบราว์เซอร์รุ่นเก่า — ทั้งสองทำงานผ่าน PostCSS
      // (เครื่องมือแปลง CSS ด้วย plugin) ซึ่ง Nuxt เรียกให้ตอน build ให้เอง
    },
  },
  css: [
    'vuetify/styles',
    // CSS หลักของ Vuetify (จำเป็นต้องโหลด ไม่งั้น component ของ Vuetify
    // จะไม่มีสไตล์ใด ๆ เลย)
    '@mdi/font/css/materialdesignicons.min.css',
    // ไอคอนฟอนต์ Material Design Icons — ใช้กับ prop เช่น
    // prepend-icon="mdi-account" ในหลายหน้าของแอป
    '~/assets/css/tailwind.css'
    // ไฟล์ CSS ของเราเองที่ import directive ของ Tailwind ไว้ (ดูเนื้อหาจริง
    // ในไฟล์ assets/css/tailwind.css)
  ],

  build: { transpile: ['vuetify'] },
  // บอก build tool ให้ "แปลง" (transpile) โค้ดของไลบรารี vuetify ด้วย (ปกติ
  // build tool จะข้ามการแปลงโค้ดใน node_modules เพื่อความเร็ว แต่ Vuetify
  // ต้องการให้แปลงด้วยเพื่อให้ทำงานถูกต้องกับ Nuxt/Vite)
  vite: {
    ssr: { noExternal: ['vuetify'] },
    // บอก Vite ว่าตอน build ฝั่ง SSR (แม้แอปนี้จะปิด ssr ไปแล้ว แต่ Nuxt
    // ยังมีกระบวนการ build บางส่วนที่อ้างอิง config นี้อยู่) ห้ามถือว่า
    // vuetify เป็น "external module" (ไม่ bundle รวมเข้ามา) ต้อง bundle
    // รวมเข้ามาในโค้ดจริง ๆ
    server: {
      // Dev server ของ Vite รับเฉพาะ localhost และ IP เป็นค่าเริ่มต้น ถ้าเปิดผ่านชื่อ
      // โดเมนจะได้ 403 "Blocked request" — บรรทัดนี้อนุญาตโดเมนภายในทุกชื่อที่ลงท้าย
      // ด้วย .vecskill.ovec (ถ้าใช้โดเมนอื่นให้แก้ตรงนี้ แล้ว build image ใหม่)
      allowedHosts: ['.vecskill.ovec'],
    },
    plugins: [vuetify({ autoImport: true })],
    // เปิดใช้ autoImport ของปลั๊กอิน Vuetify — ทำให้เขียน <v-btn> ใน
    // template ได้เลยโดยไม่ต้อง import VBtn เองทุกไฟล์
    vue: { template: { transformAssetUrls } }
    // ใช้ transformAssetUrls ที่ vite-plugin-vuetify เตรียมไว้ให้ (import
    // มาจากบรรทัดบนสุดของไฟล์นี้) เพื่อให้ path ของรูปภาพ/asset ที่อ้างอิงใน
    // template ของ component แบบ Vuetify ทำงานถูกต้องตอน build
  }
})
