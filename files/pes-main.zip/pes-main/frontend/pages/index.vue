<script setup>
definePageMeta({ layout: 'default' })
// หน้า "Dashboard" หลักของแอป (route "/") — ปัจจุบันเนื้อหาจริงคือตาราง
// รายชื่อผู้ใช้ทั้งหมด (เหมือนกับหน้า /users ในทางปฏิบัติ ไฟล์นี้กับ
// menu "Users" ชี้มาที่ path เดียวกันคือ "/") ใช้ layout 'default' (ดู
// layouts/default.vue ที่จะโชว์การ์ด "ยังไม่ได้ login" แทนถ้ายังไม่ login)
import { ref, computed, onMounted, watch } from 'vue'
import { useAuthStore } from '~/stores/auth'

const router = useRouter()
const { $api } = useNuxtApp()
const auth = useAuthStore()

const isAdmin = computed(() => auth.user?.role === 'admin')
// แก้ไข: เดิมปุ่ม "Create User" และ "Edit"/"Delete" ในตารางแสดงให้ทุก role
// เห็นเหมือนกันหมด ทั้งที่ backend อนุญาตให้ทำจริงเฉพาะ admin เท่านั้น (ดู
// backend/routes/users.routes.js — POST/PUT/DELETE ผูก auth('admin') ไว้)
// ทำให้ role อื่นกดแล้วเจอแต่ error 403 งง ๆ — ตอนนี้ซ่อนปุ่มเหล่านี้ไปเลย
// ถ้าไม่ใช่ admin ให้ UI ตรงกับสิทธิ์จริงที่มี

const apiDocsUrl = `${useApiBase()}/docs`
// คำนวณ URL ของหน้า Swagger API Docs แบบไดนามิกจาก host ปัจจุบัน (ดู
// composables/useApiBase.js) — ใช้วิธีเดียวกับที่ composables/useMenu.js
// ทำกับลิงก์ API Docs ในเมนูซ้าย เพื่อให้ปุ่ม "Open API Docs" บนหน้านี้
// ใช้งานได้ถูกต้องไม่ว่าจะเปิดแอปจาก host ไหนก็ตาม

const search = ref('')
const items = ref([])
const total = ref(0)
const loading = ref(false)
const errorMsg = ref('')
const confirmDialog = ref(false)
const selectedUser = ref(null)

const options = ref({
  page: 1,
  itemsPerPage: 10,
  sortBy: [{ key: 'id', order: 'desc' }]
})
// options คือ object เดียวที่รวมสถานะการแบ่งหน้า/เรียงลำดับทั้งหมดไว้
// ด้วยกัน ตรงกับรูปแบบที่ <v-data-table-server> ของ Vuetify ต้องการ (ดู
// v-model:page, v-model:items-per-page ใน template ด้านล่าง) sortBy เป็น
// array ของ object { key, order } เพราะ Vuetify รองรับเรียงหลายคอลัมน์
// พร้อมกันได้ (ในที่นี้ใช้แค่ตัวแรกเสมอ [0])

// โหลดข้อมูล
async function load() {
  loading.value = true
  errorMsg.value = ''
  try {
    const sortKey = options.value.sortBy?.[0]?.key || 'id'
    const sortDesc = ((options.value.sortBy?.[0]?.order) || 'desc') === 'desc'
    // แปลงรูปแบบ sortBy ของ Vuetify ([{key,order}]) ให้เป็นรูปแบบที่
    // backend ต้องการ (sortBy เป็น string เดี่ยว, sortDesc เป็น boolean) —
    // ดู backend/controllers/users.controller.js -> listServer ว่ารับ
    // query string รูปแบบไหน

    const { data } = await $api.get('/api/users/server', {
      params: {
        page: options.value.page,
        itemsPerPage: options.value.itemsPerPage,
        sortBy: sortKey,
        sortDesc,
        search: search.value
      }
      // axios แปลง params object นี้เป็น query string ให้อัตโนมัติ เช่น
      // ?page=1&itemsPerPage=10&sortBy=id&sortDesc=true&search=
    })
    items.value = data.items
    total.value = data.total
    // total ต้องเก็บแยกจาก items.length เพราะ items ที่ได้มาคือแค่ "หน้า
    // เดียว" (10 แถว) แต่ total คือจำนวนทั้งหมดในระบบ (ใช้คำนวณจำนวนหน้า
    // ทั้งหมดใน <v-data-table-server>)
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message || 'Load failed'
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  if (!auth.isLogged) {
    router.push('/login')
    return
  }
  // หมายเหตุ: การเช็ก + redirect ตรงนี้ "ซ้ำซ้อน" กับที่ layouts/default.vue
  // ทำอยู่แล้ว (layout จะโชว์การ์ด "ยังไม่ได้ login" แทนเนื้อหานี้ทั้งหมด
  // ถ้า !auth.isLogged โดยไม่ render component นี้เลยด้วยซ้ำ) โค้ดส่วนนี้
  // จึงแทบไม่มีโอกาสทำงานจริงในทางปฏิบัติ (component นี้จะไม่ถูก mount เลย
  // ถ้ายังไม่ login) เก็บไว้เป็น "ชั้นป้องกันสำรอง" เฉย ๆ ไม่เป็นอันตราย
  load()
})
watch(options, load, { deep: true })
// deep: true จำเป็นเพราะ options เป็น object/array ซ้อนกัน (sortBy เป็น
// array ของ object) — watch ปกติ (ไม่ deep) จะเห็นแค่ว่า "ตัวแปร options
// เปลี่ยน reference ไหม" ไม่เห็นการเปลี่ยนแปลงค่าข้างในลึก ๆ เช่นตัวเลข
// page ที่เปลี่ยนจาก v-model:page ของตาราง
watch(search, () => { options.value.page = 1; load() })
// เมื่อพิมพ์ช่องค้นหาใหม่ ให้รีเซ็ตกลับไปหน้า 1 เสมอ (ไม่งั้นถ้าค้นหาคำใหม่
// ขณะที่อยู่หน้า 5 ของผลลัพธ์เดิม อาจไม่เจอข้อมูลอะไรเลยเพราะผลการค้นหาใหม่
// มีแค่ 2 หน้า) แล้วค่อยโหลดข้อมูลใหม่

function logout() {
  auth.logout()
  router.push('/login')
}

/* ✅ เรียกตอนกดปุ่ม Delete */
function askDelete(user) {
  selectedUser.value = user
  confirmDialog.value = true
  // ยังไม่ลบจริงตอนนี้ — แค่เก็บว่า "กำลังจะลบใคร" แล้วเปิด dialog ถาม
  // ยืนยันก่อนเสมอ (ป้องกันกดลบพลาดโดยไม่ตั้งใจ)
}

/* ✅ เมื่อกดยืนยันใน dialog */
async function confirmDelete() {
  try {
    await $api.delete(`/api/users/${selectedUser.value.id}`)
    confirmDialog.value = false
    selectedUser.value = null
    await load()
    // โหลดรายการใหม่หลังลบสำเร็จ เพื่อให้ตารางอัปเดตทันที (ไม่ลบแถวออกจาก
    // items เองตรง ๆ แบบ optimistic update — เลือก reload ทั้งหน้าจาก
    // server ใหม่เพื่อความชัวร์ว่าข้อมูล/total ตรงกับฐานข้อมูลจริงเสมอ)
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message || 'Delete failed'
  }
}
</script>

<template>
  <div class="container mx-auto px-4 py-6">
    <div class="flex items-center justify-between mb-4 gap-3">
      <div class="flex items-center gap-3">
        <NuxtLink v-if="isAdmin" to="/users/new">
          <v-btn color="primary" variant="elevated">Create User</v-btn>
        </NuxtLink>
        <!-- แสดงเฉพาะ admin (ดู isAdmin ใน script ด้านบน) — role อื่นสร้าง
             ผู้ใช้ใหม่ไม่ได้อยู่แล้วฝั่ง backend (POST /api/users จำกัดไว้
             เฉพาะ admin) ซ่อนปุ่มนี้ไปให้ตรงกับสิทธิ์จริง -->
        <a :href="apiDocsUrl" target="_blank">
          <v-btn variant="tonal">Open API Docs</v-btn>
        </a>
        <!-- แก้ไข: เดิม href ฝังค่าคงที่ "http://localhost:7000/docs" ไว้
             ตรง ๆ ซึ่งจะใช้ไม่ได้ทันทีที่เปิดแอปผ่าน host อื่น (127.0.0.1,
             IP วง LAN, โดเมนจริง) เพราะ URL ที่ฝังไว้ชี้กลับไปที่ localhost
             เสมอไม่ว่าจะเปิดแอปจากที่ไหนก็ตาม — เปลี่ยนมาคำนวณจาก
             useApiBase() แบบเดียวกับที่ composables/useMenu.js ทำกับลิงก์
             API Docs ในเมนูซ้ายแล้ว (ดูตัวแปร apiDocsUrl ด้านบนในสคริปต์) -->
        <NuxtLink to="/upload">
          <v-btn variant="tonal">Upload</v-btn>
        </NuxtLink>
      </div>

      <div class="flex items-center gap-3">
        <v-text-field v-model="search" label="Search" density="comfortable" hide-details />
        <v-btn color="error" @click="logout">Logout</v-btn>
      </div>
    </div>

    <v-card>
      <v-card-title class="text-lg">Users</v-card-title>
      <v-card-text>
        <v-alert
          v-if="errorMsg"
          type="error"
          variant="tonal"
          class="mb-3"
        >
          {{ errorMsg }}
        </v-alert>

        <v-data-table-server
          v-model:items-per-page="options.itemsPerPage"
          v-model:page="options.page"
          :items-length="total"
          :items="items"
          :loading="loading"
          :headers="[
            { title:'ID', key:'id' },
            { title:'Name', key:'name_th' },
            { title:'Email', key:'email' },
            { title:'Role', key:'role' },
            { title:'Created', key:'created_at' },
            { title:'Actions', key:'actions', sortable:false }
          ]"
          :sort-by="options.sortBy"
          @update:sort-by="(s) => options.sortBy = s"
        >
          <!-- <v-data-table-server> (ต่างจาก <v-data-table> ธรรมดา) คือ
               ตารางที่ "ไม่โหลดข้อมูลทั้งหมดมาเก็บไว้เอง" แต่ปล่อยให้เราเป็น
               คนดึงข้อมูลเฉพาะหน้าที่ต้องการมาเอง (ฟังก์ชัน load() ด้านบน)
               ทุกครั้งที่ page/itemsPerPage/sortBy เปลี่ยน (ผ่าน watch
               options ด้านบน) เหมาะกับข้อมูลที่มีจำนวนแถวเยอะมาก -->
          <template #item.actions="{ item }">
            <!-- #item.actions คือ "named slot" ของ Vuetify สำหรับกำหนดเอง
                 ว่าคอลัมน์ที่ key เป็น 'actions' จะแสดงผลยังไง (ปกติถ้าไม่
                 ใส่ slot นี้ จะแสดงค่าดิบของฟิลด์ actions ตรง ๆ ซึ่งไม่มี
                 ข้อมูลจริงให้แสดงอยู่แล้ว เพราะเป็นคอลัมน์ที่สร้างปุ่มเอง) -->
            <template v-if="isAdmin">
              <NuxtLink :to="`/users/${item.id}`">
                <v-btn size="small" variant="text">Edit</v-btn>
              </NuxtLink>
              <v-btn
                size="small"
                color="error"
                variant="text"
                @click="askDelete(item)"
              >
                Delete
              </v-btn>
            </template>
            <span v-else class="text-caption text-medium-emphasis">—</span>
            <!-- ซ่อน Edit/Delete สำหรับ role ที่ไม่ใช่ admin เช่นกัน (ดู
                 isAdmin ด้านบน) — backend จำกัด PUT/DELETE /api/users/:id
                 ไว้เฉพาะ admin เหมือนกัน (ดู
                 backend/routes/users.routes.js) ถ้าปล่อยปุ่มไว้ role อื่นจะ
                 กดแล้วเจอแค่ error 403 งง ๆ โดยไม่มีประโยชน์ -->
          </template>
        </v-data-table-server>
      </v-card-text>
    </v-card>

    <!-- ✅ Dialog Confirm Delete -->
    <v-dialog v-model="confirmDialog" max-width="400">
      <v-card>
        <v-card-title class="text-h6">Confirm Delete</v-card-title>
        <v-card-text>
          Delete user <strong>#{{ selectedUser?.id }}</strong> ({{ selectedUser?.name_th }}) ?
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn variant="text" @click="confirmDialog = false">Cancel</v-btn>
          <v-btn color="error" variant="flat" @click="confirmDelete">Delete</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>
