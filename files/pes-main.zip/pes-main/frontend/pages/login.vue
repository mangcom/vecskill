<!-- ~/pages/login.vue -->
<!--
  หน้า login หลักของระบบ (หน้าเดียวที่เหลืออยู่ในแอปนี้ — เคยมีหน้าทดลอง UI
  อื่น ๆ เช่น login1.vue/login-vuetify.vue/login-daisy.vue แต่ถูกลบออกแล้ว
  เพราะไม่ได้ใช้งานจริง) ใช้ layout 'auth-login' (ดู
  layouts/auth-login.vue) ซึ่งเป็นแค่กรอบการ์ดกลางจอ ไม่มีเมนู/app bar
-->
<template>
  <div class="container mx-auto px-4 py-12 max-w-md">
    <v-card>
      <v-card-title class="text-xl">เข้าสู่ระบบ</v-card-title>
      <v-card-text>
        <form class="flex flex-col gap-4" @submit.prevent="onSubmit">
          <!-- @submit.prevent คือ event modifier ของ Vue — ".prevent" สั่งให้
               เรียก event.preventDefault() ให้อัตโนมัติ กันพฤติกรรม default
               ของ <form> (ที่จะ reload หน้าเว็บทั้งหน้าเมื่อกด submit) แล้ว
               เรียก onSubmit (ฟังก์ชันของเราเอง ด้านล่าง) แทน -->
          <v-text-field
                v-model="email"
                label="Email"
                type="email"
                :rules="[r => !!r || 'กรอกอีเมล', r => /.+@.+\..+/.test(r) || 'อีเมลไม่ถูกต้อง']"
                prepend-inner-icon="mdi-email-outline"
                required
              />
              <!-- :rules ของ Vuetify คือ array ของฟังก์ชันตรวจสอบ แต่ละ
                   ฟังก์ชันรับค่าปัจจุบันของ field (r) แล้วคืนค่า true (ผ่าน)
                   หรือ string ข้อความ error (ไม่ผ่าน) — นี่คือ validation
                   "ระดับ field เดียว" ของ Vuetify เอง ซึ่งทำงานคู่ขนานไปกับ
                   validation ของ vee-validate (schema ด้านล่างใน script)
                   ทั้งสองระบบตรวจสอบเรื่องคล้ายกัน (ซ้ำซ้อนกันบ้าง) แต่ไม่
                   ขัดแย้งกัน -->
              <v-text-field
                v-model="password"
                label="Password"
                :type="showPw ? 'text' : 'password'"
                :append-inner-icon="showPw ? 'mdi-eye-off' : 'mdi-eye'"
                @click:append-inner="showPw = !showPw"
                prepend-inner-icon="mdi-lock-outline"
                :rules="[r => !!r || 'กรอกรหัสผ่าน']"
                required
              />
              <!-- แก้ไข: ไอคอนรูปตาเดิมอ้างอิงตัวแปรชื่อ "show" ซึ่งไม่มีอยู่
                   จริงในสคริปต์ (ตัวแปรจริงชื่อ showPw) ทำให้ไอคอนค้างเป็น
                   รูปตาเปิด (mdi-eye) ตลอดเวลาไม่เคยสลับเป็นตาปิด แม้ว่าการ
                   คลิกจะยังสลับ :type ระหว่าง text/password ได้ถูกต้องอยู่
                   แล้วก็ตาม (เพราะ :type ใช้ showPw ถูกตัวอยู่แล้ว) — แก้
                   โดยเปลี่ยน show เป็น showPw ให้ตรงกับตัวแปรจริง -->
          <div class="d-flex align-center justify-space-between">
            <v-checkbox v-model="rememberMe" label="Remember me" density="comfortable" hide-details />
            <NuxtLink to="/forgot" class="text-primary text-caption">Forgot password?</NuxtLink>
            <!-- หมายเหตุ: ยังไม่มีหน้า pages/forgot.vue จริง — คลิกลิงก์นี้
                 จะไปเจอหน้า "กำลังพัฒนา" (ดู error.vue) แทน เป็นฟีเจอร์ที่ยัง
                 ไม่ได้ทำ ไม่ใช่บั๊ก -->
          </div>
          <v-alert v-if="errorMsg" type="error" density="comfortable" variant="tonal">
            {{ errorMsg }}
          </v-alert>
          <v-card-actions class="px-0">
            <v-spacer />
            <v-btn :loading="loading" color="primary" type="submit">Sign in</v-btn>
          </v-card-actions>
        </form>
      </v-card-text>
    </v-card>

    <div class="text-center text-caption text-medium-emphasis mt-4">
      Demo: <strong>admin@vecskill.ovec</strong> / <strong>12345678</strong>
      <br />
      (ผู้ใช้ตัวอย่างอื่น เช่น eva.it@vecskill.ovec, t.it01@vecskill.ovec ใช้รหัสผ่านเดียวกัน)
    </div>
  </div>
</template>
<script setup>
definePageMeta({ layout: 'auth-login', ssr: false })// ปิด SSR (ถ้าเปิดจะ error เพราะใช้ localStorage)
// definePageMeta คือ macro พิเศษของ Nuxt (ไม่ต้อง import) ใช้ประกาศ
// metadata ของหน้านี้ — layout เลือกใช้ layouts/auth-login.vue ส่วน
// ssr: false ตั้งซ้ำไว้เฉพาะหน้านี้อีกชั้น (แม้ nuxt.config.ts จะปิด
// ssr ไว้ทั้งแอปอยู่แล้วก็ตาม เป็นการเขียนกันเหนียว/สื่อความหมายชัดเจนว่า
// หน้านี้พึ่งพา localStorage โดยเฉพาะ)
import { ref } from 'vue'
import { useAuthStore } from '~/stores/auth'
import { useForm, useField } from 'vee-validate'
import * as yup from 'yup'
// vee-validate คือไลบรารีจัดการฟอร์ม/validation ของ Vue, yup คือไลบรารีที่
// ใช้นิยาม "schema" (โครงสร้างกฎการตรวจสอบข้อมูล) — ทั้งสองตัวทำงานร่วมกัน:
// yup นิยามกฎ, vee-validate เป็นคนเอากฎไปผูกกับ field จริงในฟอร์ม

const { $api } = useNuxtApp()
// ดึง axios instance กลางที่ plugins/axios.client.js สร้างไว้ (ดูไฟล์นั้น
// เพื่อดูว่า $api ถูกตั้งค่าอะไรไว้บ้าง เช่น baseURL, การแนบ token อัตโนมัติ)
const router = useRouter()
const auth = useAuthStore()

const errorMsg = ref('')
const showPw = ref(false)
const rememberMe = ref(false)
const loading = ref(false)

const schema = yup.object({
  email: yup.string().email('อีเมลไม่ถูกต้อง').required('กรอกอีเมล'),
  password: yup.string().min(6, 'รหัสผ่านอย่างน้อย 6 ตัว').required('กรอกรหัสผ่าน')
})
// นิยามกฎ validation ด้วย yup: email ต้องเป็นรูปแบบอีเมลที่ถูกต้องและห้าม
// ว่าง, password ต้องมีอย่างน้อย 6 ตัวอักษรและห้ามว่าง — ข้อความ error ที่
// ใส่ไว้ในแต่ละ .email()/.required()/.min() คือข้อความที่จะโชว์ถ้าฟิลด์นั้น
// ไม่ผ่านเงื่อนไข

const { handleSubmit } = useForm({ validationSchema: schema })
// useForm ผูกฟอร์มทั้งฟอร์มเข้ากับ schema ที่นิยามไว้ — handleSubmit คือ
// "ตัวห่อ" ฟังก์ชัน submit ของเรา (ดูด้านล่าง) ให้ vee-validate ตรวจสอบค่า
// ทุก field ตาม schema ก่อนเสมอ ถ้าไม่ผ่านจะไม่เรียกฟังก์ชันข้างในให้เลย
// (แสดง error message ที่แต่ละ field แทน)
const { value: email, errorMessage: emailErr } = useField('email', undefined, {
  initialValue: 'admin@vecskill.ovec'
})
const { value: password, errorMessage: passwordErr } = useField('password', undefined, {
  initialValue: '12345678'
})
// useField('email') ผูก field ชื่อ 'email' (ต้องตรงกับ key ใน schema) เข้า
// กับตัวแปร reactive ชื่อ email (ใช้ v-model="email" ใน template ได้เลย)
// พร้อม errorMessage ที่จะมีค่าอัตโนมัติถ้า field นี้ validate ไม่ผ่าน (ไม่
// ได้ถูกใช้แสดงผลตรง ๆ ใน template ของไฟล์นี้ — Vuetify ใช้ :rules ของ
// ตัวเองแสดง error แทน แต่ emailErr/passwordErr ยังมีไว้ใช้ได้ถ้าต้องการ)
//
// ตั้ง initialValue ไว้เป็น demo credentials (ตัวเดียวกับที่โชว์ไว้ใต้
// ฟอร์ม login ด้านล่าง) เพื่อความสะดวกตอนทดสอบ/สาธิต — เปิดหน้า login มา
// ก็กรอกไว้ให้พร้อมกด Sign in ได้เลยโดยไม่ต้องพิมพ์เอง ผู้ใช้ยังแก้ไขเป็น
// บัญชีอื่นได้ตามปกติก่อนกด Sign in

const onSubmit = handleSubmit(async (values) => {
  // ฟังก์ชันข้างในนี้จะถูกเรียกก็ต่อเมื่อ vee-validate เช็ก schema ผ่านครบ
  // ทุก field แล้วเท่านั้น — values คือ object ของค่าทุก field ที่ผ่านแล้ว
  // เช่น { email: '...', password: '...' }
  errorMsg.value = ''
  loading.value = true
  try {
    const { data } = await $api.post('/api/auth/login', { ...values, remember: rememberMe.value })
    // ยิง POST ไปที่ backend (ดู backend/controllers/auth.controller.js)
    // ส่งทั้ง email/password (จาก values) และ remember (จาก checkbox
    // "Remember me" — หมายเหตุ: backend ปัจจุบันยังไม่ได้ใช้ค่า remember นี้
    // ทำอะไรเป็นพิเศษเลย เช่น ปรับอายุ token ให้นานขึ้น เป็นจุดที่เตรียมไว้
    // ให้ต่อยอดได้ในอนาคต)
    if (data?.accessToken) {
      auth.setAuth(data.accessToken, data.user)   // ← เก็บลง localStorage เรียบร้อย
      await router.push('/')
      // login สำเร็จ: บันทึกสถานะ login แล้วพาไปหน้าแรก — ใช้ router.push
      // (ของ Vue Router) ไม่ใช่ navigateTo (ของ Nuxt) ทั้งสองทำงานคล้ายกัน
      // ในแอปนี้เพราะ ssr:false แต่ navigateTo เป็นวิธีที่ Nuxt แนะนำมากกว่า
      // โดยทั่วไป (รองรับทั้ง SSR/CSR อัตโนมัติ)
    } else {
      errorMsg.value = 'Invalid response'
      // กรณีนี้คือ "response สำเร็จ (status 200) แต่ body ไม่มี accessToken
      // ติดมาด้วย" — เคยเป็นอาการจริงที่เจอตอน NUXT_PUBLIC_API_BASE ใน .env
      // ตั้งค่าผิดรูปแบบ (เช่นใส่แค่ "127.0.0.1" ไม่มี http://) จน request
      // หลุดไปเรียกหน้า frontend เองแทนที่จะเรียก backend จริง (ได้ HTML
      // กลับมาแทน JSON ที่มี accessToken) — ตอนนี้แก้ไขรากของปัญหานี้แล้วที่
      // composables/useApiBase.js (ทำให้ทนทานต่อค่าที่ตั้งผิดรูปแบบมากขึ้น)
      // แต่ยังเก็บ error message นี้ไว้เผื่อเกิดกรณีแปลก ๆ อื่นในอนาคต
    }
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message || 'Login error'
    // ไล่ลำดับหาข้อความ error ที่ดีที่สุดที่มี: ข้อความจาก backend ก่อน (ที่
    // อยู่ใน response body ถ้า backend ตอบ error กลับมาเป็น JSON ที่มี
    // message) ถ้าไม่มีให้ใช้ e.message ทั่วไปของ axios (เช่น "Network
    // Error" ตอนต่อ backend ไม่ติดเลย) ถ้าไม่มีทั้งคู่ใช้ข้อความ default
    console.error('LOGIN ERROR:', e)
  } finally {
    loading.value = false
    // finally รันเสมอไม่ว่าจะสำเร็จหรือพลาด — ปิดสถานะ loading ของปุ่ม
    // Sign in กลับคืน ให้กดใหม่ได้อีกครั้ง
  }
})

defineExpose({ email, password, errorMsg, onSubmit })
// defineExpose(...) เปิดให้โค้ดภายนอก component (ปกติ <script setup> จะ
// "ปิด" ทุกตัวแปรไว้เป็นส่วนตัว มองจากข้างนอกไม่เห็นเลย) เข้าถึงค่าที่ระบุ
// ไว้ได้ผ่าน wrapper.vm ตอนเทสต์ — เปิดเฉพาะเท่าที่จำเป็นสำหรับเทสต์
// (tests/login.spec.ts) เรียกใช้งาน ไม่กระทบพฤติกรรมตอนรันจริงกับผู้ใช้
// จริงเลย (ผู้ใช้จริงไม่มีทาง "เรียก" ค่าพวกนี้ผ่าน wrapper.vm ได้อยู่แล้ว)
</script>
