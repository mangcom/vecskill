<!-- pages/me/export.vue — route: /me/export -->
<!--
  Placeholder ของหน้า "Export" (ส่งออกสรุปผลการประเมิน/รายการหลักฐานของ
  ตัวเองเป็นไฟล์ เช่น PDF/Excel) — ยังไม่มีเนื้อหาจริง (ดูคำอธิบายรูปแบบ
  placeholder ร่วมของทุกไฟล์ในโฟลเดอร์นี้ที่ pages/me/index.vue)
-->
<script setup>
definePageMeta({ layout: 'dashboard' })
</script>
<template><div class="p-4">Coming soon: ส่งออกข้อมูล</div></template>
