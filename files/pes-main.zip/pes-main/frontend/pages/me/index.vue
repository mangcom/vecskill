<!-- pages/me/index.vue — route: /me -->
<!--
  หน้า "Profile" ของผู้ใช้ที่เป็น evaluatee (เมนู "Profile" ใน
  composables/useMenu.js -> MAP.user) ตอนนี้เป็นแค่ placeholder ("Coming
  soon") ยังไม่มีเนื้อหาจริง — ทุกไฟล์ในโฟลเดอร์ pages/me/ มีโครงเดียวกัน
  หมด (definePageMeta layout: 'dashboard' + ข้อความ "Coming soon" ของตัวเอง)
  เป็นจุดเริ่มต้นที่เตรียมไว้ให้ต่อยอดใส่เนื้อหาจริงทีหลัง

  ถ้าจะทำหน้านี้ให้สมบูรณ์ ลองดูตัวอย่างโครงสร้างจาก pages/upload.vue (ยิง
  API ผ่าน $api, แสดงผล error/loading state) เป็นแนวทาง — เนื้อหาที่ควรมี
  ในหน้านี้น่าจะเป็นข้อมูลโปรไฟล์ของผู้ใช้เอง (ชื่อ, แผนก, ตำแหน่ง ฯลฯ) ดึง
  จาก GET /api/users/:id (ใช้ auth.user.id ของตัวเอง) หรือ endpoint เฉพาะ
  ที่สร้างเพิ่มในอนาคต
-->
<script setup>
definePageMeta({ layout: 'dashboard' })
</script>
<template><div class="p-4">Coming soon: หน้าหลัก</div></template>
