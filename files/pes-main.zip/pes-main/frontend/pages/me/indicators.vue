<!-- pages/me/indicators.vue — route: /me/indicators -->
<!--
  Placeholder ของหน้า "Indicators" (ดูรายการตัวชี้วัดของตัวเองพร้อมสถานะ
  ว่าส่งหลักฐานครบหรือยัง) — ยังไม่มีเนื้อหาจริง (ดูคำอธิบายรูปแบบ
  placeholder ร่วมของทุกไฟล์ในโฟลเดอร์นี้ที่ pages/me/index.vue)

  ถ้าจะต่อยอด: backend มี GET /api/indicators (ดู
  backend/routes/attachments.js) และ GET /api/upload/mine (ดู
  backend/routes/upload.routes.js) ที่พอจะเอามาประกอบกันแสดงเป็นรายการ
  "ตัวชี้วัด X — มีไฟล์หลักฐานแล้ว Y ไฟล์" ได้
-->
<script setup>
definePageMeta({ layout: 'dashboard' })
</script>
<template><div class="p-4">Coming soon: ตัวชี้วัด</div></template>
