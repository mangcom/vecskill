<!-- pages/me/progress.vue — route: /me/progress -->
<!--
  Placeholder ของหน้า "Progress" (ติดตามความคืบหน้าการส่งหลักฐาน/การ
  ประเมินของตัวเองโดยรวม เช่น เสร็จไปกี่เปอร์เซ็นต์) — ยังไม่มีเนื้อหาจริง
  (ดูคำอธิบายรูปแบบ placeholder ร่วมของทุกไฟล์ในโฟลเดอร์นี้ที่
  pages/me/index.vue)
-->
<script setup>
definePageMeta({ layout: 'dashboard' })
</script>
<template><div class="p-4">Coming soon: ติดตามความคืบหน้า</div></template>
