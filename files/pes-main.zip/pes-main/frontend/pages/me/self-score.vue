<!-- pages/me/self-score.vue — route: /me/self-score -->
<!--
  Placeholder ของหน้า "Self Assessment" (ให้ผู้ใช้ประเมินตัวเองในแต่ละ
  ตัวชี้วัดก่อนส่งให้ evaluator ประเมินซ้ำ) — ยังไม่มีเนื้อหาจริง (ดูคำอธิบาย
  รูปแบบ placeholder ร่วมของทุกไฟล์ในโฟลเดอร์นี้ที่ pages/me/index.vue)
-->
<script setup>
definePageMeta({ layout: 'dashboard' })
</script>
<template><div class="p-4">Coming soon: ประเมินตัวเอง</div></template>
