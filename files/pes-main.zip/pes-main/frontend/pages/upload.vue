<!-- pages/upload.vue -->
<!--
  หน้าอัปโหลดไฟล์หลักฐาน (evidence) — หน้าที่ซับซ้อนที่สุดในแอปนี้ เพราะต้อง
  โหลดข้อมูลประกอบฟอร์มแบบเป็นลำดับขั้น (รอบประเมิน -> ตัวชี้วัดของรอบนั้น
  -> ชนิดหลักฐานของตัวชี้วัดนั้น) ก่อนจะยอมให้อัปโหลดไฟล์จริงได้ ตรงกับฝั่ง
  backend ที่ routes/attachments.js ก็ตรวจสอบลำดับเดียวกันนี้ซ้ำอีกชั้นก่อน
  บันทึกจริง (ฝั่ง frontend เช็กไว้ "ก่อน" เพื่อ UX ที่ดี ฝั่ง backend เช็ก
  "ซ้ำ" อีกทีเพื่อความปลอดภัย เพราะห้ามเชื่อ validation ฝั่ง client อย่าง
  เดียวเด็ดขาด — ผู้ใช้ที่ไม่หวังดีสามารถยิง API ตรง ๆ ข้ามหน้าเว็บไปเลยได้)
-->
<script setup>
definePageMeta({ layout: 'dashboard' })

import { ref, computed, watch, onMounted } from 'vue'
import { useAuthStore } from '~/stores/auth'

const router = useRouter()
const { $api } = useNuxtApp()
const auth = useAuthStore()

/* ---------- state ---------- */
const loadingInit = ref(false)
// true ระหว่างกำลังโหลดข้อมูลประกอบฟอร์มครั้งแรก (รอบประเมิน) ตอนหน้าเพิ่ง
// เปิด — ใช้โชว์ skeleton loader แทนฟอร์มจริงระหว่างรอ
const submitting = ref(false)
// true ระหว่างกำลังอัปโหลดไฟล์ (ปิดปุ่ม Upload ไว้กันกดซ้ำ)
const progress = ref(0)
// เปอร์เซ็นต์ความคืบหน้าของการอัปโหลด (0-100) อัปเดตจาก onUploadProgress
// ของ axios ด้านล่าง

const periods = ref([])
const indicators = ref([])
const evidenceTypes = ref([])
// ข้อมูลประกอบฟอร์มทั้ง 3 ระดับ โหลดแบบ "ลูกโซ่": periods โหลดก่อนเสมอตอน
// หน้าเปิด, indicators โหลดใหม่ทุกครั้งที่เลือก period, evidenceTypes
// โหลดใหม่ทุกครั้งที่เลือก indicator (ดู watch ด้านล่างสุดของสคริปต์)

const form = ref({
  period_id: null,
  indicator_id: null,
  evidence_type_id: null,
  evaluatee_id: '',        // เฉพาะ evaluator; evaluatee จะถูกอิงจาก JWT ฝั่ง server
  note: '',
  file: null
})
// เก็บค่าทั้งฟอร์มไว้ใน object เดียว (ref เดียว) แทนที่จะแยกเป็น ref ย่อย
// หลายตัว — สะดวกตอนรีเซ็ตฟอร์ม/ส่งค่าทั้งก้อนไปแปลงเป็น FormData ตอน submit

const rules = {
  // ชุดฟังก์ชันตรวจสอบของ Vuetify (ใช้กับ prop :rules ของแต่ละ field ใน
  // template) — แต่ละฟังก์ชันรับค่าปัจจุบันของ field แล้วคืน true (ผ่าน)
  // หรือข้อความ error (ไม่ผ่าน)
  required: v => (!!v || v === 0) || 'กรอกข้อมูลให้ครบ',
  // เขียน (!!v || v === 0) เพราะถ้าใช้แค่ !!v เฉย ๆ ค่า 0 (ตัวเลขศูนย์ ซึ่ง
  // เป็นค่าที่ถูกต้องได้ในบางฟิลด์) จะถูกตีว่า falsy แล้วรายงาน error ผิด ๆ
  // ว่า "ไม่ได้กรอก" ทั้งที่กรอกค่า 0 มาจริง ๆ
  select: v => !!v || 'โปรดเลือก',
  file: v => !!v || 'เลือกไฟล์',
  maxMb: mb => v => !v || (v.size <= mb * 1024 * 1024) || `ไฟล์ต้องไม่เกิน ${mb}MB`,
  // maxMb เป็น "ฟังก์ชันที่คืนฟังก์ชัน" (higher-order function) เพราะขนาด
  // สูงสุดที่อนุญาต (mb) เปลี่ยนไปตามชนิดหลักฐานที่เลือก (ดู maxMb
  // computed ด้านล่าง) ต้อง "ส่งค่า mb เข้าไปก่อน" ถึงจะได้ฟังก์ชันตรวจสอบ
  // จริงออกมา เรียกใช้แบบ rules.maxMb(maxMb.value) ใน template
  mimetype: mimes => v => !v || mimes.includes(v.type) || `ชนิดไฟล์ไม่ถูกต้อง (${mimes.join(', ')})`
  // เช่นเดียวกัน mimetype รับลิสต์ mime ที่อนุญาตเข้ามาก่อน แล้วคืนฟังก์ชัน
  // ตรวจสอบจริงออกมา — ทั้งสองฟังก์ชันเช็ก !v ก่อนเสมอ (ถ้ายังไม่มีไฟล์เลย
  // ให้ถือว่า "ผ่าน" เงื่อนไขนี้ไปก่อน ปล่อยให้ rules.file ด้านบนเป็นคนจับ
  // กรณี "ไม่มีไฟล์" แทน ไม่ซ้ำซ้อนกัน)
}

const currentEvType = computed(() =>
  evidenceTypes.value.find(x => x.id === form.value.evidence_type_id) || null
)
// หาว่า "ชนิดหลักฐานที่กำลังเลือกอยู่ตอนนี้" คือ object ไหนในลิสต์
// evidenceTypes (เพื่อเอา max_mb/mime_list ของตัวนั้นมาใช้ด้านล่าง)
const maxMb = computed(() => currentEvType.value?.max_mb ?? 10)
const allowMimes = computed(() => currentEvType.value?.mime_list ?? [
  'application/pdf',
  'image/png', 'image/jpeg', 'image/webp'
])
// ถ้ายังไม่ได้เลือกชนิดหลักฐาน (currentEvType เป็น null) ใช้ค่า default
// (10MB, 4 ชนิดไฟล์พื้นฐาน) ไปพลางก่อน — ค่า default นี้ซ้ำกับค่า default
// ฝั่ง backend ที่ routes/attachments.js ตั้งไว้เช่นกัน (ตอนนี้ backend ยัง
// ส่งค่าเดียวกันให้ทุก evidence_type อยู่ เพราะตารางจริงยังไม่มีข้อมูล
// เฉพาะเจาะจงต่อชนิด — ดูคอมเมนต์ในไฟล์นั้น)

const errorMsg = ref('')
const successMsg = ref('')
const showSnack = ref(false)
// showSnack ควบคุมการแสดง/ซ่อนของ <v-snackbar> ด้านล่าง (ข้อความแจ้งเตือน
// ลอยมุมจอ) — errorMsg ใช้สองที่พร้อมกัน: ทั้งใน <v-alert> หลักของฟอร์ม
// และใน snackbar (ถ้า errorMsg มีค่าตอนที่ showSnack เป็น true)

/* ---------- load master ---------- */
async function init() {
  if (!auth.isLogged) return router.push('/login')
  // เช็กซ้ำอีกชั้น (เหมือนที่ pages/index.vue ทำ) แม้ว่า
  // layouts/dashboard.vue ที่หน้านี้ใช้จะไม่ได้กันไม่ให้ component นี้
  // mount ตอนยังไม่ login ก็ตาม (ต่างจาก layouts/default.vue ที่กันไว้ — ดู
  // หมายเหตุใน layouts/dashboard.vue) การเช็กตรงนี้จึงมีความหมายจริงสำหรับ
  // หน้านี้โดยเฉพาะ ไม่ใช่แค่กันเหนียวเฉย ๆ เหมือนไฟล์อื่น
  loadingInit.value = true
  errorMsg.value = ''
  try {
    const { data: pds } = await $api.get('/api/periods/active')
    periods.value = (pds || []).map(p => ({ ...p, name_th: p.name_th ?? p.name ?? p.title }))
    // ไล่ลำดับหาชื่อที่จะแสดง (name_th ก่อน, ไม่มีค่อยลอง name, แล้วค่อย
    // title) เผื่อ backend คืนโครงสร้างคีย์ไม่ตรงกันเป๊ะ (ดูโค้ด backend
    // ฝั่งเดียวกันที่ routes/attachments.js ก็เขียนไล่ลำดับแบบนี้เหมือนกัน
    // — ทำซ้ำสองชั้นทั้ง backend/frontend เผื่อกรณีใดกรณีหนึ่งเปลี่ยนไป)
    if (periods.value.length) {
      if (!form.value.period_id) form.value.period_id = periods.value[0].id
      // เลือกรอบประเมินแรกในลิสต์ให้อัตโนมัติ (ถ้ายังไม่เคยเลือกมาก่อน) ลด
      // ขั้นตอนให้ผู้ใช้ไม่ต้องมาเลือกเองทุกครั้งถ้ามีรอบเดียวที่เปิดอยู่
      await loadIndicators()
      // ต้องเรียกเองตรงนี้ด้วย เพราะการตั้งค่า form.value.period_id ข้างบน
      // "ไม่ได้" trigger watch(() => form.value.period_id, loadIndicators)
      // ให้ทำงานทันที (watch จะทำงานก็ต่อเมื่อค่าเปลี่ยนแปลง "หลังจาก" ที่
      // watch เริ่มทำงานไปแล้ว ไม่ใช่ตอน set ค่าเริ่มต้นครั้งแรกในฟังก์ชัน
      // เดียวกัน)
    } else {
      errorMsg.value = 'ยังไม่มีรอบการประเมินที่เปิดใช้งาน'
    }
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message
  } finally {
    loadingInit.value = false
  }
}

async function loadIndicators() {
  if (!form.value.period_id) return
  indicators.value = []
  evidenceTypes.value = []
  form.value.indicator_id = null
  form.value.evidence_type_id = null
  // ล้างค่าที่เลือกไว้ของขั้นถัดไปทั้งหมดก่อนโหลดใหม่เสมอ — กันปัญหา
  // "เปลี่ยนรอบประเมินแล้ว แต่ตัวชี้วัดที่เคยเลือกไว้ของรอบเก่ายังค้างอยู่"
  // ซึ่งอาจไม่ใช่ตัวชี้วัดที่มีอยู่จริงในรอบใหม่เลย
  try {
    const { data } = await $api.get('/api/indicators', {
      params: { period_id: form.value.period_id }
    })
    indicators.value = (data || []).map(i => ({ ...i, name_th: i.name_th ?? i.title ?? i.name }))
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message
  }
}

async function loadEvidenceTypes() {
  if (!form.value.indicator_id) return
  evidenceTypes.value = []
  form.value.evidence_type_id = null
  try {
    const { data } = await $api.get(`/api/indicators/${form.value.indicator_id}/evidence-types`)
    evidenceTypes.value = (data || []).map(x => {
      const list =
        Array.isArray(x.mime_list) ? x.mime_list :
        (typeof x.mime_csv === 'string' ? x.mime_csv.split(',').map(s => s.trim()).filter(Boolean) : [])
      // รองรับได้ทั้งกรณี backend ส่ง mime_list มาเป็น array สำเร็จรูปแล้ว
      // หรือส่งมาเป็น mime_csv (string คั่นด้วยคอมมา เช่น
      // "application/pdf,image/png") ก็แปลงเป็น array ให้เองที่นี่ —
      // .filter(Boolean) กันค่าว่างที่เกิดจากคอมมาติดกัน (เช่น "a,,b")
      return { ...x, mime_list: list, max_mb: Number(x.max_mb ?? 10), name_th: x.name_th ?? x.name }
    })
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message
  }
}

/* ---------- submit ---------- */
async function submit() {
  errorMsg.value = ''
  successMsg.value = ''
  showSnack.value = false

  if (!form.value.period_id || !form.value.indicator_id || !form.value.evidence_type_id || !form.value.file) {
    errorMsg.value = 'กรุณากรอกข้อมูลให้ครบ'
    showSnack.value = true
    return
  }
  const f = form.value.file
  if (f && f.size > maxMb.value * 1024 * 1024) {
    errorMsg.value = `ไฟล์ต้องไม่เกิน ${maxMb.value}MB`
    showSnack.value = true
    return
  }
  if (f && !allowMimes.value.includes(f.type)) {
    errorMsg.value = `ชนิดไฟล์ไม่ถูกต้อง (${allowMimes.value.join(', ')})`
    showSnack.value = true
    return
  }
  // เช็กซ้ำเองอีกรอบตรงนี้ (แม้ :rules ของ <v-file-input> ใน template จะ
  // เช็กอยู่แล้วก็ตาม) เผื่อผู้ใช้กดปุ่ม Upload ผ่านทางอื่นที่ข้าม validation
  // ของ Vuetify ไปได้ (เช่นเรียกฟังก์ชัน submit() ตรง ๆ ผ่าน DevTools) — นี่
  // คือ validation "ชั้นที่สอง" ฝั่ง frontend ก่อนจะยิง request จริง ส่วน
  // ชั้นที่สาม (เข้มงวดที่สุด) คือฝั่ง backend ที่ไม่มีทางถูกข้ามได้เลย

  const fd = new FormData()
  // FormData คือรูปแบบข้อมูลที่จำเป็นต้องใช้เวลาจะส่งไฟล์ไปกับ HTTP request
  // (multipart/form-data) ต่างจากการส่ง JSON ธรรมดาที่ใส่ไฟล์ลงไปตรง ๆ
  // ไม่ได้ (ไฟล์เป็น binary data ไม่ใช่ข้อความ)
  fd.append('period_id', form.value.period_id)
  fd.append('indicator_id', form.value.indicator_id)
  fd.append('evidence_type_id', form.value.evidence_type_id)
  if (auth.role === 'evaluator' && form.value.evaluatee_id) {
    fd.append('evaluatee_id', form.value.evaluatee_id)
  }
  // ส่ง evaluatee_id เพิ่มเฉพาะตอนที่ผู้ใช้ปัจจุบันเป็น evaluator และกรอก
  // ค่านี้มา (ดู backend/routes/attachments.js -> role === 'evaluator' จะ
  // "ต้องมี" ค่านี้ ถ้าไม่ส่งมาจะโดน 422) ถ้าเป็น evaluatee เองไม่ต้องส่ง
  // เลย (backend จะใช้ id จาก JWT token แทนอัตโนมัติ)
  if (form.value.note) fd.append('note', form.value.note)
  fd.append('file', form.value.file)
  // ชื่อ field ของไฟล์ต้องเป็น "file" ให้ตรงกับที่
  // backend/middlewares/upload.js (multer) คาดหวังไว้เป๊ะ

  submitting.value = true
  progress.value = 0
  try {
    await $api.post('/api/attachments', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
      // ต้องเขียนทับ header เริ่มต้นของ $api (ที่ตั้งเป็น
      // 'application/json' ไว้ใน plugins/axios.client.js) เป็น
      // 'multipart/form-data' เฉพาะ request นี้ ไม่งั้น backend จะอ่าน
      // body ผิดรูปแบบ
      onUploadProgress: (ev) => { if (ev.total) progress.value = Math.round((ev.loaded * 100) / ev.total) }
      // onUploadProgress คือ callback ของ axios ที่ถูกเรียกเป็นระยะระหว่าง
      // กำลังส่งข้อมูลขึ้นไป (ev.loaded = ส่งไปแล้วกี่ byte, ev.total = ขนาด
      // รวมทั้งหมดกี่ byte) คำนวณเป็นเปอร์เซ็นต์ไว้ที่ progress เพื่อแสดงผล
      // แถบความคืบหน้าใน template — if (ev.total) กันกรณี ev.total ไม่มีค่า
      // (บางสถานการณ์เบราว์เซอร์คำนวณขนาดรวมไม่ได้ล่วงหน้า)
    })
    successMsg.value = 'อัปโหลดสำเร็จ'
    showSnack.value = true
    resetFormKeepMaster()
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message || 'Upload failed'
    showSnack.value = true
  } finally {
    submitting.value = false
    setTimeout(() => (progress.value = 0), 600)
    // รอ 600ms ก่อนรีเซ็ตแถบ progress กลับเป็น 0 (ไม่รีเซ็ตทันที) เพื่อให้
    // ผู้ใช้เห็นแถบวิ่งไปจนสุด (100%) ก่อนสักครู่หนึ่ง ไม่ใช่กระพริบหายไป
    // ทันทีที่ request เสร็จ ดูเป็นธรรมชาติกว่า
  }
}

function resetFormKeepMaster() {
  form.value.file = null
  form.value.note = ''
  // รีเซ็ตแค่ "ไฟล์" กับ "หมายเหตุ" หลังอัปโหลดสำเร็จ แต่ "คงค่า" รอบ
  // ประเมิน/ตัวชี้วัด/ชนิดหลักฐานที่เลือกไว้เดิม (ไม่รีเซ็ตทั้งฟอร์ม) — เพราะ
  // ผู้ใช้มักจะอัปโหลดหลายไฟล์ติดกันให้ตัวชี้วัดเดิมหรือใกล้เคียงกัน ไม่ต้อง
  // มาเลือกรอบประเมิน/ตัวชี้วัดใหม่ทุกครั้งที่อัปโหลดเสร็จ 1 ไฟล์
}

watch(() => form.value.period_id, loadIndicators)
watch(() => form.value.indicator_id, loadEvidenceTypes)
// watch(() => form.value.xxx, ...) (ไม่ใช่ watch(form, ...) ตรง ๆ) คือการ
// "watch เฉพาะ field เดียว" ของ object form — ใช้ getter function
// (() => form.value.period_id) แทนที่จะ watch ทั้ง object เพราะอยากให้
// callback ทำงานเฉพาะตอน period_id เปลี่ยนจริง ๆ เท่านั้น ไม่ใช่ทุกครั้งที่
// field ไหนก็ตามในฟอร์มเปลี่ยน (ถ้า watch ทั้ง object แบบ deep จะ trigger
// ทุกครั้งที่พิมพ์ในช่อง note ด้วย ซึ่งไม่ควรไปโหลด indicators ใหม่)
watch(() => form.value.file, () => { if (errorMsg.value) errorMsg.value = '' })
// เคลียร์ error message เก่าทิ้งทันทีที่ผู้ใช้เลือกไฟล์ใหม่ (ให้ผู้ใช้รู้สึก
// ว่าระบบ "ลืม" error เก่าไปแล้วเมื่อเริ่มแก้ไขใหม่ ไม่ใช่ error ค้างเก่าที่
// อาจไม่เกี่ยวกับไฟล์ที่เพิ่งเลือก)

onMounted(init)
</script>

<template>
  <div class="container mx-auto px-4 py-6">
    <div class="flex items-center justify-between mb-4">
      <h1 class="text-xl font-semibold">Upload Evidence</h1>
      <NuxtLink to="/users">
        <v-btn variant="text">Back</v-btn>
      </NuxtLink>
    </div>

    <v-card>
      <v-card-text>
        <v-alert v-if="errorMsg" type="error" variant="tonal" class="mb-4">{{ errorMsg }}</v-alert>
        <v-skeleton-loader v-if="loadingInit" type="article" class="mb-4"/>
        <!-- <v-skeleton-loader> คือกล่องเทา ๆ เคลื่อนไหว (loading placeholder)
             แสดงแทนฟอร์มจริงระหว่างที่ loadingInit เป็น true — ดีกว่าแสดง
             ฟอร์มเปล่า ๆ ที่ยังไม่มีข้อมูล (periods) ให้เลือกค้างไว้เฉย ๆ -->

        <div v-else class="grid md:grid-cols-2 gap-6">
          <div>
            <v-select
              v-model="form.period_id"
              :items="periods"
              item-title="name_th"
              item-value="id"
              label="รอบการประเมิน (Period)"
              :rules="[rules.select]"
              density="comfortable" class="mb-3" clearable
            />
            <v-select
              v-model="form.indicator_id"
              :items="indicators"
              :item-title="(i)=> i.code ? `${i.code} — ${i.name_th}` : i.name_th"
              item-value="id"
              label="ตัวชี้วัด (Indicator)"
              :rules="[rules.select]"
              density="comfortable" class="mb-3" clearable
              :disabled="!form.period_id || !periods.length"
            />
            <!-- item-title รับได้ทั้ง string (ชื่อ field ตรง ๆ) หรือ
                 function (คำนวณข้อความที่จะแสดงเอง) — ที่นี่ใช้ function
                 เพื่อต่อ code กับ name_th เข้าด้วยกัน (ถ้ามี code) เช่น
                 "T1-PLAN — แผนการจัดการเรียนรู้" อ่านง่ายกว่าแสดงแค่ชื่อ
                 เฉย ๆ -->
            <v-select
              v-model="form.evidence_type_id"
              :items="evidenceTypes"
              item-title="name_th"
              item-value="id"
              label="ชนิดหลักฐาน (Evidence Type)"
              :rules="[rules.select]"
              density="comfortable" class="mb-3" clearable
              :disabled="!form.indicator_id"
              hint="ระบบจะตรวจชนิดไฟล์และขนาดตามชนิดหลักฐานนี้"
              persistent-hint
            />
            <v-text-field
              v-if="auth.role === 'evaluator'"
              v-model="form.evaluatee_id"
              label="Evaluatee ID (กรณีอัปโหลดแทน)"
              density="comfortable" class="mb-3"
              hint="ต้องเป็นคู่ที่ถูกมอบหมายในงวดนี้" persistent-hint
            />
            <!-- field นี้แสดงเฉพาะตอน role เป็น evaluator เท่านั้น
                 (evaluatee ไม่เห็น field นี้เลย เพราะอัปโหลดของตัวเองไม่
                 ต้องระบุ id ของใคร) -->
            <v-textarea v-model="form.note" label="หมายเหตุ/คำอธิบายไฟล์ (ไม่บังคับ)"
              auto-grow rows="2" density="comfortable" class="mb-3"/>
          </div>

          <div>
            <v-file-input
              v-model="form.file"
              :accept="allowMimes.length ? allowMimes.join(',') : '*/*'"
              label="เลือกไฟล์หลักฐาน" prepend-icon="mdi-paperclip"
              :rules="[rules.file, rules.maxMb(maxMb), rules.mimetype(allowMimes)]"
              density="comfortable" show-size
            />
            <!-- :accept คือ attribute มาตรฐานของ <input type="file"> บอก
                 เบราว์เซอร์ว่าควร "กรองให้เห็น" เฉพาะไฟล์ชนิดไหนในหน้าต่าง
                 เลือกไฟล์ (เป็นแค่ UI hint ช่วยผู้ใช้เท่านั้น ไม่ใช่การบังคับ
                 จริงจัง — ผู้ใช้ยังเลือกไฟล์ชนิดอื่นได้ถ้าตั้งใจ ต้องพึ่ง
                 rules.mimetype ด้านบนเป็นคนบังคับจริงอีกที) -->
            <v-alert variant="tonal" type="info" class="mt-3">
              <div class="text-sm">
                <div><strong>ชนิดไฟล์ที่อนุญาต:</strong> {{ allowMimes.length ? allowMimes.join(', ') : 'ยังไม่ระบุ (โปรดเลือกชนิดหลักฐาน)' }}</div>
                <div><strong>ขนาดสูงสุด:</strong> {{ maxMb || 0 }} MB</div>
                <div v-if="form.file" class="mt-2">
                  <strong>ตัวอย่างเมตาดาต้าไฟล์:</strong>
                  <ul class="list-disc ml-6">
                    <li>ชื่อไฟล์: {{ form.file.name }}</li>
                    <li>MIME: {{ form.file.type || 'unknown' }}</li>
                    <li>ขนาด: {{ (form.file.size/1024/1024).toFixed(2) }} MB</li>
                  </ul>
                </div>
              </div>
            </v-alert>
          </div>
        </div>

        <v-divider class="my-6" />
        <div class="flex items-center gap-3">
          <v-btn color="primary"
            :disabled="submitting || !periods.length || !form.period_id || !form.indicator_id || !form.evidence_type_id || !form.file"
            @click="submit">Upload</v-btn>
          <v-progress-linear v-if="submitting || progress>0" :model-value="progress" height="6" striped class="flex-1"/>
        </div>
      </v-card-text>
    </v-card>

    <v-snackbar v-model="showSnack" :timeout="3000" location="bottom right">
      <div v-if="successMsg">{{ successMsg }}</div>
      <div v-else>{{ errorMsg }}</div>
      <template #actions>
        <v-btn variant="text" @click="showSnack=false">ปิด</v-btn>
      </template>
    </v-snackbar>
  </div>
</template>
