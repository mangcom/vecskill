<!-- pages/users/[id].vue -->
<!--
  ฟอร์มแก้ไขผู้ใช้ — ชื่อไฟล์ที่มี [id] อยู่ในชื่อ (ในวงเล็บเหลี่ยม) คือ
  "dynamic route" ของ Nuxt หมายความว่าไฟล์นี้จะตอบ URL รูปแบบ /users/<ค่า
  อะไรก็ได้> เช่น /users/5, /users/12 ค่าที่แทนตำแหน่ง [id] จะถูกดึงออกมา
  ผ่าน route.params.id (ดูในสคริปต์ด้านล่าง) ไม่ได้ใช้ layout พิเศษ (ไม่มี
  definePageMeta) จึงใช้ layouts/default.vue เป็นค่าเริ่มต้น
-->
<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'
import { useAuthStore } from '~/stores/auth'
import { useForm, useField } from 'vee-validate'
import * as yup from 'yup'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()

const id = computed(() => route.params.id)
// route.params.id คือค่าดิบจาก URL (string เสมอ เช่น "5") — ใช้ computed
// เผื่อ route เปลี่ยนพารามิเตอร์โดยไม่ unmount/remount component ใหม่ (เช่น
// กดลิงก์จาก /users/5 ไป /users/7 ตรง ๆ โดยไม่ผ่านหน้าอื่นก่อน)
const errorMsg = ref('')
const loading = ref(false)

/* ✅ 1) แก้ schema ให้รองรับ evaluatee */
const schema = yup.object({
  name: yup.string().required('กรอกชื่อ'),
  email: yup.string().email('อีเมลไม่ถูกต้อง').required('กรอกอีเมล'),
  role: yup.string().oneOf(['evaluatee', 'evaluator', 'admin'], 'เลือกบทบาทให้ถูกต้อง').required('เลือกบทบาท')
})
// หมายเหตุ: field ในฟอร์มนี้ชื่อ "name" (ภาษาอังกฤษสั้น ๆ) แต่คอลัมน์จริงใน
// ฐานข้อมูลคือ "name_th" — ไฟล์นี้ต้อง "map ชื่อ field ไป-กลับ" เองระหว่าง
// ฟอร์ม (name) กับ API/ฐานข้อมูล (name_th) ดูจุด map ทั้งสองทิศทางด้านล่าง

/* ฟอร์ม */
const { handleSubmit, setValues } = useForm({ validationSchema: schema })
const { value: name,  errorMessage: nameErr }  = useField('name')
const { value: email, errorMessage: emailErr } = useField('email')
const { value: role,  errorMessage: roleErr }  = useField('role')

/* ใช้ items แบบมี label/value จะอ่านง่ายและกันพิมพ์ผิด */
const roleItems = [
  { title: 'Evaluatee', value: 'evaluatee' },
  { title: 'Evaluator', value: 'evaluator' },
  { title: 'Admin',     value: 'admin' }
]
// ใช้กับ <v-select :items="roleItems" item-title="title" item-value="value">
// — แยก title (ข้อความที่ผู้ใช้เห็น) ออกจาก value (ค่าจริงที่ส่งไป backend)
// ชัดเจน กันกรณีอยากเปลี่ยนข้อความที่แสดง (เช่นเป็นภาษาไทย) โดยไม่กระทบค่า
// role จริงที่ backend ต้องรับ (ต้องตรงกับ enum ที่ schema.sql กำหนดไว้เป๊ะ)

onMounted(async () => {
  // โหลดข้อมูลผู้ใช้คนที่จะแก้ไข มาเติมใส่ฟอร์มทันทีที่หน้าเปิดขึ้นมา
  try {
    loading.value = true
    const res = await axios.get(`${useApiBase()}/api/users/${id.value}`, {
      headers: { Authorization: `Bearer ${auth.token}` }
    })
    // หมายเหตุ: ไฟล์นี้เรียก axios ตรง ๆ (import axios from 'axios') พร้อม
    // คำนวณ URL เองด้วย useApiBase() + แนบ token เองด้วย auth.token ตรง ๆ
    // แทนที่จะใช้ $api (plugins/axios.client.js) ที่ทำทั้งสองอย่างนี้ให้
    // อัตโนมัติอยู่แล้ว (ดูตัวอย่างที่ pages/login.vue, index.vue,
    // users/new.vue ใช้) — วิธีนี้ "ไม่ใช่บั๊ก" เพราะ useApiBase() คำนวณ
    // host ถูกต้องอยู่แล้วเหมือนกัน (ปัญหาเรื่องเปิดผ่าน host อื่นแล้วใช้
    // งานไม่ได้จะไม่เกิดกับไฟล์นี้) แต่เป็นแนวทางที่ไม่สอดคล้องกับไฟล์อื่น
    // ในแอป ถ้าจะต่อยอดให้เขียนโค้ดสม่ำเสมอกันทั้งระบบ ลองเปลี่ยนมาใช้ $api
    // แบบเดียวกับไฟล์อื่นได้
    const u = res.data.data
    setValues({
      /* ✅ 2) map name_th -> name สำหรับแสดงผล */
      name:  u.name_th ?? '',
      email: u.email   ?? '',
      role:  u.role    ?? 'evaluatee'
    })
    // setValues(...) ของ vee-validate เติมค่าเริ่มต้นให้ทุก field พร้อมกัน
    // ในครั้งเดียว — ใช้ ?? '' กันกรณี backend ส่งค่าใดมาเป็น null/undefined
    // (ไม่งั้น field จะกลายเป็น "undefined" ตัวหนังสือจริง ๆ ในกล่อง input)
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message || 'Load failed'
  } finally {
    loading.value = false
  }
})

/* ✅ 3) ตอนอัปเดต map กลับเป็น name_th ให้ backend */
const onSubmit = handleSubmit(async (values) => {
  // ถูกเรียกก็ต่อเมื่อ validate ผ่านครบตาม schema แล้ว (values = { name,
  // email, role } ตามชื่อ field ในฟอร์ม)
  try {
    loading.value = true
    await axios.put(
      `${useApiBase()}/api/users/${id.value}`,
      { name_th: values.name, email: values.email, role: values.role },
      // map "name" (ชื่อ field ในฟอร์ม) กลับไปเป็น "name_th" (ชื่อคอลัมน์
      // จริงที่ backend คาดหวัง — ดู backend/controllers/users.controller.js
      // -> update) ก่อนส่งออกไปเสมอ
      { headers: { Authorization: `Bearer ${auth.token}`, 'Content-Type': 'application/json' } }
    )
    router.push('/')
    // แก้ไขสำเร็จ กลับไปหน้ารายชื่อผู้ใช้
  } catch (e) {
    errorMsg.value = e.response?.data?.message || e.message || 'Update failed'
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div class="container mx-auto px-4 py-6 max-w-xl">
    <v-card>
      <v-card-title>Edit User #{{ id }}</v-card-title>
      <v-card-text>
        <form class="flex flex-col gap-4" @submit.prevent="onSubmit">
          <v-text-field v-model="name"  label="Name"  :error-messages="nameErr ? [nameErr] : []" />
          <v-text-field v-model="email" label="Email" :error-messages="emailErr ? [emailErr] : []" />
          <!-- :error-messages รับ array ของข้อความ error — ใส่ [nameErr]
               ตอนมี error (nameErr ไม่ใช่ falsy) หรือ array ว่าง [] ตอนไม่มี
               error เลย (Vuetify ต้องการ array เสมอ ไม่รับ string/null
               ตรง ๆ) -->
          <!-- ✅ ใช้ items แบบ object และ schema ตรงกับ evaluatee -->
          <v-select
            v-model="role"
            :items="roleItems"
            item-title="title"
            item-value="value"
            label="Role"
            :error-messages="roleErr ? [roleErr] : []"
          />
          <v-alert v-if="errorMsg" type="error" variant="tonal">{{ errorMsg }}</v-alert>
          <v-card-actions class="px-0">
            <v-spacer />
            <NuxtLink to="/"><v-btn variant="text">Back</v-btn></NuxtLink>
            <v-btn :loading="loading" color="primary" type="submit">Save</v-btn>
          </v-card-actions>
        </form>
      </v-card-text>
    </v-card>
  </div>
</template>
