<!-- pages/users/new.vue -->
<!--
  ฟอร์มสร้างผู้ใช้ใหม่ (เฉพาะ admin เรียกใช้ได้จริง — ดู backend
  routes/users.routes.js ที่จำกัด POST /api/users ไว้แค่ role admin)
  ไม่ได้ใช้ layout พิเศษใด ๆ (ไม่มี definePageMeta เลย) จึงใช้
  layouts/default.vue เป็นค่าเริ่มต้น
-->
<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" sm="8" md="5" lg="4">
        <v-card class="pa-6 elevation-6">
          <v-card-title class="text-h6 text-center"> Create User </v-card-title>

          <v-card-text>
            <v-form
              @submit.prevent="handleSubmit"
              class="d-flex flex-column ga-4"
            >
              <!-- <v-form> ของ Vuetify คล้าย <form> ธรรมดา แต่เพิ่ม
                   ความสามารถ validate ฟิลด์ลูกทั้งหมดในตัวได้ (ไม่ได้ใช้
                   ความสามารถนั้นในไฟล์นี้ — ใช้แค่ :rules/required ของแต่ละ
                   field เป็น UI hint เฉย ๆ ไม่ได้บังคับห้าม submit จริงถ้า
                   ข้อมูลไม่ครบ ต่างจาก pages/login.vue ที่ผูกกับ
                   vee-validate ทำให้บังคับ validate ก่อน submit จริง ๆ) -->
              <v-text-field
                label="Name"
                v-model="vals.name_th"
                variant="outlined"
                clearable
                required
              />

              <v-text-field
                label="Email"
                type="email"
                v-model="vals.email"
                variant="outlined"
                clearable
                required
              />

              <!-- ✅ ช่อง Password ที่สามารถแสดง/ซ่อน -->
              <v-text-field
                :type="showPassword ? 'text' : 'password'"
                label="Password"
                v-model="vals.password"
                variant="outlined"
                clearable
                required
                :append-inner-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'"
                @click:append-inner="showPassword = !showPassword"
              />

              <v-select
                label="Role"
                v-model="vals.role"
                :items="roles"
                variant="outlined"
                required
              />

              <v-alert
                v-if="errorMsg"
                type="error"
                variant="tonal"
                class="mt-2"
              >
                {{ errorMsg }}
              </v-alert>

              <div class="d-flex justify-end mt-4">
                <v-btn
                  variant="tonal"
                  color="grey"
                  class="mr-2"
                  @click="router.back()"
                >
                  Cancel
                </v-btn>
                <!-- เปลี่ยนเป็นคลิกตรงๆ และให้ type=button -->
                <v-btn
                  type="button"
                  color="primary"
                  variant="flat"
                  @click="handleSubmit"
                >
                  <!-- type="button" (ไม่ใช่ "submit") ตั้งใจ: เพราะปุ่มนี้
                       เรียก handleSubmit() ตรง ๆ ผ่าน @click อยู่แล้ว ถ้าปล่อย
                       เป็น type="submit" แบบ default ของปุ่มใน <form>/<v-form>
                       จะเกิดการ submit ฟอร์มซ้ำสองครั้ง (ทั้งจาก @click และ
                       จาก native form submit event) -->
                  Save
                </v-btn>
              </div>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";

const router = useRouter();
const errorMsg = ref("");
const showPassword = ref(false); // ✅ state สำหรับ toggle แสดง/ซ่อนรหัสผ่าน

const { $api } = useNuxtApp();
// ใช้ axios instance กลางของแอป (ดู plugins/axios.client.js) แทนการสร้าง
// axios instance ของตัวเองพร้อม URL คงที่ + อ่าน token จาก localStorage เอง
// (แก้ไข: โค้ดเดิมยิงตรงไปที่ "http://localhost:7000/api/users" แบบ
// hardcode ซึ่งใช้ไม่ได้ทันทีที่เปิดแอปผ่าน host อื่นที่ไม่ใช่ localhost —
// เช่น 127.0.0.1, IP วง LAN, หรือโดเมนจริง ต่างจากทุกหน้าอื่นในแอปนี้
// [login.vue, index.vue, upload.vue] ที่เรียกผ่าน $api ซึ่งคำนวณ baseURL
// แบบไดนามิกให้อัตโนมัติอยู่แล้ว การสลับมาใช้ $api จึงแก้บั๊กนี้ และทำให้
// การแนบ Authorization token เป็นไปโดยอัตโนมัติด้วย ไม่ต้องอ่าน
// localStorage เองตรงนี้อีกต่อไป)

const vals = ref({
  name_th: "",
  email: "",
  password: "",
  role: "evaluatee",
});

const roles = ["evaluatee", "evaluator", "admin"];
const handleSubmit = async () => {
  try {
    await $api.post("/api/users", {
      name_th: vals.value.name_th,
      email: vals.value.email,
      password: vals.value.password,
      role: vals.value.role,
    });
    // ไม่ต้องตั้ง header Authorization/Content-Type เองแล้ว — $api
    // (plugins/axios.client.js) ใส่ 'Content-Type: application/json' เป็น
    // ค่าเริ่มต้นให้อยู่แล้ว และแนบ Authorization: Bearer <token> ให้
    // อัตโนมัติผ่าน request interceptor ถ้ามี token อยู่ (ดูไฟล์นั้น)
    router.push("/");
    // สร้างสำเร็จ กลับไปหน้ารายชื่อผู้ใช้ (หน้าแรก "/")
  } catch (e) {
    errorMsg.value = e?.response?.data?.message || e.message || "Create failed";
  }
};

defineExpose({ vals, errorMsg, handleSubmit });
// เปิดให้เทสต์ (tests/users.new.spec.ts) เข้าถึง vals/errorMsg/handleSubmit
// ผ่าน wrapper.vm ได้ — ดูเหตุผลเดียวกันที่ pages/login.vue
</script>
