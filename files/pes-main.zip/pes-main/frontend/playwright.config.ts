// playwright.config.ts
//
// ไฟล์ตั้งค่าของ Playwright — ไลบรารีที่ใช้ทำ "E2E test" (End-to-End test)
// ต่างจาก Vitest (tests/*.spec.ts, ดู vitest.config.ts) ตรงที่ Playwright
// จะเปิด "เบราว์เซอร์จริง" (Chromium ในที่นี้) แล้วคลิก/พิมพ์/อ่านหน้าเว็บ
// เหมือนผู้ใช้จริงทำเอง ผ่าน URL จริง — ไม่ได้ mount component เดี่ยว ๆ ใน
// jsdom เหมือน Vitest ทำ ดังนั้น E2E test จึงต้องการ "สแตคที่รันอยู่จริง"
// (frontend + backend + ฐานข้อมูล seed ไว้แล้ว) ก่อนรันเทสต์เสมอ ไม่เหมือน
// Vitest ที่ mount component ลอย ๆ ได้โดยไม่ต้องมี server ใด ๆ
//
// ตรงกับหัวข้อ 3.4.2.8 ของเกณฑ์การแข่งขัน (Playwright อยู่ในลิสต์ package ที่
// อนุญาต) และหัวข้อ 4.6 "มี E to E Test เป็นการทดสอบ Work flow ตั้งแต่เริ่ม
// จนจบ" — ไฟล์ e2e/login.e2e.spec.ts และ e2e/upload.e2e.spec.ts คือตัวอย่าง
// สองกรณี (เทียบเท่า E2E-001 และ E2E-002 ในตัวอย่างของเกณฑ์) ให้ดูเป็นแนวทาง
//
// วิธีรัน: ต้องมีสแตคทั้งหมดรันอยู่แล้วก่อน (docker compose up -d — ดู README.md) แล้วค่อยรัน `npm run test:e2e` จากโฟลเดอร์
// frontend/ (ใช้ `npm run test:e2e:ui` ถ้าอยากเห็นเบราว์เซอร์ทำงานแบบ
// step-by-step ผ่านหน้าต่าง Playwright UI ช่วย debug)

import { defineConfig, devices } from '@playwright/test'

export default defineConfig({
  testDir: './e2e',
  // โฟลเดอร์ที่เก็บไฟล์เทสต์ E2E ทั้งหมด — แยกจาก tests/ (ที่เก็บเทสต์แบบ
  // mount component ของ Vitest) ให้ชัดเจนว่าเป็นคนละชนิดของเทสต์กัน

  timeout: 30_000,
  // แต่ละ test case มีเวลาไม่เกิน 30 วินาที (รวมเวลารอหน้าเว็บโหลด/รอ API
  // ตอบกลับด้วย) ถ้าเกินถือว่าเทสต์ล้มเหลว (ไม่ใช่ค้างรอตลอดไป)

  fullyParallel: false,
  workers: 1,
  // ปิดการรันเทสต์แบบขนานทั้งหมด (ทั้ง fullyParallel: false สำหรับภายในไฟล์
  // เดียวกัน และ workers: 1 สำหรับข้ามไฟล์ด้วย) — เหตุผลมี 2 ข้อ: (1)
  // เทสต์ในไฟล์นี้ใช้ข้อมูล seed เดียวกันในฐานข้อมูลจริง (ไม่ได้ mock) การรัน
  // พร้อมกันหลาย worker อาจชนข้อมูลกันได้ (2) frontend รันด้วย `nuxt dev`
  // (dev server ที่ compile แบบ on-demand ไม่ใช่ build สำเร็จรูปแบบ
  // production) ถ้ามีหลาย worker เปิดหลายแท็บพร้อมกันยิงใส่ dev server ตัว
  // เดียวพร้อมกัน จะทำให้ compile ช้าลงมากจนเทสต์ timeout ได้ (เจอปัญหานี้จริง
  // ตอนพัฒนาไฟล์นี้ — รันพร้อมกัน 2 worker ทำให้ทั้งสองเทสต์ timeout ไปด้วย)

  retries: 0,
  // ไม่ retry อัตโนมัติถ้าเทสต์ล้มเหลว — อยากเห็น error จริงทันทีตอนเรียน
  // รู้ ไม่อยากให้ retry บังปัญหาจริงไว้

  reporter: [['list']],
  // แสดงผลลัพธ์แบบรายการ (list) ใน terminal ตรง ๆ อ่านง่ายสำหรับตัวอย่างสอน

  use: {
    baseURL: process.env.E2E_BASE_URL || 'http://localhost:3000',
    // URL ตั้งต้นของแอปที่จะทดสอบ — ดีฟอลต์คือ frontend ที่รันผ่าน docker
    // compose บนเครื่องเดียว (พอร์ตมาจาก FRONTEND_PORT ใน .env — ถ้าคุณ
    // เปลี่ยนพอร์ตไว้ ให้ตั้งตัวแปรสภาพแวดล้อม E2E_BASE_URL ให้ตรงกันก่อนรัน
    // เช่น $env:E2E_BASE_URL="http://localhost:3001"; npm run test:e2e)
    trace: 'retain-on-failure',
    // เก็บ "trace" (บันทึกทุก action + screenshot + network ระหว่างเทสต์)
    // ไว้เฉพาะตอนเทสต์ล้มเหลวเท่านั้น (ไม่เก็บทุกครั้งเปลืองพื้นที่เปล่า ๆ)
    // เปิดดูด้วยคำสั่ง `npx playwright show-trace <ไฟล์ trace.zip>`
    screenshot: 'only-on-failure',
    // ถ่ายภาพหน้าจอ ณ จุดที่เทสต์ล้มเหลวไว้ด้วย ช่วยดูว่าตอนพังหน้าเว็บ
    // หน้าตาเป็นยังไง
  },

  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    // รันด้วย Chromium เบราว์เซอร์เดียวพอสำหรับตัวอย่างสอน (Playwright
    // รองรับ Firefox/WebKit ด้วย แต่ไม่จำเป็นต้องรันครบทุกเบราว์เซอร์สำหรับ
    // การสาธิตแนวคิด E2E test)
  ],
})
