// ~/plugins/auth-init.client.js
//
// "Nuxt plugin" คือโค้ดที่รันครั้งเดียวตอนแอป "เริ่มทำงาน" (ก่อนหน้าไหนจะ
// render เลยด้วยซ้ำ) ชื่อไฟล์ที่ลงท้ายด้วย ".client.js" บอก Nuxt ว่าปลั๊กอิน
// นี้ให้รันเฉพาะฝั่ง client (เบราว์เซอร์) เท่านั้น ไม่ต้องพยายามรันฝั่ง
// เซิร์ฟเวอร์เลย (เหมาะกับปลั๊กอินนี้เพราะ localStorage มีแค่ฝั่งเบราว์เซอร์)
//
// หน้าที่ของไฟล์นี้: ทันทีที่แอปเปิดขึ้นมา (refresh หน้าเว็บ/เปิดแท็บใหม่)
// ให้ไป "กู้คืน" สถานะ login ที่เคยบันทึกไว้ใน localStorage กลับเข้า Pinia
// store ก่อนที่หน้าไหนจะเริ่ม render — ถ้าไม่มีปลั๊กอินนี้ ทุกครั้งที่
// refresh หน้าเว็บ auth store จะว่างเปล่าเสมอ (เหมือน logout ไปแล้ว) ทั้งที่
// จริง ๆ ผู้ใช้ login ค้างอยู่ (token ยังไม่หมดอายุ)
export default defineNuxtPlugin(() => {
  const auth = useAuthStore()
  // useAuthStore ถูก auto-import ให้โดย module @pinia/nuxt (ดู
  // nuxt.config.ts) ไม่ต้อง import เอง
  auth.hydrateFromStorage()
  // เรียก action ของ store (ดูรายละเอียดจริงใน stores/auth.js) ที่อ่านค่า
  // token/user ที่เคยเก็บไว้ใน localStorage กลับมาใส่ไว้ใน state ของ store
  // ให้ตรงกับก่อนหน้าที่ refresh หน้าเว็บ
})
