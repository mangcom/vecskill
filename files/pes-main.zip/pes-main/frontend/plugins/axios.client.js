// plugins/axios.client.js
//
// ไฟล์นี้สร้าง axios instance "กลางตัวเดียว" ให้ทั้งแอปใช้ร่วมกัน (เรียกผ่าน
// useNuxtApp().$api — ดูตัวอย่างใน pages/upload.vue) แทนที่จะ import axios
// มาสร้าง instance ใหม่เองทุกไฟล์ ข้อดีคือการตั้งค่า (baseURL, timeout, การ
// แนบ token อัตโนมัติ) ทำครั้งเดียวที่นี่ที่เดียว ทุกหน้าที่เรียก $api ได้
// พฤติกรรมเดียวกันหมด ไม่ต้องเขียนซ้ำ

import axios from 'axios'
import { useAuthStore } from '~/stores/auth'

export default defineNuxtPlugin((nuxtApp) => {
  const auth = useAuthStore()

  const api = axios.create({
    baseURL: useApiBase(),
    // ใช้ composable useApiBase() (ดู composables/useApiBase.js) คำนวณ URL
    // ของ backend แบบไดนามิกจาก host ที่เปิดหน้าเว็บอยู่ตอนนี้ — เรียกตรงนี้
    // "ครั้งเดียว" ตอนสร้าง axios instance (ตอนแอปเริ่มทำงาน) ไม่ได้คำนวณ
    // ใหม่ทุก request เพราะ host ที่เปิดเว็บไม่เปลี่ยนระหว่างที่แอปทำงานอยู่
    timeout: 15000,
    // ถ้า request ไหนใช้เวลานานเกิน 15 วินาทียังไม่ได้คำตอบ ให้ถือว่า
    // timeout แล้ว โยน error ออกมา (กันไม่ให้หน้าเว็บค้างรอ response ไม่มี
    // ที่สิ้นสุดถ้า backend ไม่ตอบ)
    headers: { 'Content-Type': 'application/json' },
    // ค่าเริ่มต้นของทุก request คือส่งข้อมูลแบบ JSON — หมายเหตุ: ตอน
    // pages/upload.vue ส่งไฟล์ (FormData) จะ "เขียนทับ" header นี้เป็น
    // 'multipart/form-data' เองเฉพาะ request นั้น (ดูใน upload.vue) ไม่ได้
    // ใช้ค่าเริ่มต้นนี้
    withCredentials: false
    // ไม่ส่ง cookie ติดไปกับ request ข้าม origin (ระบบนี้ใช้ JWT เก็บใน
    // localStorage + แนบผ่าน header เอง ไม่ได้พึ่งกลไก cookie/session ของ
    // เบราว์เซอร์เลย จึงไม่จำเป็นต้องเปิดค่านี้)
  })

  // ✅ แนบ token ทุกครั้งที่ request
  api.interceptors.request.use((req) => {
    // "interceptor" คือจุดที่ axios ให้เรา "ดักแก้ไข" request/response ได้
    // ก่อนที่มันจะถูกส่งออกไปจริง (request interceptor) หรือก่อนที่โค้ดที่
    // เรียกใช้งานจะได้รับ response กลับไป (response interceptor ด้านล่าง)
    // รองรับทั้งจาก store และ localStorage
    const token =
      auth.token ||
      localStorage.getItem('auth_token') ||
      localStorage.getItem('accessToken')
    // ลองดึง token จากหลายแหล่งไล่ลำดับ: จาก Pinia store ก่อน (เร็วที่สุด
    // ไม่ต้องอ่าน localStorage ถ้ามีอยู่ใน memory แล้ว) ถ้าไม่มีค่อยลองอ่าน
    // จาก localStorage โดยตรงสองชื่อ key ที่ต่างกัน (auth_token คือ key ที่
    // stores/auth.js ใช้จริงตอนนี้ ส่วน accessToken เป็น key ชื่อเก่า/ทาง
    // เลือกสำรอง เผื่อมีโค้ดส่วนอื่นเคยเขียนด้วยชื่อ key นี้ไว้)

    if (token) {
      req.headers = req.headers || {}
      req.headers.Authorization = `Bearer ${token}`
      // แนบ header Authorization แบบ "Bearer <token>" ตามมาตรฐานที่
      // middlewares/auth.js ฝั่ง backend คาดหวัง — ทำอัตโนมัติตรงนี้ที่
      // เดียว ทำให้ทุกหน้าที่เรียก $api ไม่ต้องมาแนบ header นี้เองทุกครั้ง
      console.log('[Axios] ส่ง token:', token.slice(0, 15) + '...')
      // log แค่ 15 ตัวอักษรแรกของ token (ไม่ log เต็ม ๆ) พอให้เห็นว่ามีการ
      // แนบ token จริงตอน debug โดยไม่เผย token เต็มออกไปใน console log
      // โดยไม่จำเป็น
    } else {
      console.warn('[Axios] ไม่มี token จะส่ง')
      // ไม่มี token เลย (ยังไม่ได้ login) — ปล่อยให้ request ส่งออกไปแบบไม่
      // มี Authorization header (backend จะตอบ 401 เองถ้า endpoint นั้น
      // ต้อง login)
    }

    return req
    // ต้อง return request ที่ (อาจจะ) แก้ไขแล้วกลับไปเสมอ ไม่งั้น axios จะ
    // ไม่รู้ว่าจะส่ง request แบบไหนออกไปจริง
  })

  // ✅ เพิ่ม debug ถ้า server บอก Missing token
  api.interceptors.response.use(
    (res) => res,
    // กรณี response สำเร็จ (status 2xx) ส่งต่อ res เดิมกลับไปตรง ๆ ไม่ต้อง
    // แก้ไขอะไร
    (err) => {
      // กรณี response ผิดพลาด (status 4xx/5xx หรือ network error) จะเข้ามา
      // ที่ฟังก์ชันนี้แทน
      if (err?.response?.status === 401) {
        console.warn('[Axios] 401 Unauthorized:', err?.response?.data)
        // token หมดอายุ/ไม่ถูกต้อง (backend ส่ง 401 เฉพาะกรณีนี้ ดู
        // middlewares/auth.js — role mismatch ใช้ 403 แยกต่างหาก) ล้าง
        // สถานะ login ทิ้งแล้วพาไปหน้า login ทันที กันไม่ให้หน้าเว็บค้างอยู่
        // ในสถานะ "เหมือน login อยู่" ทั้งที่ token ใช้ไม่ได้แล้วจริงๆ —
        // ปลอดภัยแม้ตอนที่ request ที่ 401 นี้คือการ login ผิดรหัสเอง (token
        // เป็น null อยู่แล้ว logout() จึงไม่มีผลอะไรเพิ่ม และ navigateTo
        // ไปหน้าที่อยู่ตรงนั้นพอดีอยู่แล้วก็แค่ no-op)
        auth.logout()
        navigateTo('/login')
      }
      return Promise.reject(err)
      // ต้อง reject ต่อไปเสมอ (ไม่ swallow error) ไม่งั้นโค้ดฝั่งที่เรียก
      // $api.get(...)/.post(...) จะไม่รู้เลยว่า request ล้มเหลว (เช่น
      // catch (e) {...} ในหน้า upload.vue จะไม่ทำงาน ถ้า error ถูกกลืนไว้
      // ตรงนี้โดยไม่ reject ต่อ)
    }
  )

  nuxtApp.provide('api', api)
  // nuxtApp.provide('api', api) ทำให้ทุกที่ในแอปเรียกใช้ axios instance
  // ตัวนี้ได้ผ่าน useNuxtApp().$api (ชื่อ '$api' มาจากการเติม $ นำหน้าชื่อ
  // ที่ provide ไว้โดยอัตโนมัติ — เป็นธรรมเนียมของ Nuxt plugin)
})
