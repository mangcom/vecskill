// ~/plugins/piniaPersist.client.js
//
// ปลั๊กอินนี้สอน "Pinia plugin" (ไม่ใช่ Nuxt plugin เฉย ๆ — คนละชนิดกัน แต่
// เขียนไว้ในไฟล์เดียวกันได้ เพราะ Nuxt plugin ด้านนอกเป็นแค่ตัวห่อให้โค้ด
// รันตอนแอปเริ่มทำงาน) — Pinia plugin คือฟังก์ชันที่ "เสียบ" เข้าไปแทรก
// พฤติกรรมเพิ่มให้กับ "ทุก store" ของ Pinia โดยอัตโนมัติ ไม่ต้องไปเขียนโค้ด
// ซ้ำ ๆ ในแต่ละ store เอง
//
// เป้าหมายของปลั๊กอินนี้: ทำให้ "ทุก store" (ไม่ใช่แค่ auth store) มี state
// ที่ persist (บันทึกค้าง) ไว้ใน localStorage โดยอัตโนมัติ แล้วกู้คืนกลับมา
// เองตอนเปิดแอปใหม่ — เป็น pattern ทั่วไปที่ใช้ได้กับ store ไหนก็ได้ในอนาคต
// โดยไม่ต้องเขียน hydrateFromStorage/setAuth-style ของตัวเองใหม่ทุกที
//
// ⚠️ หมายเหตุสำคัญสำหรับคนต่อยอด: ปัจจุบัน auth store (stores/auth.js) มี
// กลไก persist ของตัวเองอยู่แล้วแยกต่างหาก (เขียนมือ: setAuth() เขียนลง
// localStorage key "auth_token"/"auth_user" เอง, hydrateFromStorage() อ่าน
// กลับมาเอง, เรียกจาก plugins/auth-init.client.js) ส่วนปลั๊กอินไฟล์นี้จะ
// persist ทุก store รวมถึง auth store ด้วย "ซ้ำอีกชุด" ลง localStorage
// คนละ key กัน (key รูปแบบ "pinia-<ชื่อ store>" เช่น "pinia-auth") ทำให้
// ตอนนี้ auth store มี "สำเนาข้อมูลเดียวกัน" ถูกเก็บไว้ 2 ชุดคนละ key ใน
// localStorage พร้อมกัน — ระบบยังทำงานถูกต้องอยู่ในปัจจุบัน (เพราะ
// auth-init.client.js เป็นตัวที่ถูกเรียกใช้จริงตอนกู้คืนสถานะ login) แต่ถ้า
// จะต่อยอดเรื่อง persistence ของ auth store ในอนาคต ควรเลือกใช้แนวทางใด
// แนวทางหนึ่งแนวทางเดียว (ลบกลไกเขียนมือใน stores/auth.js ออกแล้วพึ่งพา
// ปลั๊กอินนี้แทนทั้งหมด หรือลบปลั๊กอินนี้ออกแล้วใช้แนวทางเขียนมือต่อไป) เพื่อ
// ไม่ให้มีแหล่งข้อมูลที่ซ้ำซ้อนกันสับสน
export default defineNuxtPlugin((nuxtApp) => {
  const pinia = nuxtApp.$pinia || nuxtApp.pinia
  // Nuxt เก็บ instance ของ Pinia ไว้ใน nuxtApp แต่ชื่อ property อาจต่างกัน
  // เล็กน้อยตามเวอร์ชัน/การตั้งค่า (บางครั้งเป็น $pinia บางครั้งเป็น pinia
  // ตรง ๆ) โค้ดนี้จึงลองทั้งสองชื่อ (|| ไล่หาตัวที่มีค่าจริง) กันเหนียว

  pinia.use(({ store }) => {
    // pinia.use(fn) คือการลงทะเบียน "Pinia plugin" ฟังก์ชันนี้จะถูกเรียก
    // ครั้งหนึ่งสำหรับทุก ๆ store ที่ถูกสร้างขึ้นในแอป (ทั้ง store ที่มีอยู่
    // แล้วตอนนี้ และ store ใหม่ที่จะถูกสร้างในอนาคต) — { store } ที่รับเข้า
    // มาคือ instance ของ store นั้น ๆ
    const key = `pinia-${store.$id}`
    // store.$id คือชื่อที่ตั้งไว้ตอน defineStore('auth', {...}) (ในที่นี้คือ
    // "auth") ใช้สร้างชื่อ key ของ localStorage ที่ไม่ชนกันระหว่าง store
    // ต่างชนิด เช่น store ชื่อ auth จะได้ key "pinia-auth"

    // restore เฉพาะฝั่ง client
    const saved = localStorage.getItem(key)
    // หมายเหตุ: ไม่ได้เช็ก process.client ก่อนเรียก localStorage ตรงนี้ —
    // ใช้ได้เพราะไฟล์นี้ลงท้ายด้วย ".client.js" อยู่แล้ว (Nuxt การันตีว่า
    // ปลั๊กอินนี้จะไม่ถูกรันฝั่งเซิร์ฟเวอร์เลย จึงมั่นใจได้ว่า localStorage
    // มีอยู่จริงเสมอตอนโค้ดนี้ทำงาน)
    if (saved) {
      try { store.$patch(JSON.parse(saved)) } catch (e) { console.error(e) }
      // store.$patch(obj) คือการอัปเดต state หลาย field พร้อมกันในครั้งเดียว
      // (merge เข้ากับ state เดิม ไม่ใช่แทนที่ทั้งหมด) — ครอบด้วย try/catch
      // เผื่อค่าที่เก็บไว้ใน localStorage เสียหาย/ไม่ใช่ JSON ที่ถูกต้อง
      // (เช่นถูกแก้ไขด้วยมือผ่าน DevTools) จะได้ไม่ทำให้แอปทั้งหน้า error
      // ไปเลยตอนเริ่มทำงาน
    }

    // subscribe แล้วบันทึกทุกครั้งที่ state เปลี่ยน
    store.$subscribe((_m, state) => {
      localStorage.setItem(key, JSON.stringify(state))
      // store.$subscribe(...) คือการ "ดักฟัง" ทุกครั้งที่ state ของ store
      // นี้เปลี่ยนแปลง (ไม่ว่าจะเปลี่ยนด้วย action, $patch, หรือแก้ตรง ๆ)
      // แล้ว callback นี้จะถูกเรียก — พารามิเตอร์ตัวแรก (_m ย่อมาจาก
      // mutation ไม่ได้ใช้งานในที่นี้ จึงตั้งชื่อด้วย _ นำหน้าตามธรรมเนียม
      // บอกว่า "รู้ว่ามีค่านี้แต่ตั้งใจไม่ใช้") ตัวที่สอง (state) คือ state
      // ล่าสุดทั้งก้อนของ store ตอนนี้ เอาไปแปลงเป็น JSON string แล้วเขียน
      // ทับ localStorage key เดิมทุกครั้ง (ทำให้ข้อมูลล่าสุดถูกบันทึกไว้
      // เสมอแบบอัตโนมัติ ไม่ต้องเรียกบันทึกเองทุกจุดที่แก้ state)
    }, { detached: true })
    // { detached: true } บอกว่าการ subscribe นี้ "ไม่ผูกอายุกับ component"
    // ใด ๆ (ปกติ $subscribe จะหยุดทำงานอัตโนมัติเมื่อ component ที่เรียกมัน
    // ถูก unmount ไป) เนื่องจากปลั๊กอินนี้รันตอนแอปเริ่มทำงาน ไม่ได้อยู่ใน
    // component ไหนเลย จึงต้องสั่ง detached ไว้เพื่อให้ subscribe นี้คง
    // อยู่ไปตลอดอายุของแอป ไม่ถูกยกเลิกไปเฉย ๆ
  })
})
