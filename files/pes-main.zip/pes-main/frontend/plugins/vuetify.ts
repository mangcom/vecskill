// import { createVuetify } from 'vuetify'
// import * as components from 'vuetify/components'
// import * as directives from 'vuetify/directives'

// export default defineNuxtPlugin((nuxtApp) => {
//   const vuetify = createVuetify({ components, directives })
//   nuxtApp.vueApp.use(vuetify)
// })
// เวอร์ชันข้างบนที่ comment ไว้คือวิธี "import ทุก component/directive ของ
// Vuetify มาเองตรง ๆ" (components, directives แบบเต็ม ๆ) ซึ่งทำให้ไฟล์
// สุดท้าย (bundle) ใหญ่เกินจำเป็น เพราะดึงมาทั้งหมดไม่ว่าจะใช้จริงกี่ตัวก็
// ตาม — เวอร์ชันด้านล่างที่ใช้งานจริงตอนนี้ อาศัย vite-plugin-vuetify (ตั้งค่า
// ไว้ใน nuxt.config.ts: vite.plugins -> vuetify({ autoImport: true })) มา
// ช่วย import เฉพาะ component ที่ใช้จริงใน template ให้อัตโนมัติแทน (tree
// -shaking) ไฟล์นี้จึงเหลือแค่หน้าที่ "สร้าง Vuetify instance พร้อมธีมสี
// ของเราเอง" แล้วติดตั้ง (.use()) เข้ากับแอปเท่านั้น

// plugins/vuetify.ts
import 'vuetify/styles'
// CSS หลักของ Vuetify (จำเป็นต้อง import แม้จะมี 'vuetify/styles' อยู่ใน
// nuxt.config.ts css: [...] อยู่แล้วก็ตาม — import ซ้ำแบบนี้ไม่มีผลเสีย
// เพราะ build tool จะรวม/ตัดซ้ำให้เองอยู่ดี)
import { createVuetify } from 'vuetify'
import { aliases, mdi } from 'vuetify/iconsets/mdi'
// ชุดไอคอน Material Design Icons (mdi) — aliases คือชื่อย่อมาตรฐานที่
// Vuetify ใช้เรียกไอคอนบางตัวภายใน component ของตัวเอง (เช่นไอคอนลูกศรใน
// dropdown) ต้องส่งเข้าไปด้วยไม่งั้นไอคอนพวกนั้นจะหายไป
import { md3 } from 'vuetify/blueprints'
// "blueprint" คือชุดค่าเริ่มต้นสำเร็จรูปของ Vuetify (เช่น ความโค้งมุม,
// ระยะห่าง, สไตล์โดยรวม) md3 คือ blueprint ตามแนวทาง Material Design 3
// (เวอร์ชันล่าสุดของ Material Design ตอนที่เขียนไฟล์นี้)

const light = {
  dark: false,
  colors: {
    background: '#FFFFFF',
    surface: '#FFFFFF',
    primary: '#2563eb',
    secondary: '#64748b',
    error: '#ef4444',
    info: '#0ea5e9',
    success: '#10b981',
    warning: '#f59e0b',
  },
}
// ชุดสีธีม "สว่าง" ของทั้งแอป — ชื่อ key เหล่านี้ (primary, secondary,
// error, ...) เป็นชื่อมาตรฐานที่ Vuetify รู้จัก ใช้กับ prop เช่น
// color="primary" ใน component ต่าง ๆ ได้ทันที (ไม่ต้องจำค่าสี hex เอง)
const dark = {
  dark: true,
  colors: {
    background: '#0b1220',
    surface: '#111827',
    primary: '#60a5fa',
    secondary: '#94a3b8',
    error: '#f87171',
    info: '#38bdf8',
    success: '#34d399',
    warning: '#fbbf24',
  },
}
// ชุดสีธีม "มืด" — สังเกตว่าสีเดียวกัน (เช่น primary) มีค่า hex ต่างกันในแต่
// ละธีม (เช่น primary โทนเข้มกว่าในธีมสว่าง แต่โทนสว่างกว่าในธีมมืด) เพราะ
// สีที่ตัดกับพื้นหลังสว่างได้ดี อาจกลืนไปกับพื้นหลังมืดถ้าใช้ค่าเดียวกัน —
// ดูการสลับธีมจริงได้ใน layouts/dashboard.vue (ปุ่ม toggleTheme)

export default defineNuxtPlugin((nuxtApp) => {
  const vuetify = createVuetify({
    blueprint: md3,
    icons: { defaultSet: 'mdi', aliases, sets: { mdi } },
    // defaultSet: 'mdi' บอกว่าถ้าเขียน icon="mdi-xxx" แบบสั้น ๆ ใน
    // component ให้ไปหาไอคอนจากชุด mdi โดยอัตโนมัติ
    theme: {
      defaultTheme: 'light',     // 👈 ชื่อให้ตรงกับที่เราจะสลับ
      // ธีมเริ่มต้นตอนเปิดแอปครั้งแรก (ก่อนที่ layouts/dashboard.vue จะอ่าน
      // ค่าที่เคยจำไว้จาก localStorage มาเซ็ตทับอีกที — ดู onMounted ใน
      // ไฟล์นั้น) ชื่อ 'light' ต้องตรงกับ key ที่ใช้ใน themes ด้านล่างเป๊ะ ๆ
      themes: { light, dark },
      // ลงทะเบียนทั้งสองธีมที่นิยามไว้ด้านบนให้ Vuetify รู้จักในชื่อ
      // 'light' และ 'dark' — theme.global.name.value ใน
      // layouts/dashboard.vue จะสลับไปมาระหว่างชื่อทั้งสองนี้
    },
  })
  nuxtApp.vueApp.use(vuetify)
  // ติดตั้ง Vuetify instance ที่สร้างไว้เข้ากับ Vue app ของ Nuxt จริง ๆ
  // (nuxtApp.vueApp คือ Vue app instance ที่อยู่ข้างใต้ Nuxt) หลังจากนี้
  // component ของ Vuetify ทุกตัว (<v-btn>, <v-card>, ...) ถึงจะใช้งานได้
  // ทั่วทั้งแอป
})
