// ~/stores/auth.js
//
// Pinia store กลางของทั้งแอป เก็บสถานะการ login (token + ข้อมูลผู้ใช้) — ทุก
// component/composable ที่ต้องรู้ว่า "login อยู่ไหม", "login เป็นใคร/role
// อะไร" จะเรียก useAuthStore() ตัวนี้ร่วมกันทั้งหมด (Pinia การันตีว่าเรียก
// useAuthStore() จากที่ไหนก็ได้ instance เดียวกันเสมอ ไม่ได้สร้าง store
// ใหม่ทุกครั้งที่เรียก)
//
// ⚠️ หมายเหตุเรื่อง persistence (การบันทึกค้างไว้ข้ามการ refresh หน้าเว็บ):
// store นี้เขียนโค้ดบันทึก/กู้คืนค่าไป-กลับกับ localStorage "ด้วยมือเอง"
// ตรง ๆ ในไฟล์นี้เลย (setAuth / hydrateFromStorage / logout ด้านล่าง) ใช้
// localStorage key ชื่อ "auth_token" กับ "auth_user" — แยกเป็นคนละกลไกกับ
// plugins/piniaPersist.client.js (ปลั๊กอิน Pinia กลางที่ persist ทุก store
// อัตโนมัติ รวมถึง store นี้ด้วย แต่เก็บไว้คนละ key คือ "pinia-auth") ตอนนี้
// ตัวที่ถูกเรียกใช้งานจริงตอนเปิดแอปคือ hydrateFromStorage() (เรียกจาก
// plugins/auth-init.client.js) ไม่ใช่กลไกของ piniaPersist — มีข้อมูลซ้ำกัน
// สองชุดอยู่ใน localStorage โดยไม่ได้ตั้งใจ ถ้าจะต่อยอดเรื่องนี้ควรเลือกใช้
// กลไกใดกลไกหนึ่งแนวทางเดียว (ดูรายละเอียดเพิ่มเติมที่คอมเมนต์ใน
// plugins/piniaPersist.client.js)
import { defineStore } from 'pinia'
export const useAuthStore = defineStore('auth', {
  // defineStore(id, options) — id คือ 'auth' (ใช้สร้าง key ภายในของ Pinia
  // เอง และใช้เป็นส่วนหนึ่งของชื่อ key ตอน persist เช่น "pinia-auth")
  state: () => ({
    token: null,
    // JWT ที่ได้จาก POST /api/auth/login (ดู
    // backend/controllers/auth.controller.js) — null แปลว่ายังไม่ได้ login
    user: null,
    // ข้อมูลผู้ใช้แบบย่อ { id, name, email, role } ที่ backend ส่งมาพร้อม
    // token ตอน login สำเร็จ
  }),
  getters: {
    isLogged: (s) => !!s.token,
    // getter คือ "ค่าที่คำนวณจาก state" (เหมือน computed ของ component)
    // isLogged เป็น true ก็ต่อเมื่อมี token อยู่จริง (ไม่ใช่ null/undefined/
    // สตริงว่าง) — ใช้เช็กทั่วทั้งแอป เช่นใน layouts/default.vue,
    // middleware/auth.global.js แทนที่จะเช็ก !!token ซ้ำเองทุกที่
  },
  actions: {
    setAuth(token, user) {
      // เรียกตอน login สำเร็จ (ดู pages/login.vue) — บันทึกทั้งลง state
      // ของ store (ให้ UI reactive ตามทันที) และลง localStorage (ให้รอด
      // ข้ามการ refresh หน้าเว็บ)
      this.token = token
      this.user  = user
      if (process.client) {
        // เช็ก process.client ก่อนแตะ localStorage เพราะไฟล์ store (ไม่ใช่
        // ไฟล์ .client.js) อาจถูกเรียกใช้งานจากโค้ดที่รันได้ทั้งสองฝั่ง —
        // แม้แอปนี้จะปิด SSR (ssr:false) ไปแล้ว การเช็กไว้แบบนี้ยังเป็น
        // นิสัยที่ปลอดภัยเสมอ
        localStorage.setItem('auth_token', token)
        localStorage.setItem('auth_user', JSON.stringify(user || null))
        // JSON.stringify เพราะ localStorage เก็บได้แค่ string เท่านั้น
        // (ไม่ใช่ object ตรง ๆ) ต้องแปลง user object ให้เป็น JSON string
        // ก่อนเก็บ แล้วค่อยแปลงกลับด้วย JSON.parse ตอนอ่านออกมา (ดู
        // hydrateFromStorage ด้านล่าง)
      }
    },
    hydrateFromStorage() {
      // เรียกตอนแอปเริ่มทำงาน (ดู plugins/auth-init.client.js) เพื่อ "กู้
      // คืน" สถานะ login ที่เคยบันทึกไว้ก่อนหน้า กลับเข้า state ของ store
      if (!process.client) return
      const t = localStorage.getItem('auth_token')
      const u = localStorage.getItem('auth_user')
      if (t) {
        // มี token เก่าบันทึกไว้ -> ถือว่ายัง login อยู่ก่อน (โค้ดนี้ "ไม่ได้"
        // ตรวจสอบว่า token หมดอายุไปแล้วหรือยัง แค่เช็กว่ามีค่าอยู่) ถ้า token
        // หมดอายุจริง ครั้งแรกที่ยิง API ที่ต้อง login จะโดน 401 กลับมาจาก
        // backend เอง แล้ว response interceptor ใน plugins/axios.client.js
        // จะเป็นคนจัดการ logout + redirect ไปหน้า /login ให้อัตโนมัติ
        this.token = t
        try { this.user = u ? JSON.parse(u) : null } catch { this.user = null }
        // ครอบด้วย try/catch เผื่อค่าที่เก็บไว้เสียหาย/ไม่ใช่ JSON ที่ถูกต้อง
        // (เช่นถูกแก้ไขด้วยมือผ่าน DevTools) จะได้ไม่ error ทั้งแอปตอนเริ่ม
      }
    },
    logout() {
      // ล้างสถานะ login ทั้งหมด ทั้งใน state ของ store และใน localStorage
      this.token = null
      this.user  = null
      if (process.client) {
        localStorage.removeItem('auth_token')
        localStorage.removeItem('auth_user')
      }
      // หมายเหตุ: ไม่ได้เรียก API ใด ๆ ไปบอก backend ว่า "logout แล้วนะ"
      // เพราะระบบนี้ไม่มีกลไก server-side session/token blacklist (JWT เป็น
      // stateless อยู่แล้ว — token เดิมจะยังคง "ถูกต้อง" ในสายตา backend
      // จนกว่าจะหมดอายุเองตาม JWT_EXPIRES แม้ฝั่ง frontend จะลบทิ้งไปแล้วก็
      // ตาม) นี่คือข้อจำกัดปกติของระบบ auth แบบ JWT ล้วน ๆ ไม่ใช่บั๊ก
    }
  }
})
