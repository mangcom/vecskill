// tailwind.config.js
//
// ไฟล์ตั้งค่าของ Tailwind CSS (framework สำหรับเขียน CSS ด้วย utility class
// เช่น class="flex items-center gap-2" แทนการเขียน CSS เอง) — ถูกเรียกใช้
// ผ่าน PostCSS ที่ nuxt.config.ts ตั้งค่าไว้ (ดู postcss.plugins ในไฟล์นั้น)

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    // "content" คือรายชื่อไฟล์ที่ Tailwind จะไป "สแกนหา" ว่ามีการใช้ class
    // อะไรบ้าง แล้วค่อยสร้าง CSS เฉพาะ class ที่ใช้จริงออกมาเท่านั้น (ไม่สร้าง
    // CSS ของทุก utility class ที่ Tailwind มีทั้งหมด ซึ่งจะทำให้ไฟล์ CSS
    // สุดท้ายใหญ่เกินจำเป็นมาก) — ถ้าสร้างไฟล์ .vue ใหม่ไว้นอกรายชื่อ pattern
    // ด้านล่างนี้ แล้วใช้ class ของ Tailwind ใน component นั้น class จะไม่ถูก
    // สร้าง CSS ให้ (ต้องเพิ่ม path เข้าไปในรายการนี้ด้วย)
    "./components/**/*.{vue,js,ts}",
    "./layouts/**/*.{vue,js,ts}",
    "./pages/**/*.{vue,js,ts}",
    "./app.vue",
    "./plugins/**/*.{js,ts}",
  ],
  theme: { extend: {} },
  // ตรงนี้คือจุดที่จะปรับแต่ง/เพิ่มค่าธีมของ Tailwind เอง (สี, ระยะห่าง,
  // ฟอนต์ ฯลฯ) ถ้าอยากต่อยอด — ตอนนี้ยังไม่ได้ปรับแต่งอะไรเพิ่ม (extend: {}
  // ว่างเปล่า ใช้ค่าธีมมาตรฐานของ Tailwind ทั้งหมด)
  plugins: [require("daisyui")],           // <— เพิ่มบรรทัดนี้
  // DaisyUI คือปลั๊กอินของ Tailwind ที่เพิ่ม component class สำเร็จรูป (เช่น
  // class="btn btn-primary") ไว้ใช้คู่กับ utility class ของ Tailwind เอง —
  // ในแอปนี้ส่วนที่ใช้ Vuetify เป็นหลักจะไม่ได้พึ่ง DaisyUI มากนัก แต่ค่า
  // config นี้ยังเปิดไว้เผื่อมีการใช้ class ของ DaisyUI ปนอยู่ในบางหน้า
  // (ไม่อยากต้องแก้ config ไฟล์นี้ใหม่ทุกครั้งที่จะลองใช้ DaisyUI ที่ไหนก็ได้)
  // (ไม่บังคับ) ตั้งธีมเริ่มต้น/รายการธีม
  daisyui: {
    themes: ["light", "dark", "corporate"], // เลือกได้ตามต้องการ
    // รายชื่อธีมสำเร็จรูปของ DaisyUI ที่อนุญาตให้ใช้ในแอปนี้ (DaisyUI มีธีม
    // ให้เลือกเยอะกว่านี้มาก แต่การจำกัดไว้แค่บางธีมช่วยลดขนาด CSS สุดท้าย)
    darkTheme: "dark",
    // บอก DaisyUI ว่าถ้าต้องเลือก "ธีมมืด" อัตโนมัติ (เช่นตาม
    // prefers-color-scheme ของระบบปฏิบัติการผู้ใช้) ให้ใช้ธีมชื่อ "dark"
  },
}
