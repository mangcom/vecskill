// tests/login.spec.ts
//
// ทดสอบ pages/login.vue — หน้านี้เรียก useNuxtApp().$api.post(...) (ไม่ใช่
// $fetch ของ Nuxt อย่างที่โค้ดเทสต์เวอร์ชันเดิมเข้าใจผิด) จึงต้อง mock
// useNuxtApp ให้คืน $api ปลอมที่เป็น vi.fn() เอาไว้ตรวจสอบว่าถูกเรียกด้วย
// อะไรบ้าง ไม่ใช่ mock $fetch ที่ component ไม่เคยเรียกใช้เลยจริง ๆ
//
// อีกจุดที่ต้องระวัง: ของเดิมเทสต์นี้ตรวจสอบข้อความ validation (เช่น
// "กรอกอีเมล") จาก wrapper.html() ตรง ๆ — แต่ setup.ts stub ทุก Vuetify
// component (รวม v-text-field) เป็น placeholder เปล่า ๆ ไม่ render
// โครงสร้างภายในที่ Vuetify ใช้แสดงข้อความ :rules เลย ข้อความนั้นจึงไม่มี
// ทางปรากฏใน wrapper.html() ได้จริง (ไม่ว่าโค้ดจะถูกหรือผิดก็ตาม) จึง
// เปลี่ยนมาตรวจสอบผ่าน $api mock (ถูกเรียกไหม/เรียกด้วยอะไร) และผ่าน
// wrapper.vm.errorMsg (ที่ page เปิดให้เข้าถึงด้วย defineExpose) แทน

import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import Login from '../pages/login.vue'

describe('pages/login.vue', () => {
  let postMock: ReturnType<typeof vi.fn>

  beforeEach(() => {
    setActivePinia(createPinia())
    // useAuthStore() (เรียกใช้ข้างใน login.vue) ต้องมี Pinia instance ที่
    // "active" อยู่ก่อนเสมอ ไม่งั้นจะ error ทันทีตอน component พยายามสร้าง
    // store — สร้าง Pinia ใหม่ก่อนทุก test case กันไม่ให้ state (เช่น token)
    // ของเทสต์ก่อนหน้าหลงเหลือข้ามมา

    postMock = vi.fn()
    vi.stubGlobal('useNuxtApp', () => ({ $api: { post: postMock } }))
    // ปลอม useNuxtApp() ให้คืน object ที่มี $api.post เป็น mock function —
    // component เรียก const { $api } = useNuxtApp() แล้วใช้ $api.post(...)
    // ตรง ๆ ดังนั้น mock แค่เท่านี้ก็ครอบคลุมทุกจุดที่ component คุยกับ
    // "โลกภายนอก" (เครือข่าย) แล้ว ไม่ต้องยิง request จริงเลยในเทสต์
  })

  it('ไม่เรียก API เมื่อฟอร์มยังไม่ผ่าน schema validation ของ vee-validate (ฟิลด์ว่าง)', async () => {
    const wrapper = mount(Login)
    const vm: any = wrapper.vm
    vm.email = ''
    vm.password = ''
    // ต้องเคลียร์ค่าให้ว่างเองตรงนี้ก่อน — หน้า login.vue ตั้งค่าเริ่มต้น
    // (initialValue) ของทั้ง email/password ไว้เป็น demo credentials จริง
    // (admin@vecskill.ovec / 12345678) เพื่อความสะดวกตอนสาธิต ถ้าไม่เคลียร์
    // ก่อน ฟอร์มจะ "ไม่ว่าง" เลยตั้งแต่ mount เสร็จ ทำให้ schema validation
    // ผ่านไปเฉย ๆ และ onSubmit() จะเรียก $api.post จริง (ไม่ตรงกับชื่อเทสต์
    // นี้ที่ต้องการทดสอบกรณี "ฟอร์มว่าง") — เจอ regression นี้จริงตอนเพิ่ม
    // ฟีเจอร์ prefill demo credentials ทีหลัง แล้วลืมย้อนกลับมาแก้เทสต์นี้
    await wrapper.vm.onSubmit()
    // onSubmit ที่ defineExpose ไว้คือผลลัพธ์ของ handleSubmit(...) ของ
    // vee-validate — ถ้า schema (yup) ไม่ผ่าน (ฟิลด์ email/password ว่าง
    // อยู่) ฟังก์ชัน async ข้างในที่เรียก $api.post จะ "ไม่ถูกเรียกเลย"
    // vee-validate จะดักไว้ก่อนแล้วอัปเดต error message ของแต่ละ field แทน
    expect(postMock).not.toHaveBeenCalled()
  })

  it('เรียก POST /api/auth/login ด้วยค่าที่กรอก แล้วบันทึกสถานะ login เมื่อสำเร็จ', async () => {
    postMock.mockResolvedValueOnce({
      data: {
        accessToken: 'fake-token',
        user: { id: 1, name: 'Admin', email: 'admin@vecskill.ovec', role: 'admin' }
      }
    })

    const wrapper = mount(Login)
    const vm: any = wrapper.vm
    vm.email = 'admin@vecskill.ovec'
    vm.password = '12345678'
    // ตั้งค่าโดยตรงผ่าน wrapper.vm (ที่ defineExpose เปิดให้เข้าถึง email/
    // password ซึ่งเป็น value ของ useField('email')/useField('password'))
    // แทนการพิมพ์ผ่าน <input> จริงในหน้าเว็บ (ซึ่งทำไม่ได้ในเทสต์นี้ เพราะ
    // v-text-field ถูก stub ไว้ ไม่มี <input> จริงให้พิมพ์)

    await vm.onSubmit()

    expect(postMock).toHaveBeenCalledWith(
      '/api/auth/login',
      expect.objectContaining({ email: 'admin@vecskill.ovec', password: '12345678' })
    )
    expect(vm.errorMsg).toBe('')
    // ไม่มี error message ค้างอยู่ แปลว่า flow ไปถึงขั้นตอน "สำเร็จ" ของ
    // onSubmit (ดู pages/login.vue: เข้า if (data?.accessToken) แล้วไม่ได้
    // ตั้ง errorMsg เลย)
  })

  it('แสดงข้อความ error เมื่อ API ตอบ error กลับมา (เช่น รหัสผ่านผิด)', async () => {
    postMock.mockRejectedValueOnce({
      response: { data: { message: 'Invalid credentials-password' } }
    })

    const wrapper = mount(Login)
    const vm: any = wrapper.vm
    vm.email = 'admin@vecskill.ovec'
    vm.password = 'wrong-password'

    await vm.onSubmit()

    expect(vm.errorMsg).toBe('Invalid credentials-password')
    // ตรวจว่า error message จาก response.data.message ของ backend (ดู
    // catch block ใน pages/login.vue) ถูกเก็บไว้ที่ errorMsg ถูกต้อง
  })
})
