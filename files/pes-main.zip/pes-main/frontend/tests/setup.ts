// tests/setup.ts
//
// ไฟล์นี้รันก่อนทุกไฟล์เทสต์เสมอ (ตั้งค่าไว้ใน vitest.config.ts ->
// test.setupFiles) มีหน้าที่เตรียม "สภาพแวดล้อมปลอม" ให้ครบพอที่จะ mount
// หน้า Nuxt (pages/*.vue) ได้โดยไม่ error — ซึ่งมีความท้าทายเฉพาะตัว:
// หน้าพวกนี้เขียนโดยใช้ "auto-import" ของ Nuxt (เรียก useRouter(),
// useNuxtApp(), definePageMeta() เป็นฟังก์ชัน global เลยโดยไม่มี import
// statement ใด ๆ ในไฟล์ — ปกติ Nuxt จะแปลง/เติม import ให้อัตโนมัติตอน
// build จริงผ่านปลั๊กอินของตัวเอง) แต่ Vitest ในโปรเจกต์นี้ตั้งค่าไว้แบบ
// "เบา" (ดู vitest.config.ts — มีแค่ @vitejs/plugin-vue ไม่ได้ใช้
// @nuxt/test-utils เต็มรูปแบบ) จึงไม่มีใครมาเติม import พวกนี้ให้เลย
//
// วิธีแก้ที่ไฟล์นี้ใช้: vi.stubGlobal(name, fn) จะเซ็ต globalThis[name] =
// fn — เมื่อโค้ดในไฟล์ .vue อ้างอิงชื่อ (เช่น useRouter) ที่ไม่มีการ import
// ไว้เลยในไฟล์นั้น JavaScript จะไล่หาใน global scope เป็นลำดับสุดท้าย แล้ว
// เจอค่าที่เราเซ็ตไว้ตรงนี้พอดี ทำให้เรียกใช้งานได้โดยไม่ error (เหมือนกับ
// ที่ Nuxt ทำให้ตอนรันจริง เพียงแต่เราทำเอง "ด้วยมือ" สำหรับตอนเทสต์)
//
// ⚠️ ของเดิมไฟล์นี้เคยใช้ vi.mock('#app', { useRuntimeConfig, useRouter })
// ซึ่ง "ไม่เคยทำงานจริง" เลย เพราะไม่มีไฟล์ .vue ไหนในระบบ import จาก '#app'
// ตรง ๆ (ทุกไฟล์เรียกเป็น bare global ตามที่อธิบายไว้ด้านบน) vi.mock จึง
// mock โมดูลที่ไม่มีใครเรียกใช้ ไม่ได้ผลอะไรเลย — เปลี่ยนมาใช้ vi.stubGlobal
// ให้ตรงกับพฤติกรรมจริงแทน
import { vi } from 'vitest'
import { config } from '@vue/test-utils'

vi.stubGlobal('definePageMeta', () => {})
// definePageMeta ของจริงเป็นแค่ "macro" ที่ Nuxt ใช้อ่านตอน build (ไม่ได้
// ทำอะไรตอนรันจริงเลย) ตอนเทสต์จึงแค่ทำให้มันเป็นฟังก์ชันว่างเปล่าที่ไม่
// error ตอนถูกเรียกก็พอ ไม่ต้องให้มันทำอะไรจริง

vi.stubGlobal('useRouter', () => ({
  push: vi.fn(),
  back: vi.fn(),
}))
// ปลอม useRouter() ให้คืน object ที่มีแค่ push/back เป็น mock function
// (vi.fn()) — พอให้ component เรียก router.push('/') หรือ router.back()
// ได้โดยไม่ error แต่ละเทสต์ไฟล์ที่อยากเช็กว่า "เรียก push ไปหน้าไหน" ให้
// import useRouter มา assert เอง (เช่น expect(useRouter().push)
// .toHaveBeenCalledWith('/'))

config.global.stubs = {
  // Stub Vuetify components to avoid heavy DOM
  // "stub: true" แทนที่ component จริงด้วย placeholder ง่าย ๆ (ไม่ render
  // โครงสร้างภายในจริงของ Vuetify เช่น <input> ข้างใน <v-text-field>) ลด
  // ความซับซ้อนของสิ่งที่ต้อง mount/ทำให้เทสต์เร็วขึ้น และไม่ต้องติดตั้ง
  // Vuetify plugin เต็มรูปแบบ (ที่ต้องพึ่ง browser API บางตัวที่ jsdom ไม่มี
  // ให้ครบ) แลกมาด้วยข้อจำกัด: ข้อความ error จาก :rules ของ Vuetify (ที่
  // render อยู่ "ข้างใน" ของแต่ละ component) จะไม่ปรากฏใน wrapper.html()
  // เลย เพราะ component ถูกตัดโครงสร้างภายในทิ้งไปตั้งแต่ชั้น stub นี้ —
  // นี่คือเหตุผลที่เทสต์ในไฟล์นี้ (tests/login.spec.ts,
  // tests/users.new.spec.ts) ไม่ตรวจสอบข้อความ validation ที่ render จาก
  // Vuetify โดยตรง แต่ตรวจสอบผ่าน defineExpose() ของแต่ละหน้าแทน (ดู
  // คอมเมนต์ในไฟล์เทสต์ทั้งสองไฟล์)
  'v-card': true, 'v-card-title': true, 'v-card-text': true, 'v-card-actions': true,
  'v-btn': true, 'v-alert': true, 'v-text-field': true, 'v-select': true,
  'v-data-table': true, 'v-data-table-server': true, 'v-table': true, 'v-spacer': true,
  'v-checkbox': true, 'v-form': true, 'v-row': true, 'v-col': true, 'v-container': true,
  // เพิ่ม v-checkbox (ใช้ใน login.vue), v-form/v-row/v-col/v-container
  // (ใช้ใน users/new.vue) เข้าไปในรายการ stub ด้วย — ของเดิมไม่มี 4 ตัวหลัง
  // นี้ ทำให้ Vue แสดง warning "Failed to resolve component" (ไม่ได้ทำให้
  // เทสต์ error ตรง ๆ แต่เป็นสัญญาณว่า component ไม่ถูก resolve ตามที่ตั้งใจ)
  NuxtLink: true,
  // <NuxtLink> (ใช้ใน login.vue สำหรับลิงก์ "Forgot password?") เป็น
  // component ของ Nuxt เอง ไม่ใช่ของ Vuetify — ไม่มีให้ใช้นอก context ของ
  // Nuxt app จริง จึง stub ไว้เป็นเปลือกเปล่า ๆ เหมือนกัน
}
