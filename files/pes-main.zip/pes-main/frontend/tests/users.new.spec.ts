// tests/users.new.spec.ts
//
// ทดสอบ pages/users/new.vue — หลังแก้ไขให้ใช้ useNuxtApp().$api แทนการยิง
// axios ตรงไปที่ URL คงที่ "http://localhost:7000/api/users" (ดูคอมเมนต์
// อธิบายสาเหตุและผลของการแก้ไขในไฟล์ pages/users/new.vue) การ mock ของ
// เทสต์นี้จึงต้องปลอม useNuxtApp แบบเดียวกับ tests/login.spec.ts แทนการ
// stub $fetch ของเดิม (ซึ่ง component ไม่เคยเรียกใช้เลยทั้งก่อนและหลังแก้ไข)
//
// หมายเหตุ: component นี้ "ไม่มี" client-side validation จริงจัง (ปุ่ม Save
// เรียก handleSubmit() ตรง ๆ ไม่ผ่าน schema ใด ๆ ก่อน ต่างจาก
// pages/login.vue ที่ผูกกับ vee-validate) ข้อความ "required" บน
// <v-text-field> เป็นแค่ UI attribute เฉย ๆ ไม่ได้บังคับห้าม submit จริง —
// เทสต์นี้จึงตรวจสอบพฤติกรรมจริงตามที่ component เป็น ไม่ใช่ตรวจสอบข้อความ
// validation ที่ไม่มีอยู่จริงในโค้ด (ของเดิมคาดหวัง 'กรอกชื่อ'/'กรอกอีเมล'/
// 'กรอกรหัสผ่าน' ซึ่งไม่เคยมีโค้ดส่วนไหนสร้างข้อความเหล่านี้ขึ้นมาเลย)

import { mount } from '@vue/test-utils'
import { describe, it, expect, vi, beforeEach } from 'vitest'
import NewUser from '../pages/users/new.vue'

// pages/users/new.vue import useRouter มาจาก 'vue-router' โดยตรง (ไม่ใช่
// bare global แบบ auto-import ของ Nuxt เหมือนไฟล์อื่น) ของจริง useRouter()
// ต้องพึ่ง router instance ที่ติดตั้งผ่าน app.use(router) ไว้ก่อน ถ้าไม่มี
// context นี้เลยตอนเทสต์ มันจะคืน undefined แล้วเรียก .push()/.back() ต่อ
// ไม่ได้ — mock ทั้งโมดูลตรงนี้ไปเลยให้ง่ายกว่าไปสร้าง router จริงทั้งชุด
vi.mock('vue-router', () => ({
  useRouter: () => ({ push: vi.fn(), back: vi.fn() })
}))

describe('pages/users/new.vue', () => {
  let postMock: ReturnType<typeof vi.fn>

  beforeEach(() => {
    postMock = vi.fn()
    vi.stubGlobal('useNuxtApp', () => ({ $api: { post: postMock } }))
  })

  it('ส่ง field ครบตามที่กรอกไปที่ POST /api/users แล้วแสดง error จาก backend ถ้าไม่ครบ', async () => {
    postMock.mockRejectedValueOnce({
      response: { data: { message: 'name_th, email, password required' } }
    })
    // จำลองสถานการณ์เดียวกับที่ backend จริงตอบกลับ (ดู
    // backend/controllers/users.controller.js -> create) เมื่อฟิลด์ไม่
    // ครบ — เพราะ component นี้ไม่ validate เองฝั่ง client เลย ฟิลด์ที่ไม่
    // ครบจะถูกส่งไปถึง backend เสมอ แล้วปล่อยให้ backend เป็นคนปฏิเสธแทน

    const wrapper = mount(NewUser)
    await wrapper.vm.handleSubmit()
    // ไม่ได้กรอกอะไรเลย (vals เป็นค่าว่างทั้งหมดตามค่าเริ่มต้น) เรียก
    // handleSubmit ตรง ๆ เหมือนตอนผู้ใช้กดปุ่ม Save

    expect(postMock).toHaveBeenCalledWith('/api/users', {
      name_th: '', email: '', password: '', role: 'evaluatee'
    })
    expect(wrapper.vm.errorMsg).toBe('name_th, email, password required')
  })

  it('สร้างผู้ใช้สำเร็จแล้วพาไปหน้าแรกเมื่อกรอกข้อมูลครบ', async () => {
    postMock.mockResolvedValueOnce({ data: { success: true } })

    const wrapper = mount(NewUser)
    const vm: any = wrapper.vm
    vm.vals.name_th = 'Test User'
    vm.vals.email = 'test.user@vecskill.ovec'
    vm.vals.password = '12345678'
    vm.vals.role = 'evaluator'

    await vm.handleSubmit()

    expect(postMock).toHaveBeenCalledWith('/api/users', {
      name_th: 'Test User',
      email: 'test.user@vecskill.ovec',
      password: '12345678',
      role: 'evaluator'
    })
    expect(vm.errorMsg).toBe('')
    // ไม่มี error ค้าง แปลว่าผ่าน try block ไปจนจบโดยไม่เข้า catch (ดู
    // pages/users/new.vue: สำเร็จแล้วเรียก router.push('/') ซึ่งถูก
    // stub ไว้ใน tests/setup.ts ผ่าน vi.stubGlobal('useRouter', ...)
    // อยู่แล้ว ไม่ error แม้จะไม่มี router จริงก็ตาม)
  })
})
