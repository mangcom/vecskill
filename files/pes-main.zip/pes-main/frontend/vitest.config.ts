// vitest.config.ts
//
// ไฟล์ตั้งค่าของ Vitest (test runner ที่ frontend ใช้ — รันด้วยคำสั่ง
// `npm test` ดู package.json -> scripts.test) แยกไฟล์ต่างหากจาก
// nuxt.config.ts เพราะ Vitest รันแยกเป็นกระบวนการของตัวเอง ไม่ได้ผ่าน
// Nuxt dev server/build process เลย — ถ้าไม่มีไฟล์นี้ Vitest จะไม่รู้จัก
// syntax ของไฟล์ .vue และไม่รู้ว่าต้อง setup อะไรก่อนรัน test

import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vitest/config'
import vue from '@vitejs/plugin-vue'
// ปลั๊กอินที่ทำให้ Vite/Vitest "อ่านไฟล์ .vue ออก" (คอมไพล์ Single File
// Component ให้กลายเป็น JavaScript ปกติก่อนรัน) — ถ้าไม่มีปลั๊กอินนี้ การ
// import ไฟล์ .vue ในเทสต์ (เช่น tests/login.spec.ts ที่ import
// '../pages/login.vue') จะ error ทันที

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '~': fileURLToPath(new URL('.', import.meta.url)),
      '@': fileURLToPath(new URL('.', import.meta.url)),
      // Nuxt ตั้งค่า alias "~" และ "@" ให้ชี้ไปที่โฟลเดอร์ frontend/ (root
      // ของโปรเจกต์ฝั่ง frontend) ให้อัตโนมัติตอนรันแอปจริง — เช่น import
      // { useAuthStore } from '~/stores/auth' ใน pages/login.vue จะ resolve
      // ไปที่ frontend/stores/auth.js ได้เอง แต่ Vitest ไม่รู้จัก alias
      // พวกนี้โดยอัตโนมัติ (ไม่ได้ใช้ Nuxt vite config ชุดเดียวกับตอนรันจริง)
      // ถ้าไม่เพิ่ม alias ตรงนี้เอง การ import ไฟล์ .vue ที่มี "~/..." ข้างใน
      // จะ error ทันทีว่า "Failed to resolve import"
    }
  },
  test: {
    environment: 'jsdom',
    // ปกติ Node.js (ที่ Vitest รันอยู่) ไม่มี DOM/window/document ให้ใช้
    // เหมือนเบราว์เซอร์ — jsdom คือไลบรารีที่จำลองสภาพแวดล้อมเบราว์เซอร์ขึ้นมา
    // ในหน่วยความจำ ทำให้เทสต์ component ของ Vue (ที่ต้อง mount ลงใน DOM
    // จริง ๆ ถึงจะทำงานได้) รันได้โดยไม่ต้องเปิดเบราว์เซอร์จริง
    globals: true,
    // เปิดให้ใช้ describe/it/expect/vi ได้เลยทุกไฟล์เทสต์โดยไม่ต้อง import
    // เองทุกครั้ง (เหมือนที่ Jest ทำเป็นค่าเริ่มต้น)
    setupFiles: ['./tests/setup.ts'],
    // ไฟล์ที่ Vitest จะรันก่อน "ทุก" ไฟล์เทสต์เสมอ ใช้สำหรับเตรียม
    // สภาพแวดล้อมร่วมกัน (เช่น import matcher เพิ่มเติม, stub ค่า global) —
    // ดูเนื้อหาจริงที่ tests/setup.ts
    exclude: ['**/node_modules/**', '**/e2e/**'],
    // ต้องกันโฟลเดอร์ e2e/ ออกไปตรง ๆ เพราะไฟล์ในนั้น (เช่น
    // e2e/login.e2e.spec.ts) ก็ลงท้ายด้วย .spec.ts เหมือนกับไฟล์ของ Vitest
    // เอง — ถ้าไม่กันไว้ `npm test` (Vitest) จะไปเจอไฟล์พวกนี้ด้วยแล้วพยายาม
    // รันเป็นเทสต์ของตัวเอง แต่ไฟล์เหล่านั้น import test()/expect() จาก
    // '@playwright/test' ซึ่งต้องรันผ่าน `playwright test` เท่านั้น (ดู
    // package.json -> scripts["test:e2e"]) รันผ่าน Vitest ตรง ๆ ไม่ได้ จะ
    // error "Playwright Test did not expect test() to be called here" ทันที
    // (ของเดิมไม่มีการกันไว้ ทำให้ `npm test` เคยพังไปด้วยหลังเพิ่มโฟลเดอร์
    // e2e/ เข้ามา) — '**/node_modules/**' คือค่า default ของ Vitest เองอยู่
    // แล้ว ใส่ไว้ตรงนี้ด้วยเพื่อให้เห็นชัดเจนในไฟล์นี้ว่าไม่ได้ตั้งใจลบออก
    // (ถ้าเขียน exclude เองแล้วลืมใส่ค่า default เดิม Vitest จะไม่ใช้ค่า
    // default ให้อัตโนมัติอีกต่อไป ต้องระบุเองให้ครบ)
  }
})
