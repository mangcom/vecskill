module.exports = {
  testEnvironment: 'node',
  testMatch: ['<rootDir>/test1/**/*.spec.js'],
  clearMocks: true,
  verbose: true,
};
