// plugins/axios.client.js
import axios from 'axios'
import { useAuthStore } from '~/stores/auth'
export default defineNuxtPlugin((nuxtApp) => {
  const config = useRuntimeConfig()
  const auth = useAuthStore()
  const api = axios.create({
    baseURL: config.public.apiBase || 'http://localhost:7000',  // กรณี env ไม่มีค่า
    timeout: 15000,
    headers: { 'Content-Type': 'application/json' },
    withCredentials: false // ✅ ปิด credentials เพื่อให้ใช้ ACAO: * ได้
  })


  // ----- Request: แนบ Bearer token ถ้ามี
  api.interceptors.request.use((req) => {
  const auth = useAuthStore()
  if (auth.token) {
    req.headers = req.headers || {}
    req.headers.Authorization = `Bearer ${auth.token}`
  }
  return req
})
  // ----- Response: จัดการ 401 แบบ refresh + retry (JS ล้วน ไม่มี TS type)
  let isRefreshing = false
  const waiters = [] // array of callbacks

  function onRefreshed(newToken) {
    // ปล่อยทุกคิวที่รอผล refresh
    while (waiters.length) {
      const cb = waiters.shift()
      try { cb(newToken) } catch (_) {}
    }
  }
  api.interceptors.response.use(
    (res) => res,
    async (err) => {
      const status = err?.response?.status
      const original = err?.config || {}
      const url = (original.url || '').toString()

      // ไม่แตะ 401 ของ endpoint auth เอง
      const isAuthPath = url.includes('/api/auth/login') || url.includes('/api/auth/refresh')
      if (status !== 401 || isAuthPath) {
        return Promise.reject(err)
      }

      // กันลูป retry
      if (original._retry) {
        // refresh ล้มเหลวแล้ว → logout แค่ฝั่ง client
        if (process.client) auth.logout()
        return Promise.reject(err)
      }
      original._retry = true

      try {
        if (isRefreshing) {
          // รอให้ refresh เสร็จ แล้วค่อยยิงซ้ำ
          const newToken = await new Promise((resolve) => {
            waiters.push(resolve)
          })
          if (newToken) {
            original.headers = { ...(original.headers || {}), Authorization: `Bearer ${newToken}` }
          }
          return api(original)
        }

        // เริ่ม refresh
        isRefreshing = true
        const r = await api.post('/api/auth/refresh') // ต้องมี endpoint นี้ใน backend
        const newToken = r?.data?.accessToken || null

        if (!newToken) throw new Error('No refreshed token')

        // อัปเดต store และปล่อยคิว
        auth.setAuth(newToken, r?.data?.user ?? auth.user)
        onRefreshed(newToken)

        // ยิงคำขอเดิมซ้ำด้วย token ใหม่
        original.headers = { ...(original.headers || {}), Authorization: `Bearer ${newToken}` }
        return api(original)
      } catch (e) {
        onRefreshed(null)
        if (process.client) {
          auth.logout()
          // กันไม่ให้ redirect ตอนอยู่ที่ /login อยู่แล้ว
          const route = useRoute()
          if (route.path !== '/login') navigateTo('/login')
        }
        return Promise.reject(err)
      } finally {
        isRefreshing = false
      }
    }
  )
  // ผูกเป็น $api
  nuxtApp.provide('api', api)
})
